/**
 * Antigravity IDE - Core Type Definitions
 * 
 * This file contains all the TypeScript interfaces and types that define
 * the structure of the Antigravity agentic development environment.
 */

// =============================================================================
// AGENT TYPES
// =============================================================================

export type AgentStatus =
  | "idle"
  | "planning"
  | "awaiting_approval"
  | "executing"
  | "verifying"
  | "complete"
  | "error"
  | "paused"
  | "cancelled";

export interface Agent {
  id: string;
  name: string;
  status: AgentStatus;
  mission: Mission | null;
  workspace: WorkspaceContext;
  tools: AgentTool[];
  artifacts: Artifact[];
  knowledge: KnowledgeBase;
  createdAt: Date;
  updatedAt: Date;
  metrics: AgentMetrics;
}

export interface AgentMetrics {
  tokensUsed: number;
  tokensRemaining: number;
  tasksCompleted: number;
  tasksTotal: number;
  executionTimeMs: number;
  modelsUsed: string[];
}

export interface AgentConfig {
  maxConcurrentAgents: number;
  defaultTools: string[];
  autoApprovalThreshold: number;
  timeoutMs: number;
}

// =============================================================================
// MISSION TYPES
// =============================================================================

export interface Mission {
  id: string;
  goal: string;
  constraints: string[];
  successCriteria: string[];
  taskList: Task[];
  implementationPlan: ImplementationPlan | null;
  walkthrough: Walkthrough | null;
  status: MissionStatus;
  priority: MissionPriority;
  startedAt: Date | null;
  completedAt: Date | null;
}

export type MissionStatus =
  | "pending"
  | "planning"
  | "in_progress"
  | "verifying"
  | "completed"
  | "failed"
  | "cancelled";

export type MissionPriority = "critical" | "high" | "normal" | "low";

export interface MissionInput {
  goal: string;
  name?: string;
  constraints?: string[];
  successCriteria?: string[];
  workspace: string;
  priority?: MissionPriority;
}

export interface MissionResult {
  success: boolean;
  artifacts?: Artifact[];
  error?: Error;
  summary?: string;
  metrics?: MissionMetrics;
}

export interface MissionMetrics {
  totalTokensUsed: number;
  totalTimeMs: number;
  modelsUsed: ModelUsage[];
  filesModified: number;
  testsRun: number;
  testsPassed: number;
}

export interface ModelUsage {
  model: ModelIdentifier;
  tokensUsed: number;
  calls: number;
}

// =============================================================================
// TASK TYPES
// =============================================================================

export interface Task {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  subTasks: Task[];
  dependencies: string[];
  estimatedTokens: number;
  actualTokens?: number;
  assignedModel?: ModelIdentifier;
  startedAt?: Date;
  completedAt?: Date;
  result?: TaskResult;
}

export type TaskStatus =
  | "pending"
  | "in_progress"
  | "awaiting_approval"
  | "completed"
  | "failed"
  | "skipped";

export interface TaskResult {
  success: boolean;
  output?: string;
  error?: string;
  artifacts?: Artifact[];
  filesModified?: string[];
}

// =============================================================================
// ARTIFACT TYPES
// =============================================================================

export type ArtifactType =
  | "task_list"
  | "implementation_plan"
  | "walkthrough"
  | "screenshot"
  | "video_recording"
  | "diff"
  | "test_results"
  | "code_snippet"
  | "documentation";

export interface Artifact {
  id: string;
  type: ArtifactType;
  title: string;
  content: string | Buffer;
  mimeType: string;
  metadata: ArtifactMetadata;
  comments: ArtifactComment[];
}

export interface ArtifactMetadata {
  createdAt: Date;
  updatedAt: Date;
  agentId: string;
  missionId: string;
  taskId?: string;
  step: number;
  verified: boolean;
  version: number;
}

export interface ArtifactComment {
  id: string;
  author: string;
  authorType: "human" | "agent";
  content: string;
  createdAt: Date;
  resolved: boolean;
  position?: CommentPosition;
}

export interface CommentPosition {
  startLine?: number;
  endLine?: number;
  startColumn?: number;
  endColumn?: number;
  x?: number;
  y?: number;
}

export interface ImplementationPlan {
  overview: string;
  architecturalChanges: ArchitecturalChange[];
  fileModifications: FileModification[];
  riskAssessment: RiskAssessment;
  estimatedEffort: EffortEstimate;
}

export interface ArchitecturalChange {
  component: string;
  changeType: "add" | "modify" | "remove" | "refactor";
  description: string;
  impact: "low" | "medium" | "high";
  dependencies: string[];
}

export interface FileModification {
  path: string;
  action: "create" | "modify" | "delete" | "rename";
  description: string;
  linesAdded?: number;
  linesRemoved?: number;
}

export interface RiskAssessment {
  overallRisk: "low" | "medium" | "high" | "critical";
  factors: RiskFactor[];
  mitigations: string[];
}

export interface RiskFactor {
  description: string;
  severity: "low" | "medium" | "high";
  likelihood: "unlikely" | "possible" | "likely";
}

export interface EffortEstimate {
  tokens: number;
  estimatedTimeMinutes: number;
  complexity: "simple" | "moderate" | "complex" | "very_complex";
}

export interface Walkthrough {
  summary: string;
  stepsPerformed: WalkthroughStep[];
  results: WalkthroughResult[];
  screenshots: string[];
  videoUrl?: string;
}

export interface WalkthroughStep {
  step: number;
  action: string;
  description: string;
  timestamp: Date;
  screenshotPath?: string;
}

export interface WalkthroughResult {
  criterion: string;
  passed: boolean;
  evidence: string;
}

// =============================================================================
// TOOL TYPES
// =============================================================================

export interface AgentTool {
  name: string;
  description: string;
  parameters: ToolParameter[];
  execute: (params: Record<string, unknown>, context: ToolContext) => Promise<ToolResult>;
  requiresApproval: boolean | ((params: Record<string, unknown>) => boolean);
  riskLevel: "safe" | "moderate" | "dangerous";
  category: ToolCategory;
}

export type ToolCategory =
  | "file_system"
  | "terminal"
  | "browser"
  | "api"
  | "git"
  | "database"
  | "search"
  | "analysis";

export interface ToolParameter {
  name: string;
  type: "string" | "number" | "boolean" | "array" | "object";
  description: string;
  required: boolean;
  default?: unknown;
  enum?: unknown[];
  validation?: (value: unknown) => boolean;
}

export interface ToolContext {
  agentId: string;
  missionId: string;
  workspace: WorkspaceContext;
  permissions: PermissionSet;
}

export interface ToolResult {
  success: boolean;
  output?: unknown;
  error?: string;
  artifacts?: Artifact[];
  sideEffects?: SideEffect[];
}

export interface SideEffect {
  type: "file_created" | "file_modified" | "file_deleted" | "process_started" | "network_request";
  description: string;
  path?: string;
  reversible: boolean;
}

// =============================================================================
// NEURAL ENGINE TYPES
// =============================================================================

export type ModelIdentifier =
  | "gemini-3.1-pro"
  | "gemini-3-flash"
  | "gemini-3.1-flash-lite"
  | "claude-4.6-opus"
  | "claude-4.6-sonnet"
  | "claude-4.5-haiku"
  | "gpt-oss-120b"
  | "gemma-4-27b"
  | "local-nim";

export type ModelTier = "tier1" | "tier2" | "tier3" | "local";

export type ClaudeEffortLevel = "low" | "medium" | "high" | "max";

export interface ModelConfig {
  identifier: ModelIdentifier;
  provider: ModelProvider;
  tier: ModelTier;
  contextWindow: number;
  maxOutputTokens: number;
  costPer1kTokens: CostStructure;
  capabilities: ModelCapabilities;
}

export type ModelProvider = "vertex" | "anthropic" | "nvidia" | "local";

export interface CostStructure {
  input: number;
  output: number;
  cached?: number;
}

export interface ModelCapabilities {
  streaming: boolean;
  functionCalling: boolean;
  vision: boolean;
  codeExecution: boolean;
  webBrowsing: boolean;
  longContext: boolean;
  adaptiveThinking?: boolean;
  contextCompaction?: boolean;
}

export interface UnifiedModelRequest {
  model: ModelIdentifier;
  messages: Message[];
  options: ModelOptions;
  stream?: boolean;
  context?: PreparedContext;
}

export interface Message {
  role: "system" | "user" | "assistant" | "tool";
  content: string | ContentPart[];
  name?: string;
  toolCallId?: string;
}

export interface ContentPart {
  type: "text" | "image" | "file";
  text?: string;
  imageUrl?: string;
  imageData?: Buffer;
  mimeType?: string;
  filePath?: string;
}

export interface ModelOptions {
  maxTokens?: number;
  temperature?: number;
  topP?: number;
  topK?: number;
  stopSequences?: string[];
  thinking?: ThinkingConfig;
  safetySettings?: SafetySettings;
  responseFormat?: ResponseFormat;
}

export interface ThinkingConfig {
  type: "enabled" | "disabled";
  effortLevel?: ClaudeEffortLevel;
  budgetTokens?: number;
}

export interface SafetySettings {
  harassment: SafetyThreshold;
  hateSpeech: SafetyThreshold;
  sexuallyExplicit: SafetyThreshold;
  dangerousContent: SafetyThreshold;
}

export type SafetyThreshold = "block_none" | "block_low" | "block_medium" | "block_high";

export interface ResponseFormat {
  type: "text" | "json_object" | "json_schema";
  schema?: object;
}

export interface ModelResponse {
  id: string;
  model: ModelIdentifier;
  content: string;
  thinking?: string;
  usage: TokenUsage;
  finishReason: FinishReason;
  toolCalls?: ToolCall[];
}

export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  cachedTokens?: number;
  thinkingTokens?: number;
}

export type FinishReason = "stop" | "length" | "tool_calls" | "content_filter" | "error";

export interface ToolCall {
  id: string;
  type: "function";
  function: {
    name: string;
    arguments: string;
  };
}

export interface PreparedContext {
  files: FileContent[];
  history: ConversationTurn[];
  docs: Documentation[];
  totalTokens: number;
  compacted: boolean;
}

export interface FileContent {
  path: string;
  content: string;
  language: string;
  tokens: number;
  relevanceScore: number;
}

export interface ConversationTurn {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  summarized: boolean;
}

export interface Documentation {
  source: string;
  title: string;
  content: string;
  tokens: number;
}

export interface RoutingDecision {
  model: ModelIdentifier;
  effortLevel?: ClaudeEffortLevel;
  contextBudget: number;
  fallbackModel: ModelIdentifier;
  reasoning: string;
}

export interface ComplexityScore {
  score: number;
  requiresDeepReasoning: boolean;
  factors: ComplexityFactor[];
}

export interface ComplexityFactor {
  name: string;
  weight: number;
  value: number;
}

export interface ContextRequirements {
  tokens: number;
  filesNeeded: number;
  historyDepth: number;
  docsNeeded: boolean;
}

// =============================================================================
// BROWSER AGENT TYPES
// =============================================================================

export interface BrowserAgentConfig {
  isolatedProfile: boolean;
  headless: boolean;
  viewport: Viewport;
  allowedDomains: string[];
  blockedDomains: string[];
  recordVideo: boolean;
  screenshotOnAction: boolean;
  timeout: number;
}

export interface Viewport {
  width: number;
  height: number;
}

export interface BrowserAction {
  type: BrowserActionType;
  selector?: string;
  value?: string;
  url?: string;
  x?: number;
  y?: number;
  key?: string;
}

export type BrowserActionType =
  | "navigate"
  | "click"
  | "fill"
  | "select"
  | "hover"
  | "scroll"
  | "press"
  | "wait"
  | "screenshot"
  | "extract";

export interface NavigationResult {
  url: string;
  title: string;
  screenshot: Buffer;
  loadTimeMs: number;
  status: number;
}

export interface InteractionResult {
  success: boolean;
  action: BrowserAction;
  before: Buffer;
  after: Buffer;
  error?: string;
  duration: number;
}

export interface DOMContent {
  html: string;
  text: string;
  attributes?: Record<string, string | null>;
}

export interface UIExpectation {
  description: string;
  selector?: string;
  condition: UICondition;
  value?: string;
}

export type UICondition =
  | "visible"
  | "hidden"
  | "contains_text"
  | "has_attribute"
  | "is_enabled"
  | "is_disabled"
  | "has_class";

export interface VerificationResult {
  passed: boolean;
  results: ExpectationResult[];
  visualAnalysis: VisualAnalysisResult;
  screenshot: Buffer;
}

export interface ExpectationResult {
  expectation: UIExpectation;
  passed: boolean;
  actualValue?: string;
  error?: string;
}

export interface VisualAnalysisResult {
  passed: boolean;
  confidence: number;
  findings: VisualFinding[];
  suggestions: string[];
}

export interface VisualFinding {
  type: "regression" | "improvement" | "neutral";
  description: string;
  severity: "low" | "medium" | "high";
  location?: { x: number; y: number; width: number; height: number };
}

// =============================================================================
// GPU / NVML TYPES
// =============================================================================

export interface NVMLMetrics {
  gpuUtilization: number;
  memoryUsed: number;
  memoryTotal: number;
  memoryFree: number;
  temperature: number;
  powerDraw: number;
  powerLimit: number;
  performanceState: PerformanceState;
  eccErrors: ECCErrorCounts;
  processes: GPUProcess[];
  fanSpeed: number;
  clockSpeeds: ClockSpeeds;
}

export type PerformanceState =
  | "P0" | "P1" | "P2" | "P3" | "P4" | "P5" | "P6" | "P7"
  | "P8" | "P9" | "P10" | "P11" | "P12";

export interface ECCErrorCounts {
  singleBit: number;
  doubleBit: number;
  singleBitVolatile: number;
  doubleBitVolatile: number;
}

export interface GPUProcess {
  pid: number;
  name: string;
  memoryUsed: number;
  computeUsage: number;
  type: "compute" | "graphics" | "mixed";
}

export interface ClockSpeeds {
  graphics: number;
  memory: number;
  sm: number;
}

export interface ResourceThresholds {
  maxGpuUtilization: number;
  maxMemoryUsage: number;
  maxTemperature: number;
  minFreeMemory: number;
  maxPowerDraw: number;
}

export interface ModelRequirements {
  model: ModelIdentifier;
  vramRequired: number;
  computeRequired: number;
  estimatedTimeMs: number;
}

export interface ThrottleAction {
  type: "pause_agent" | "block_spawn" | "reduce_speed" | "alert";
  reason: string;
  affectedAgents?: string[];
  duration?: number;
}

// =============================================================================
// SECURITY TYPES
// =============================================================================

export interface PermissionConfig {
  terminal: TerminalPermissionLevel;
  fileSystem: FileSystemPermissions;
  browser: BrowserPermissions;
  network: NetworkPermissions;
  models: ModelPermissions;
}

export type TerminalPermissionLevel = "off" | "auto" | "turbo";

export interface FileSystemPermissions {
  allowedPaths: string[];
  deniedPaths: string[];
  readOnlyPaths: string[];
  maxFileSize: number;
  allowedExtensions: string[];
  deniedExtensions: string[];
}

export interface BrowserPermissions {
  allowedDomains: string[];
  deniedDomains: string[];
  allowCookies: boolean;
  allowLocalStorage: boolean;
  allowClipboard: boolean;
  maxNavigationsPerMinute: number;
}

export interface NetworkPermissions {
  allowedHosts: string[];
  deniedHosts: string[];
  allowedPorts: number[];
  maxRequestsPerMinute: number;
}

export interface ModelPermissions {
  allowedModels: ModelIdentifier[];
  maxTokensPerRequest: number;
  maxRequestsPerMinute: number;
  dailyTokenBudget: number;
}

export interface PermissionSet {
  terminal: TerminalPermissionLevel;
  paths: {
    read: string[];
    write: string[];
    execute: string[];
  };
  domains: {
    allowed: string[];
    denied: string[];
  };
  models: ModelIdentifier[];
}

export interface PermissionResult {
  allowed: boolean;
  requiresApproval: boolean;
  reason: string;
  riskLevel?: "low" | "medium" | "high" | "critical";
}

export interface SecretMatch {
  type: SecretType;
  position: number;
  length: number;
  masked: string;
  confidence: number;
}

export type SecretType =
  | "api_key"
  | "aws_access_key"
  | "aws_secret_key"
  | "github_token"
  | "private_key"
  | "password"
  | "oauth_token"
  | "jwt"
  | "generic_secret";

export interface AuditLogEntry {
  id: string;
  timestamp: Date;
  agentId: string;
  userId?: string;
  action: string;
  actionType: AuditActionType;
  parameters: Record<string, unknown>;
  result: "success" | "failure" | "pending";
  approvedBy?: string;
  workspace: string;
  ipAddress?: string;
  userAgent?: string;
}

export type AuditActionType =
  | "file_read"
  | "file_write"
  | "file_delete"
  | "terminal_execute"
  | "browser_navigate"
  | "browser_interact"
  | "model_invoke"
  | "agent_create"
  | "agent_terminate"
  | "permission_request"
  | "permission_grant"
  | "permission_deny";

// =============================================================================
// WORKSPACE TYPES
// =============================================================================

export interface WorkspaceContext {
  id: string;
  name: string;
  rootPath: string;
  gitInfo?: GitInfo;
  config: WorkspaceConfig;
  state: WorkspaceState;
}

export interface GitInfo {
  remote: string;
  branch: string;
  commit: string;
  isDirty: boolean;
  uncommittedChanges: number;
}

export interface WorkspaceConfig {
  rules: Rule[];
  workflows: Workflow[];
  skills: Skill[];
  ignorePaths: string[];
  preferredModels: ModelIdentifier[];
}

export interface WorkspaceState {
  openFiles: string[];
  activeFile?: string;
  terminalSessions: TerminalSession[];
  runningProcesses: RunningProcess[];
}

export interface TerminalSession {
  id: string;
  name: string;
  cwd: string;
  history: TerminalCommand[];
  isActive: boolean;
}

export interface TerminalCommand {
  command: string;
  output: string;
  exitCode: number;
  timestamp: Date;
  duration: number;
}

export interface RunningProcess {
  pid: number;
  name: string;
  command: string;
  startedAt: Date;
  port?: number;
}

// =============================================================================
// CONFIGURATION TYPES
// =============================================================================

export interface Rule {
  id: string;
  name: string;
  description: string;
  type: "always" | "file_type" | "directory";
  condition?: RuleCondition;
  content: string;
  enabled: boolean;
  priority: number;
}

export interface RuleCondition {
  fileTypes?: string[];
  directories?: string[];
  pattern?: string;
}

export interface Workflow {
  id: string;
  name: string;
  trigger: string;
  description: string;
  steps: WorkflowStep[];
  variables: WorkflowVariable[];
  enabled: boolean;
}

export interface WorkflowStep {
  id: string;
  name: string;
  action: WorkflowAction;
  condition?: string;
  onError: "stop" | "continue" | "retry";
  retries?: number;
}

export interface WorkflowAction {
  type: "terminal" | "file" | "browser" | "agent" | "notify";
  command?: string;
  path?: string;
  url?: string;
  message?: string;
  parameters?: Record<string, unknown>;
}

export interface WorkflowVariable {
  name: string;
  type: "string" | "number" | "boolean" | "select";
  default?: unknown;
  options?: unknown[];
  required: boolean;
  description: string;
}

export interface Skill {
  id: string;
  name: string;
  triggerPhrases: string[];
  description: string;
  parameters: SkillParameter[];
  implementation: SkillImplementation;
  enabled: boolean;
}

export interface SkillParameter {
  name: string;
  type: "string" | "number" | "boolean" | "file" | "directory";
  description: string;
  required: boolean;
  default?: unknown;
}

export interface SkillImplementation {
  type: "inline" | "file" | "api";
  code?: string;
  path?: string;
  endpoint?: string;
  method?: "GET" | "POST" | "PUT" | "DELETE";
}

// =============================================================================
// KNOWLEDGE BASE TYPES
// =============================================================================

export interface KnowledgeBase {
  id: string;
  workspaceId: string;
  patterns: LearnedPattern[];
  preferences: UserPreference[];
  solutions: SuccessfulSolution[];
  embeddings: EmbeddingIndex;
}

export interface LearnedPattern {
  id: string;
  pattern: string;
  context: string;
  language: string;
  successRate: number;
  usageCount: number;
  lastUsed: Date;
  createdAt: Date;
}

export interface UserPreference {
  id: string;
  category: PreferenceCategory;
  key: string;
  value: unknown;
  confidence: number;
  source: "explicit" | "inferred";
  updatedAt: Date;
}

export type PreferenceCategory =
  | "code_style"
  | "naming_convention"
  | "architecture"
  | "testing"
  | "documentation"
  | "tooling"
  | "communication";

export interface SuccessfulSolution {
  id: string;
  problemDescription: string;
  solutionSummary: string;
  codeSnippets: CodeSnippet[];
  missionId: string;
  feedback: SolutionFeedback;
  createdAt: Date;
}

export interface CodeSnippet {
  code: string;
  language: string;
  path: string;
  startLine: number;
  endLine: number;
}

export interface SolutionFeedback {
  rating: number;
  comments: string[];
  wasModified: boolean;
}

export interface EmbeddingIndex {
  dimensions: number;
  count: number;
  lastUpdated: Date;
}

// =============================================================================
// INBOX / NOTIFICATION TYPES
// =============================================================================

export interface InboxMessage {
  id: string;
  agentId: string;
  missionId: string;
  timestamp: Date;
  type: InboxMessageType;
  priority: InboxPriority;
  payload: InboxPayload;
  status: InboxStatus;
  readAt?: Date;
  respondedAt?: Date;
  response?: InboxResponse;
}

export type InboxMessageType =
  | "permission_request"
  | "plan_review"
  | "completion"
  | "error"
  | "clarification"
  | "progress_update"
  | "warning";

export type InboxPriority = "critical" | "high" | "normal" | "low";

export type InboxStatus = "pending" | "approved" | "rejected" | "deferred" | "expired";

export interface InboxPayload {
  title: string;
  description: string;
  artifact?: Artifact;
  actions: InboxAction[];
  expiresAt?: Date;
  context?: Record<string, unknown>;
}

export interface InboxAction {
  id: string;
  label: string;
  type: "approve" | "reject" | "modify" | "view_details" | "defer";
  primary?: boolean;
  destructive?: boolean;
}

export interface InboxResponse {
  action: string;
  comment?: string;
  modifications?: Record<string, unknown>;
  respondedBy: string;
  timestamp: Date;
}

// =============================================================================
// UI TYPES
// =============================================================================

export interface EditorViewState {
  activeFile: string | null;
  openFiles: OpenFile[];
  sidebarVisible: boolean;
  sidebarWidth: number;
  terminalVisible: boolean;
  terminalHeight: number;
  aiPanelVisible: boolean;
  aiPanelWidth: number;
}

export interface OpenFile {
  path: string;
  content: string;
  language: string;
  isDirty: boolean;
  cursorPosition: CursorPosition;
  selections: Selection[];
  scrollPosition: ScrollPosition;
}

export interface CursorPosition {
  line: number;
  column: number;
}

export interface Selection {
  startLine: number;
  startColumn: number;
  endLine: number;
  endColumn: number;
}

export interface ScrollPosition {
  top: number;
  left: number;
}

export interface ManagerViewState {
  activeAgents: Agent[];
  selectedAgentId: string | null;
  inboxMessages: InboxMessage[];
  unreadCount: number;
  gpuMetrics: NVMLMetrics | null;
  viewMode: "grid" | "list" | "timeline";
  filters: ManagerFilters;
}

export interface ManagerFilters {
  status: AgentStatus[];
  priority: MissionPriority[];
  dateRange: DateRange | null;
}

export interface DateRange {
  start: Date;
  end: Date;
}

// =============================================================================
// EVENT TYPES
// =============================================================================

export interface AntigravityEvent<T = unknown> {
  id: string;
  type: EventType;
  source: EventSource;
  timestamp: Date;
  payload: T;
}

export type EventType =
  | "agent.created"
  | "agent.status_changed"
  | "agent.completed"
  | "agent.error"
  | "mission.started"
  | "mission.progress"
  | "mission.completed"
  | "task.started"
  | "task.completed"
  | "artifact.created"
  | "inbox.message"
  | "permission.requested"
  | "permission.resolved"
  | "gpu.threshold_exceeded"
  | "gpu.metrics_updated"
  | "file.modified"
  | "terminal.output";

export interface EventSource {
  type: "agent" | "system" | "user" | "browser";
  id: string;
}

export type EventHandler<T = unknown> = (event: AntigravityEvent<T>) => void | Promise<void>;

export interface EventSubscription {
  id: string;
  eventType: EventType | EventType[];
  handler: EventHandler;
  filter?: (event: AntigravityEvent) => boolean;
}
