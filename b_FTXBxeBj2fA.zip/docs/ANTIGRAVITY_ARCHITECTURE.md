# Antigravity IDE - Comprehensive Architecture Blueprint

## Executive Summary

This document outlines the complete architectural specification for building an **Antigravity-class Agentic Development Environment** - a next-generation IDE that shifts from "AI-assisted" coding to "agent-first" orchestration. The system enables developers to act as mission-control architects, managing autonomous AI agents that plan, execute, and verify complex engineering tasks.

---

## Table of Contents

1. [System Philosophy & Design Principles](#1-system-philosophy--design-principles)
2. [High-Level Architecture](#2-high-level-architecture)
3. [User Interface Architecture](#3-user-interface-architecture)
4. [Neural Engine & Model Orchestration](#4-neural-engine--model-orchestration)
5. [Agent Framework Architecture](#5-agent-framework-architecture)
6. [Hardware Monitoring & Resource Management](#6-hardware-monitoring--resource-management)
7. [Browser Automation Subsystem](#7-browser-automation-subsystem)
8. [Security & Permission Model](#8-security--permission-model)
9. [API Gateway & Integration Layer](#9-api-gateway--integration-layer)
10. [Data Persistence & Knowledge Management](#10-data-persistence--knowledge-management)
11. [Deployment Architecture](#11-deployment-architecture)
12. [Implementation Roadmap](#12-implementation-roadmap)

---

## 1. System Philosophy & Design Principles

### 1.1 Agent-First Paradigm

The fundamental design philosophy assumes that **AI is not a peripheral utility but an autonomous actor** capable of:
- Long-horizon reasoning (multi-hour/day tasks)
- Multi-step task execution with minimal human intervention
- Self-verification through artifacts and browser testing
- Continuous learning from successful patterns

### 1.2 Core Design Principles

| Principle | Description |
|-----------|-------------|
| **Bifurcated Interface** | Separate tactical code editing from strategic orchestration |
| **Model Specialization** | Route tasks to optimal models based on reasoning requirements |
| **Hardware Awareness** | Real-time GPU/resource monitoring for stability |
| **Artifact Verification** | Tangible deliverables that prove agent work |
| **Human-in-the-Loop Gating** | Critical decisions require human approval |

---

## 2. High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              ANTIGRAVITY IDE                                     │
├─────────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                  │
│  │   Editor View   │  │  Manager View   │  │  Browser Agent  │                  │
│  │   (Code OSS)    │  │  (React App)    │  │  (Chrome CDP)   │                  │
│  └────────┬────────┘  └────────┬────────┘  └────────┬────────┘                  │
│           │                    │                    │                            │
│  ┌────────┴────────────────────┴────────────────────┴────────┐                  │
│  │                    UI Shell Layer (Electron)               │                  │
│  └────────────────────────────┬───────────────────────────────┘                  │
│                               │                                                  │
│  ┌────────────────────────────┴───────────────────────────────┐                  │
│  │              Agent Orchestration Engine                     │                  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │                  │
│  │  │ Task Router  │  │ Context Mgr  │  │ Artifact Gen │      │                  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘      │                  │
│  └────────────────────────────┬───────────────────────────────┘                  │
│                               │                                                  │
│  ┌────────────────────────────┴───────────────────────────────┐                  │
│  │                   Neural Engine Layer                       │                  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │                  │
│  │  │ Gemini 3.1   │  │ Claude 4.6   │  │  NVIDIA NIM  │      │                  │
│  │  │    Pro       │  │    Opus      │  │  Local LLMs  │      │                  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘      │                  │
│  └────────────────────────────┬───────────────────────────────┘                  │
│                               │                                                  │
│  ┌────────────────────────────┴───────────────────────────────┐                  │
│  │              Infrastructure Layer                           │                  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │                  │
│  │  │  NVML/GPU    │  │  Storage     │  │  Security    │      │                  │
│  │  │  Monitor     │  │  (SQLite/PG) │  │  Gateway     │      │                  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘      │                  │
│  └────────────────────────────────────────────────────────────┘                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 2.1 Layer Responsibilities

| Layer | Responsibility | Technologies |
|-------|---------------|--------------|
| **UI Shell** | Window management, view routing, IPC | Electron, React |
| **Agent Orchestration** | Task decomposition, agent lifecycle, verification | Node.js, TypeScript |
| **Neural Engine** | Model routing, context management, inference | Vertex AI, Anthropic SDK, NVIDIA NIM |
| **Infrastructure** | Hardware monitoring, persistence, security | NVML, SQLite/PostgreSQL, OAuth 2.0 |

---

## 3. User Interface Architecture

### 3.1 Dual-Surface Interface Design

The UI implements a **bifurcated architecture** separating tactical and strategic work:

#### Editor View (Tactical Surface)
```typescript
interface EditorViewConfig {
  base: "Code-OSS" | "Monaco";
  features: {
    tabCompletion: AIAutoComplete;      // "Tab" mode
    inlineCommands: AIInlineEdit;       // "Command" mode
    contextSidebar: AIChatPanel;        // Contextual assistance
    fileExplorer: ExtendedFileTree;
    terminal: IntegratedTerminal;
  };
  vibeCodeMode: {
    enabled: boolean;
    naturalLanguageInput: boolean;
    livePreview: boolean;
  };
}
```

#### Manager View (Strategic Surface)
```typescript
interface ManagerViewConfig {
  layout: "dashboard";
  components: {
    agentGrid: AgentCardGrid;           // Up to 5 parallel agents
    inbox: NotificationLedger;          // Critical decision queue
    artifactViewer: ArtifactPanel;      // Verification documents
    resourceMonitor: GPUMetricsPanel;   // NVML integration
    missionTimeline: TaskTimeline;      // Progress visualization
  };
  maxConcurrentAgents: 5;
}
```

### 3.2 Component Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        App Shell                                 │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────────┐  ┌─────────────────────────────────┐   │
│  │    View Switcher    │  │        Global Controls          │   │
│  │  [Editor] [Manager] │  │  [Settings] [Models] [Deploy]   │   │
│  └─────────────────────┘  └─────────────────────────────────┘   │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                    EDITOR VIEW                             │  │
│  │  ┌──────────────┬───────────────────────┬──────────────┐  │  │
│  │  │  File Tree   │    Monaco Editor      │  AI Sidebar  │  │  │
│  │  │              │                       │              │  │  │
│  │  │  - src/      │  // Your code here    │  [Chat]      │  │  │
│  │  │  - tests/    │  function main() {    │  [Context]   │  │  │
│  │  │  - docs/     │    // ...             │  [History]   │  │  │
│  │  │              │  }                    │              │  │  │
│  │  └──────────────┴───────────────────────┴──────────────┘  │  │
│  │  ┌─────────────────────────────────────────────────────┐  │  │
│  │  │                  Terminal Panel                      │  │  │
│  │  └─────────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                   MANAGER VIEW                             │  │
│  │  ┌─────────────────────────────────────────────────────┐  │  │
│  │  │                    Inbox (3 pending)                 │  │  │
│  │  │  ⚠️ Agent-2 requests terminal permission            │  │  │
│  │  │  📋 Agent-1 plan ready for review                   │  │  │
│  │  │  ✅ Agent-3 completed refactoring                   │  │  │
│  │  └─────────────────────────────────────────────────────┘  │  │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐     │  │
│  │  │ Agent 1  │ │ Agent 2  │ │ Agent 3  │ │ Agent 4  │     │  │
│  │  │ ████████ │ │ ████░░░░ │ │ Complete │ │  Idle    │     │  │
│  │  │ Testing  │ │ Refactor │ │ ✓ Done   │ │ [Start]  │     │  │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘     │  │
│  │  ┌─────────────────────────────────────────────────────┐  │  │
│  │  │  GPU: 78% │ VRAM: 45GB/80GB │ Temp: 72°C │ Power: OK │  │  │
│  │  └─────────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

### 3.3 Inbox System Architecture

The Inbox serves as the **critical communication ledger** between agents and humans:

```typescript
interface InboxMessage {
  id: string;
  agentId: string;
  timestamp: Date;
  type: "permission_request" | "plan_review" | "completion" | "error" | "clarification";
  priority: "critical" | "high" | "normal" | "low";
  payload: {
    title: string;
    description: string;
    artifact?: Artifact;
    actions: InboxAction[];
  };
  status: "pending" | "approved" | "rejected" | "deferred";
}

interface InboxAction {
  label: string;
  type: "approve" | "reject" | "modify" | "view_details";
  handler: () => Promise<void>;
}
```

---

## 4. Neural Engine & Model Orchestration

### 4.1 Multi-Model Architecture

The Neural Engine implements **intelligent task routing** based on reasoning requirements:

```typescript
interface NeuralEngineConfig {
  models: {
    tier1: {
      gemini31Pro: GeminiModelConfig;    // 2M context, orchestration
      claude46Opus: ClaudeModelConfig;   // Adaptive thinking, precision
    };
    tier2: {
      gemini3Flash: GeminiModelConfig;   // 1M context, rapid tasks
      claude46Sonnet: ClaudeModelConfig; // Balanced performance
    };
    tier3: {
      gemini31FlashLite: GeminiModelConfig; // Classification, routing
      claude45Haiku: ClaudeModelConfig;     // Quick responses
    };
    local: {
      nvidiaNIM: NIMConfig;              // Local inference
      gemma4: LocalModelConfig;          // Open-source fallback
    };
  };
  router: TaskRouter;
  contextManager: ContextController;
}
```

### 4.2 Model Selection Matrix

| Task Type | Primary Model | Context Needs | Reasoning Level |
|-----------|--------------|---------------|-----------------|
| **Large Refactoring** | Gemini 3.1 Pro | 2M tokens | Tier 1 |
| **Architectural Planning** | Claude 4.6 Opus | 1M tokens | Tier 1 (Max Effort) |
| **E2E Test Generation** | Gemini 3.1 Pro | 2M tokens | Tier 1 |
| **Rapid Debugging** | Gemini 3 Flash | 1M tokens | Tier 2 |
| **Unit Test Writing** | Claude 4.6 Sonnet | 200K tokens | Tier 2 |
| **UI Iteration** | Gemini 3 Flash | 1M tokens | Tier 2 |
| **Task Routing** | Gemini 3.1 Flash-Lite | 200K tokens | Tier 3 |
| **Documentation Summary** | Claude 4.5 Haiku | 200K tokens | Tier 3 |

### 4.3 Task Router Implementation

```typescript
class TaskRouter {
  private models: Map<string, AIModel>;
  private contextManager: ContextController;

  async route(task: AgentTask): Promise<RoutingDecision> {
    // 1. Analyze task complexity
    const complexity = await this.analyzeComplexity(task);
    
    // 2. Estimate context requirements
    const contextNeeds = await this.estimateContext(task);
    
    // 3. Select optimal model
    const model = this.selectModel(complexity, contextNeeds);
    
    // 4. Configure effort level (for Claude)
    const effortLevel = this.determineEffort(complexity);
    
    return {
      model,
      effortLevel,
      contextBudget: contextNeeds,
      fallbackModel: this.selectFallback(model),
    };
  }

  private selectModel(
    complexity: ComplexityScore,
    contextNeeds: ContextRequirements
  ): AIModel {
    // Large codebase + high complexity = Gemini 3.1 Pro
    if (contextNeeds.tokens > 1_000_000 && complexity.score > 0.8) {
      return this.models.get("gemini-3.1-pro");
    }
    
    // Deep reasoning + precision = Claude 4.6 Opus
    if (complexity.requiresDeepReasoning && complexity.score > 0.7) {
      return this.models.get("claude-4.6-opus");
    }
    
    // Standard tasks = Tier 2 models
    if (complexity.score > 0.4) {
      return contextNeeds.tokens > 500_000
        ? this.models.get("gemini-3-flash")
        : this.models.get("claude-4.6-sonnet");
    }
    
    // Simple tasks = Tier 3 models
    return this.models.get("gemini-3.1-flash-lite");
  }
}
```

### 4.4 Context Controller

Manages the massive context windows (up to 2M tokens):

```typescript
class ContextController {
  private contextCache: Map<string, ContextWindow>;
  private compactionService: ClaudeCompactionAPI;

  async prepareContext(
    task: AgentTask,
    model: AIModel
  ): Promise<PreparedContext> {
    const maxTokens = model.contextWindow;
    
    // 1. Gather relevant files
    const files = await this.gatherRelevantFiles(task);
    
    // 2. Include conversation history
    const history = await this.getConversationHistory(task.agentId);
    
    // 3. Add documentation context
    const docs = await this.gatherDocumentation(task);
    
    // 4. Calculate total tokens
    const totalTokens = this.calculateTokens(files, history, docs);
    
    // 5. Apply compaction if needed
    if (totalTokens > maxTokens * 0.9) {
      return this.compactContext(files, history, docs, maxTokens);
    }
    
    return { files, history, docs, totalTokens };
  }

  private async compactContext(
    files: FileContent[],
    history: ConversationTurn[],
    docs: Documentation[],
    maxTokens: number
  ): Promise<PreparedContext> {
    // Use Claude's Context Compaction API for summarization
    const compactedHistory = await this.compactionService.compact(history);
    
    // Prioritize recent and relevant files
    const prioritizedFiles = this.prioritizeFiles(files);
    
    return {
      files: prioritizedFiles,
      history: compactedHistory,
      docs: this.summarizeDocs(docs),
      totalTokens: maxTokens * 0.85,
    };
  }
}
```

### 4.5 Claude 4.6 Adaptive Thinking Integration

```typescript
interface ClaudeAdaptiveConfig {
  effortLevels: {
    low: { description: "Fast, token-efficient for simple automation" };
    medium: { description: "Balanced for production use cases" };
    high: { description: "Complex architectural analysis" };
    max: { description: "Highest capability for agentic coding" };
  };
  contextCompaction: {
    enabled: boolean;
    autoSummarize: boolean;
    preserveKeyDecisions: boolean;
  };
}

class ClaudeAdapter {
  async invoke(
    prompt: string,
    effort: "low" | "medium" | "high" | "max",
    context: PreparedContext
  ): Promise<ClaudeResponse> {
    return await this.client.messages.create({
      model: "claude-4.6-opus",
      max_tokens: this.getMaxTokensForEffort(effort),
      thinking: {
        type: "enabled",
        effort_level: effort,
      },
      messages: this.formatMessages(prompt, context),
    });
  }
}
```

### 4.6 NVIDIA NIM Integration for Local Inference

```typescript
interface NIMConfig {
  endpoint: string;
  models: string[];
  gpuAllocation: GPUAllocation;
  quantization: "fp16" | "int8" | "int4";
}

class NIMAdapter {
  private nvmlMonitor: NVMLMonitor;

  async invoke(
    prompt: string,
    model: string
  ): Promise<NIMResponse> {
    // Check GPU availability before inference
    const gpuStatus = await this.nvmlMonitor.getStatus();
    
    if (gpuStatus.memoryFree < this.getModelMemoryRequirement(model)) {
      throw new InsufficientResourcesError(
        `Insufficient VRAM for ${model}. Required: ${this.getModelMemoryRequirement(model)}GB, Available: ${gpuStatus.memoryFree}GB`
      );
    }

    return await this.nimClient.generate({
      model,
      prompt,
      stream: true,
    });
  }
}
```

---

## 5. Agent Framework Architecture

### 5.1 Agent Lifecycle

```
┌─────────────────────────────────────────────────────────────────┐
│                     AGENT LIFECYCLE                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐  │
│  │  INIT    │───▶│ PLANNING │───▶│ EXECUTE  │───▶│ VERIFY   │  │
│  └──────────┘    └──────────┘    └──────────┘    └──────────┘  │
│       │              │                │               │         │
│       │              ▼                ▼               │         │
│       │         ┌──────────┐    ┌──────────┐         │         │
│       │         │ APPROVAL │    │ ARTIFACT │         │         │
│       │         │ REQUIRED │    │ CREATION │         │         │
│       │         └──────────┘    └──────────┘         │         │
│       │              │                               │         │
│       │              ▼                               │         │
│       │         ┌──────────┐                         │         │
│       └────────▶│ COMPLETE │◀────────────────────────┘         │
│                 └──────────┘                                    │
│                      │                                          │
│                      ▼                                          │
│                 ┌──────────┐                                    │
│                 │ LEARNING │  (Update Knowledge Base)           │
│                 └──────────┘                                    │
└─────────────────────────────────────────────────────────────────┘
```

### 5.2 Agent Core Implementation

```typescript
interface Agent {
  id: string;
  name: string;
  status: AgentStatus;
  mission: Mission;
  workspace: WorkspaceContext;
  tools: AgentTool[];
  artifacts: Artifact[];
  knowledge: KnowledgeBase;
}

type AgentStatus = 
  | "idle"
  | "planning"
  | "awaiting_approval"
  | "executing"
  | "verifying"
  | "complete"
  | "error"
  | "paused";

interface Mission {
  id: string;
  goal: string;
  constraints: string[];
  successCriteria: string[];
  taskList: Task[];
  implementationPlan: ImplementationPlan;
  walkthrough: Walkthrough;
}

class AgentEngine {
  private agents: Map<string, Agent> = new Map();
  private neuralEngine: NeuralEngine;
  private toolExecutor: ToolExecutor;
  private artifactGenerator: ArtifactGenerator;

  async createAgent(mission: MissionInput): Promise<Agent> {
    const agent: Agent = {
      id: generateId(),
      name: mission.name || `Agent-${this.agents.size + 1}`,
      status: "idle",
      mission: await this.parseMission(mission),
      workspace: await this.createWorkspace(mission),
      tools: this.getDefaultTools(),
      artifacts: [],
      knowledge: await this.loadKnowledge(mission.workspace),
    };

    this.agents.set(agent.id, agent);
    return agent;
  }

  async executeMission(agentId: string): Promise<MissionResult> {
    const agent = this.agents.get(agentId);
    
    try {
      // Phase 1: Planning
      agent.status = "planning";
      const plan = await this.createPlan(agent);
      
      // Phase 2: Human Approval (if required)
      if (plan.requiresApproval) {
        agent.status = "awaiting_approval";
        await this.requestApproval(agent, plan);
      }
      
      // Phase 3: Execution
      agent.status = "executing";
      const results = await this.executeSteps(agent, plan);
      
      // Phase 4: Verification
      agent.status = "verifying";
      const verification = await this.verify(agent, results);
      
      // Phase 5: Learning
      await this.updateKnowledge(agent, results, verification);
      
      agent.status = "complete";
      return { success: true, artifacts: agent.artifacts };
      
    } catch (error) {
      agent.status = "error";
      return { success: false, error };
    }
  }
}
```

### 5.3 Artifact System

```typescript
interface Artifact {
  id: string;
  type: ArtifactType;
  content: string | Buffer;
  metadata: ArtifactMetadata;
  comments: Comment[];  // Interactive feedback
}

type ArtifactType = 
  | "task_list"           // task.md
  | "implementation_plan" // implementation_plan.md
  | "walkthrough"         // walkthrough.md
  | "screenshot"          // Visual proof
  | "video_recording"     // Browser session recording
  | "diff"                // Code changes
  | "test_results";       // Test output

interface ArtifactMetadata {
  createdAt: Date;
  agentId: string;
  missionId: string;
  step: number;
  verified: boolean;
}

class ArtifactGenerator {
  async generateTaskList(mission: Mission): Promise<Artifact> {
    const content = this.formatTaskList(mission.taskList);
    return {
      id: generateId(),
      type: "task_list",
      content,
      metadata: this.createMetadata(mission),
      comments: [],
    };
  }

  async generateImplementationPlan(
    mission: Mission,
    analysis: CodebaseAnalysis
  ): Promise<Artifact> {
    const plan = await this.neuralEngine.generatePlan(mission, analysis);
    return {
      id: generateId(),
      type: "implementation_plan",
      content: this.formatPlan(plan),
      metadata: this.createMetadata(mission),
      comments: [],
    };
  }

  async captureScreenshot(page: BrowserPage): Promise<Artifact> {
    const screenshot = await page.screenshot({ fullPage: true });
    return {
      id: generateId(),
      type: "screenshot",
      content: screenshot,
      metadata: this.createMetadata(page.mission),
      comments: [],
    };
  }
}
```

### 5.4 Agent Tools

```typescript
interface AgentTool {
  name: string;
  description: string;
  parameters: ToolParameter[];
  execute: (params: Record<string, unknown>) => Promise<ToolResult>;
  requiresApproval: boolean;
}

const defaultTools: AgentTool[] = [
  {
    name: "read_file",
    description: "Read contents of a file",
    parameters: [{ name: "path", type: "string", required: true }],
    execute: async ({ path }) => fs.readFile(path, "utf-8"),
    requiresApproval: false,
  },
  {
    name: "write_file",
    description: "Write content to a file",
    parameters: [
      { name: "path", type: "string", required: true },
      { name: "content", type: "string", required: true },
    ],
    execute: async ({ path, content }) => fs.writeFile(path, content),
    requiresApproval: false,
  },
  {
    name: "execute_terminal",
    description: "Execute a terminal command",
    parameters: [{ name: "command", type: "string", required: true }],
    execute: async ({ command }) => execAsync(command),
    requiresApproval: true,  // Requires human approval
  },
  {
    name: "browser_navigate",
    description: "Navigate browser to URL",
    parameters: [{ name: "url", type: "string", required: true }],
    execute: async ({ url }) => browserAgent.navigate(url),
    requiresApproval: false,
  },
  {
    name: "browser_click",
    description: "Click an element in the browser",
    parameters: [{ name: "selector", type: "string", required: true }],
    execute: async ({ selector }) => browserAgent.click(selector),
    requiresApproval: false,
  },
];
```

---

## 6. Hardware Monitoring & Resource Management

### 6.1 NVML Integration Architecture

```typescript
interface NVMLMetrics {
  gpuUtilization: number;        // 0-100%
  memoryUsed: number;            // Bytes
  memoryTotal: number;           // Bytes
  temperature: number;           // Celsius
  powerDraw: number;             // Watts
  powerLimit: number;            // Watts
  performanceState: PState;      // P0-P12
  eccErrors: ECCErrorCounts;
  processes: GPUProcess[];
}

type PState = "P0" | "P1" | "P2" | "P3" | "P4" | "P5" | "P6" | "P7" | "P8" | "P9" | "P10" | "P11" | "P12";

interface ECCErrorCounts {
  singleBit: number;
  doubleBit: number;
}

interface GPUProcess {
  pid: number;
  name: string;
  memoryUsed: number;
  computeUsage: number;
}
```

### 6.2 Resource Manager Implementation

```typescript
class ResourceManager {
  private nvml: NVMLBinding;
  private metrics: NVMLMetrics;
  private thresholds: ResourceThresholds;
  private agents: Map<string, Agent>;

  constructor() {
    this.thresholds = {
      maxGpuUtilization: 95,
      maxMemoryUsage: 0.9,  // 90%
      maxTemperature: 85,   // Celsius
      minFreeMemory: 4 * 1024 * 1024 * 1024,  // 4GB
    };
  }

  async startMonitoring(): Promise<void> {
    // Poll NVML every second
    setInterval(async () => {
      this.metrics = await this.collectMetrics();
      await this.enforceThresholds();
      this.broadcastMetrics();
    }, 1000);
  }

  private async collectMetrics(): Promise<NVMLMetrics> {
    const device = await this.nvml.getDevice(0);
    
    return {
      gpuUtilization: await device.getUtilization(),
      memoryUsed: await device.getMemoryUsed(),
      memoryTotal: await device.getMemoryTotal(),
      temperature: await device.getTemperature(),
      powerDraw: await device.getPowerUsage(),
      powerLimit: await device.getPowerLimit(),
      performanceState: await device.getPerformanceState(),
      eccErrors: await device.getECCErrors(),
      processes: await device.getRunningProcesses(),
    };
  }

  private async enforceThresholds(): Promise<void> {
    const { metrics, thresholds, agents } = this;

    // GPU Overload Protection
    if (metrics.gpuUtilization > thresholds.maxGpuUtilization) {
      await this.pauseLowestPriorityAgent();
      this.emitWarning("GPU utilization critical", metrics.gpuUtilization);
    }

    // Memory Protection (prevent OOM)
    const memoryUsageRatio = metrics.memoryUsed / metrics.memoryTotal;
    if (memoryUsageRatio > thresholds.maxMemoryUsage) {
      await this.preventNewAgentSpawns();
      this.emitWarning("VRAM usage critical", memoryUsageRatio);
    }

    // Thermal Throttling
    if (metrics.temperature > thresholds.maxTemperature) {
      await this.enableThrottling();
      this.emitWarning("GPU temperature critical", metrics.temperature);
    }

    // ECC Error Detection
    if (metrics.eccErrors.doubleBit > 0) {
      await this.alertHardwareInstability();
      this.emitCritical("ECC double-bit errors detected");
    }
  }

  canSpawnAgent(modelRequirements: ModelRequirements): boolean {
    const availableMemory = this.metrics.memoryTotal - this.metrics.memoryUsed;
    const requiredMemory = modelRequirements.vramRequired;
    
    return availableMemory > requiredMemory + this.thresholds.minFreeMemory;
  }
}
```

### 6.3 GPU Metrics Dashboard Component

```typescript
interface GPUDashboardProps {
  metrics: NVMLMetrics;
  onThresholdAlert: (alert: ThresholdAlert) => void;
}

// React component for Manager View
function GPUMetricsPanel({ metrics, onThresholdAlert }: GPUDashboardProps) {
  const memoryUsagePercent = (metrics.memoryUsed / metrics.memoryTotal) * 100;
  
  return (
    <div className="gpu-metrics-panel">
      <MetricGauge
        label="GPU Utilization"
        value={metrics.gpuUtilization}
        max={100}
        unit="%"
        warning={80}
        critical={95}
      />
      <MetricGauge
        label="VRAM Usage"
        value={memoryUsagePercent}
        max={100}
        unit="%"
        warning={75}
        critical={90}
        detail={`${formatBytes(metrics.memoryUsed)} / ${formatBytes(metrics.memoryTotal)}`}
      />
      <MetricGauge
        label="Temperature"
        value={metrics.temperature}
        max={100}
        unit="°C"
        warning={75}
        critical={85}
      />
      <MetricGauge
        label="Power Draw"
        value={metrics.powerDraw}
        max={metrics.powerLimit}
        unit="W"
        warning={metrics.powerLimit * 0.9}
        critical={metrics.powerLimit}
      />
      <PerformanceStateIndicator state={metrics.performanceState} />
      {metrics.eccErrors.doubleBit > 0 && (
        <ECCWarning errors={metrics.eccErrors} />
      )}
    </div>
  );
}
```

---

## 7. Browser Automation Subsystem

### 7.1 Browser Agent Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    BROWSER AGENT SUBSYSTEM                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                 Chrome DevTools Protocol                 │    │
│  │  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐    │    │
│  │  │ Page Control │ │ DOM Access   │ │ Network      │    │    │
│  │  └──────────────┘ └──────────────┘ └──────────────┘    │    │
│  └─────────────────────────────────────────────────────────┘    │
│                              │                                   │
│  ┌───────────────────────────┴───────────────────────────┐      │
│  │                  Browser Agent Core                    │      │
│  │  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐  │      │
│  │  │ Navigation   │ │ Interaction  │ │ Verification │  │      │
│  │  │ Controller   │ │ Engine       │ │ Engine       │  │      │
│  │  └──────────────┘ └──────────────┘ └──────────────┘  │      │
│  └───────────────────────────────────────────────────────┘      │
│                              │                                   │
│  ┌───────────────────────────┴───────────────────────────┐      │
│  │               Documentation Engine                     │      │
│  │  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐  │      │
│  │  │ Screenshot   │ │ Video        │ │ DOM Snapshot │  │      │
│  │  │ Capture      │ │ Recording    │ │ Archive      │  │      │
│  │  └──────────────┘ └──────────────┘ └──────────────┘  │      │
│  └───────────────────────────────────────────────────────┘      │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   Isolated Profile                       │    │
│  │   • Separate from user's main Chrome profile             │    │
│  │   • No access to cookies, history, or login data         │    │
│  │   • Sandboxed execution environment                      │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### 7.2 Browser Agent Implementation

```typescript
interface BrowserAgentConfig {
  isolatedProfile: boolean;
  headless: boolean;
  viewport: { width: number; height: number };
  allowedDomains: string[];
  blockedDomains: string[];
  recordVideo: boolean;
  screenshotOnAction: boolean;
}

class BrowserAgent {
  private browser: Browser;
  private page: Page;
  private recorder: VideoRecorder;
  private domainFilter: DomainFilter;

  async launch(config: BrowserAgentConfig): Promise<void> {
    // Launch Chrome with isolated profile
    this.browser = await chromium.launch({
      headless: config.headless,
      args: [
        `--user-data-dir=${this.createIsolatedProfile()}`,
        "--disable-extensions",
        "--disable-plugins",
      ],
    });

    this.page = await this.browser.newPage();
    await this.page.setViewportSize(config.viewport);

    if (config.recordVideo) {
      this.recorder = new VideoRecorder(this.page);
      await this.recorder.start();
    }

    this.domainFilter = new DomainFilter(
      config.allowedDomains,
      config.blockedDomains
    );
  }

  async navigate(url: string): Promise<NavigationResult> {
    // Validate domain against allow/deny lists
    if (!this.domainFilter.isAllowed(url)) {
      throw new DomainBlockedError(`Navigation to ${url} is blocked`);
    }

    await this.page.goto(url, { waitUntil: "networkidle" });
    
    return {
      url: this.page.url(),
      title: await this.page.title(),
      screenshot: await this.captureScreenshot(),
    };
  }

  async extractContent(selector?: string): Promise<DOMContent> {
    if (selector) {
      const element = await this.page.$(selector);
      return {
        html: await element.innerHTML(),
        text: await element.innerText(),
        attributes: await element.evaluate(el => 
          Object.fromEntries(el.getAttributeNames().map(n => [n, el.getAttribute(n)]))
        ),
      };
    }

    return {
      html: await this.page.content(),
      text: await this.page.innerText("body"),
    };
  }

  async interact(action: BrowserAction): Promise<InteractionResult> {
    const beforeScreenshot = await this.captureScreenshot();

    switch (action.type) {
      case "click":
        await this.page.click(action.selector);
        break;
      case "fill":
        await this.page.fill(action.selector, action.value);
        break;
      case "select":
        await this.page.selectOption(action.selector, action.value);
        break;
      case "hover":
        await this.page.hover(action.selector);
        break;
      case "scroll":
        await this.page.evaluate((y) => window.scrollTo(0, y), action.y);
        break;
    }

    await this.page.waitForLoadState("networkidle");
    const afterScreenshot = await this.captureScreenshot();

    return {
      success: true,
      before: beforeScreenshot,
      after: afterScreenshot,
      action,
    };
  }

  async verifyUI(expectations: UIExpectation[]): Promise<VerificationResult> {
    const results: ExpectationResult[] = [];

    for (const expectation of expectations) {
      const result = await this.checkExpectation(expectation);
      results.push(result);
    }

    // Use Gemini 3.1 Pro for visual verification
    const visualAnalysis = await this.neuralEngine.analyzeScreenshot(
      await this.captureScreenshot(),
      expectations
    );

    return {
      passed: results.every(r => r.passed) && visualAnalysis.passed,
      results,
      visualAnalysis,
      screenshot: await this.captureScreenshot(),
    };
  }

  async syncWithTerminal(
    terminalCommand: string,
    verification: () => Promise<boolean>
  ): Promise<SyncResult> {
    // Execute terminal command (e.g., restart dev server)
    await this.terminalAgent.execute(terminalCommand);

    // Wait for server to be ready
    await this.waitForServer();

    // Refresh browser
    await this.page.reload({ waitUntil: "networkidle" });

    // Verify the result
    const verified = await verification();

    return {
      success: verified,
      screenshot: await this.captureScreenshot(),
    };
  }
}
```

### 7.3 Visual Verification with Gemini 3.1 Pro

```typescript
class VisualVerificationEngine {
  private gemini: GeminiAdapter;

  async verifyUIChange(
    beforeScreenshot: Buffer,
    afterScreenshot: Buffer,
    expectedChange: string
  ): Promise<VisualVerificationResult> {
    const response = await this.gemini.analyzeImages({
      model: "gemini-3.1-pro",
      images: [
        { data: beforeScreenshot, label: "before" },
        { data: afterScreenshot, label: "after" },
      ],
      prompt: `
        Analyze these before/after screenshots and verify:
        Expected change: ${expectedChange}
        
        1. Did the expected change occur?
        2. Are there any visual regressions?
        3. Is the UI consistent and properly rendered?
        4. Are there any accessibility issues visible?
        
        Provide a detailed analysis with confidence scores.
      `,
    });

    return this.parseVerificationResponse(response);
  }

  async detectVisualRegressions(
    baselineScreenshot: Buffer,
    currentScreenshot: Buffer
  ): Promise<RegressionReport> {
    // Pixel-level comparison
    const pixelDiff = await this.comparePixels(baselineScreenshot, currentScreenshot);

    // AI-powered semantic comparison
    const semanticDiff = await this.gemini.analyzeImages({
      model: "gemini-3.1-pro",
      images: [
        { data: baselineScreenshot, label: "baseline" },
        { data: currentScreenshot, label: "current" },
      ],
      prompt: `
        Compare these screenshots for visual regressions.
        Identify any:
        - Layout shifts
        - Missing elements
        - Broken styles
        - Alignment issues
        - Color inconsistencies
        - Font rendering problems
      `,
    });

    return {
      pixelDiff,
      semanticDiff,
      regressions: this.extractRegressions(semanticDiff),
    };
  }
}
```

---

## 8. Security & Permission Model

### 8.1 Multi-Layer Security Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    SECURITY ARCHITECTURE                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Layer 1: User Authentication                                    │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  OAuth 2.0 / OIDC │ SAML 2.0 │ API Keys │ MFA          │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  Layer 2: Workspace Isolation                                    │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  • Agents confined to designated project folders         │    │
│  │  • No cross-workspace file access                        │    │
│  │  • Encrypted workspace storage                           │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  Layer 3: Terminal Command Policies                              │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  OFF    │ Never auto-execute any commands               │    │
│  │  AUTO   │ Auto-execute based on risk assessment         │    │
│  │  TURBO  │ Always auto-execute (high trust)              │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  Layer 4: Browser Domain Filtering                               │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  Allow List: localhost, *.company.com, docs.*           │    │
│  │  Deny List:  *.internal.*, sensitive-apps.*             │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  Layer 5: API & Model Access Control                             │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  • Rate limiting per user/agent                          │    │
│  │  • Token budget enforcement                              │    │
│  │  • Audit logging for all API calls                       │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  Layer 6: Data Protection                                        │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  • Encryption at rest (AES-256)                          │    │
│  │  • Encryption in transit (TLS 1.3)                       │    │
│  │  • Secret detection & masking                            │    │
│  │  • PII filtering in logs                                 │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### 8.2 Permission System Implementation

```typescript
interface PermissionConfig {
  terminal: TerminalPermissionLevel;
  fileSystem: FileSystemPermissions;
  browser: BrowserPermissions;
  network: NetworkPermissions;
  models: ModelPermissions;
}

type TerminalPermissionLevel = "off" | "auto" | "turbo";

interface FileSystemPermissions {
  allowedPaths: string[];
  deniedPaths: string[];
  readOnly: string[];
  maxFileSize: number;
}

interface BrowserPermissions {
  allowedDomains: string[];
  deniedDomains: string[];
  allowCookies: boolean;
  allowLocalStorage: boolean;
}

class PermissionManager {
  private config: PermissionConfig;
  private auditLog: AuditLogger;

  async checkPermission(
    action: AgentAction,
    agent: Agent
  ): Promise<PermissionResult> {
    const check = await this.evaluateAction(action, agent);
    
    // Log all permission checks
    await this.auditLog.log({
      timestamp: new Date(),
      agentId: agent.id,
      action,
      result: check,
    });

    if (check.requires === "approval") {
      return {
        allowed: false,
        requiresApproval: true,
        reason: check.reason,
      };
    }

    return {
      allowed: check.allowed,
      requiresApproval: false,
      reason: check.reason,
    };
  }

  private async evaluateAction(
    action: AgentAction,
    agent: Agent
  ): Promise<EvaluationResult> {
    switch (action.type) {
      case "terminal":
        return this.evaluateTerminalCommand(action.command);
      case "file_write":
        return this.evaluateFileWrite(action.path, agent.workspace);
      case "browser_navigate":
        return this.evaluateBrowserNavigation(action.url);
      case "api_call":
        return this.evaluateAPICall(action.endpoint);
      default:
        return { allowed: true };
    }
  }

  private evaluateTerminalCommand(command: string): EvaluationResult {
    const { terminal } = this.config;

    if (terminal === "off") {
      return { requires: "approval", reason: "Terminal execution disabled" };
    }

    if (terminal === "turbo") {
      return { allowed: true };
    }

    // "auto" mode - assess risk
    const risk = this.assessCommandRisk(command);
    
    if (risk.level === "high") {
      return {
        requires: "approval",
        reason: `High-risk command: ${risk.reason}`,
      };
    }

    return { allowed: true };
  }

  private assessCommandRisk(command: string): RiskAssessment {
    const highRiskPatterns = [
      /rm\s+-rf/,
      /sudo/,
      /chmod\s+777/,
      />\s*\/dev\//,
      /mkfs/,
      /dd\s+if=/,
      /curl.*\|\s*sh/,
      /wget.*\|\s*bash/,
    ];

    for (const pattern of highRiskPatterns) {
      if (pattern.test(command)) {
        return {
          level: "high",
          reason: `Matches dangerous pattern: ${pattern}`,
        };
      }
    }

    // Use AI to assess novel commands
    return this.aiRiskAssessment(command);
  }
}
```

### 8.3 Secret Detection & Protection

```typescript
class SecretProtector {
  private patterns: RegExp[] = [
    // API Keys
    /(?:api[_-]?key|apikey)['":\s]*['"]([\w-]{20,})['"]/gi,
    // AWS
    /AKIA[0-9A-Z]{16}/g,
    /(?:aws[_-]?secret)['":\s]*['"]([A-Za-z0-9/+=]{40})['"]/gi,
    // GitHub
    /ghp_[A-Za-z0-9]{36}/g,
    /gho_[A-Za-z0-9]{36}/g,
    // Generic secrets
    /(?:password|passwd|pwd|secret|token)['":\s]*['"]([^'"]{8,})['"]/gi,
    // Private keys
    /-----BEGIN (?:RSA |EC |DSA )?PRIVATE KEY-----/g,
  ];

  scan(content: string): SecretMatch[] {
    const matches: SecretMatch[] = [];

    for (const pattern of this.patterns) {
      let match;
      while ((match = pattern.exec(content)) !== null) {
        matches.push({
          type: this.classifySecret(pattern),
          position: match.index,
          length: match[0].length,
          masked: this.mask(match[0]),
        });
      }
    }

    return matches;
  }

  sanitize(content: string): string {
    let sanitized = content;
    const matches = this.scan(content);

    for (const match of matches.reverse()) {
      sanitized =
        sanitized.slice(0, match.position) +
        match.masked +
        sanitized.slice(match.position + match.length);
    }

    return sanitized;
  }

  private mask(secret: string): string {
    if (secret.length <= 8) return "***REDACTED***";
    return secret.slice(0, 4) + "***REDACTED***" + secret.slice(-4);
  }
}
```

---

## 9. API Gateway & Integration Layer

### 9.1 API Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      API GATEWAY                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   Rate Limiter                           │    │
│  │   • Per-user limits  • Per-model limits  • Burst control │    │
│  └─────────────────────────────────────────────────────────┘    │
│                              │                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                 Authentication Layer                     │    │
│  │   • JWT validation  • API key auth  • OAuth tokens       │    │
│  └─────────────────────────────────────────────────────────┘    │
│                              │                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   Request Router                         │    │
│  └─────────────────────────────────────────────────────────┘    │
│           │              │              │              │         │
│           ▼              ▼              ▼              ▼         │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌────────┐ │
│  │ Vertex AI    │ │ Anthropic    │ │ NVIDIA NIM   │ │ OpenAI │ │
│  │ (Gemini)     │ │ (Claude)     │ │ (Local LLMs) │ │ (GPT)  │ │
│  └──────────────┘ └──────────────┘ └──────────────┘ └────────┘ │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 9.2 Unified Model Interface

```typescript
interface UnifiedModelRequest {
  model: ModelIdentifier;
  messages: Message[];
  options: ModelOptions;
  stream?: boolean;
}

interface ModelOptions {
  maxTokens?: number;
  temperature?: number;
  topP?: number;
  stopSequences?: string[];
  // Claude-specific
  thinking?: ThinkingConfig;
  // Gemini-specific
  safetySettings?: SafetySettings;
}

type ModelIdentifier =
  | "gemini-3.1-pro"
  | "gemini-3-flash"
  | "gemini-3.1-flash-lite"
  | "claude-4.6-opus"
  | "claude-4.6-sonnet"
  | "claude-4.5-haiku"
  | "gpt-oss-120b"
  | "gemma-4-27b";

class ModelGateway {
  private adapters: Map<string, ModelAdapter>;
  private rateLimiter: RateLimiter;
  private cache: ResponseCache;

  async invoke(request: UnifiedModelRequest): Promise<ModelResponse> {
    // 1. Rate limit check
    await this.rateLimiter.checkLimit(request);

    // 2. Cache check (for deterministic requests)
    const cached = await this.cache.get(request);
    if (cached) return cached;

    // 3. Route to appropriate adapter
    const adapter = this.adapters.get(this.getProvider(request.model));

    // 4. Transform to provider-specific format
    const providerRequest = adapter.transformRequest(request);

    // 5. Execute request
    const response = await adapter.invoke(providerRequest);

    // 6. Transform to unified format
    const unifiedResponse = adapter.transformResponse(response);

    // 7. Cache response
    await this.cache.set(request, unifiedResponse);

    return unifiedResponse;
  }

  async invokeStream(
    request: UnifiedModelRequest
  ): AsyncGenerator<StreamChunk> {
    const adapter = this.adapters.get(this.getProvider(request.model));
    const providerRequest = adapter.transformRequest(request);

    for await (const chunk of adapter.invokeStream(providerRequest)) {
      yield adapter.transformStreamChunk(chunk);
    }
  }
}
```

### 9.3 Provider Adapters

```typescript
// Vertex AI / Gemini Adapter
class GeminiAdapter implements ModelAdapter {
  private client: VertexAI;

  transformRequest(request: UnifiedModelRequest): GeminiRequest {
    return {
      model: request.model,
      contents: request.messages.map(m => ({
        role: m.role === "assistant" ? "model" : m.role,
        parts: [{ text: m.content }],
      })),
      generationConfig: {
        maxOutputTokens: request.options.maxTokens,
        temperature: request.options.temperature,
        topP: request.options.topP,
        stopSequences: request.options.stopSequences,
      },
      safetySettings: request.options.safetySettings,
    };
  }

  async invoke(request: GeminiRequest): Promise<GeminiResponse> {
    const model = this.client.getGenerativeModel({ model: request.model });
    return await model.generateContent(request);
  }
}

// Anthropic / Claude Adapter
class ClaudeAdapter implements ModelAdapter {
  private client: Anthropic;

  transformRequest(request: UnifiedModelRequest): ClaudeRequest {
    return {
      model: request.model,
      max_tokens: request.options.maxTokens || 8192,
      messages: request.messages.map(m => ({
        role: m.role,
        content: m.content,
      })),
      thinking: request.options.thinking,
    };
  }

  async invoke(request: ClaudeRequest): Promise<ClaudeResponse> {
    return await this.client.messages.create(request);
  }
}

// NVIDIA NIM Adapter
class NIMAdapter implements ModelAdapter {
  private endpoint: string;
  private nvmlMonitor: NVMLMonitor;

  async invoke(request: NIMRequest): Promise<NIMResponse> {
    // Pre-flight GPU check
    const canRun = await this.nvmlMonitor.canRunModel(request.model);
    if (!canRun) {
      throw new InsufficientResourcesError("GPU resources unavailable");
    }

    return await fetch(`${this.endpoint}/v1/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    }).then(r => r.json());
  }
}
```

---

## 10. Data Persistence & Knowledge Management

### 10.1 Storage Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    DATA PERSISTENCE LAYER                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   Primary Database                       │    │
│  │   PostgreSQL / SQLite (per-workspace)                    │    │
│  │   • Users, Workspaces, Agents, Missions, Artifacts       │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   Vector Database                        │    │
│  │   pgvector / Pinecone / Weaviate                         │    │
│  │   • Code embeddings, documentation, conversation history │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   File-Based Config                      │    │
│  │   .agent/ directory                                      │    │
│  │   • rules/, workflows/, skills/, knowledge/              │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   Artifact Storage                       │    │
│  │   Object Storage (S3 / GCS / Local)                      │    │
│  │   • Screenshots, videos, large documents                 │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 10.2 Knowledge Base Schema

```typescript
// .agent/ directory structure
interface AgentConfigDirectory {
  rules: {
    // Always-active constraints
    "global.md": string;           // Global rules
    "typescript.md": string;       // TypeScript-specific rules
    "security.md": string;         // Security policies
  };
  workflows: {
    // User-triggered macros
    "test.yaml": WorkflowConfig;   // /test command
    "deploy.yaml": WorkflowConfig; // /deploy command
    "review.yaml": WorkflowConfig; // /review command
  };
  skills: {
    // Agent-triggered tools
    "database-query.yaml": SkillConfig;
    "api-integration.yaml": SkillConfig;
    "code-search.yaml": SkillConfig;
  };
  knowledge: {
    // Learned patterns and preferences
    "patterns.json": LearnedPatterns;
    "preferences.json": UserPreferences;
    "history.json": SuccessfulSolutions;
  };
}

interface WorkflowConfig {
  name: string;
  trigger: string;  // e.g., "/test"
  description: string;
  steps: WorkflowStep[];
}

interface SkillConfig {
  name: string;
  triggerPhrases: string[];  // Semantic triggers
  description: string;
  parameters: SkillParameter[];
  implementation: string;  // Code or reference
}

interface LearnedPatterns {
  codePatterns: {
    pattern: string;
    context: string;
    successRate: number;
    lastUsed: Date;
  }[];
  architecturalDecisions: {
    decision: string;
    reasoning: string;
    outcome: "success" | "failure";
    timestamp: Date;
  }[];
}
```

### 10.3 Knowledge Learning System

```typescript
class KnowledgeLearner {
  private knowledge: KnowledgeBase;
  private vectorStore: VectorDatabase;

  async learnFromMission(
    mission: CompletedMission,
    feedback: MissionFeedback
  ): Promise<void> {
    // 1. Extract successful patterns
    if (feedback.successful) {
      const patterns = await this.extractPatterns(mission);
      await this.knowledge.addPatterns(patterns);
    }

    // 2. Store architectural decisions
    const decisions = await this.extractDecisions(mission);
    await this.knowledge.addDecisions(decisions, feedback);

    // 3. Update code embeddings
    const codeChanges = mission.artifacts.filter(a => a.type === "diff");
    await this.vectorStore.upsert(
      codeChanges.map(change => ({
        id: change.id,
        vector: await this.embed(change.content),
        metadata: {
          type: "code_change",
          missionId: mission.id,
          successful: feedback.successful,
        },
      }))
    );

    // 4. Learn user preferences
    if (feedback.comments.length > 0) {
      await this.learnPreferences(feedback.comments);
    }
  }

  async retrieveRelevantKnowledge(
    task: AgentTask
  ): Promise<RelevantKnowledge> {
    // 1. Semantic search for similar past solutions
    const taskEmbedding = await this.embed(task.description);
    const similarSolutions = await this.vectorStore.search(taskEmbedding, {
      filter: { successful: true },
      limit: 5,
    });

    // 2. Retrieve applicable patterns
    const patterns = await this.knowledge.getPatterns(task.context);

    // 3. Get relevant rules
    const rules = await this.knowledge.getRules(task.fileTypes);

    return {
      similarSolutions,
      patterns,
      rules,
      preferences: await this.knowledge.getPreferences(),
    };
  }
}
```

---

## 11. Deployment Architecture

### 11.1 Deployment Options

```
┌─────────────────────────────────────────────────────────────────┐
│                   DEPLOYMENT ARCHITECTURE                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Option A: Desktop Application (Electron)                        │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │    │
│  │  │  Electron   │  │ Local Node  │  │ Local GPU   │      │    │
│  │  │  Shell      │  │ Backend     │  │ (NVML)      │      │    │
│  │  └─────────────┘  └─────────────┘  └─────────────┘      │    │
│  │                         │                                │    │
│  │                         ▼                                │    │
│  │              ┌─────────────────────┐                     │    │
│  │              │  Cloud Model APIs   │                     │    │
│  │              │  (Vertex, Anthropic)│                     │    │
│  │              └─────────────────────┘                     │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  Option B: Cloud-Hosted (Browser-Based)                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  ┌─────────────┐                    ┌─────────────┐     │    │
│  │  │  React SPA  │◀────WebSocket─────▶│  API Server │     │    │
│  │  │  (Browser)  │                    │  (K8s)      │     │    │
│  │  └─────────────┘                    └─────────────┘     │    │
│  │                                           │              │    │
│  │                    ┌──────────────────────┼────────┐    │    │
│  │                    ▼                      ▼        ▼    │    │
│  │              ┌──────────┐          ┌──────────┐ ┌─────┐│    │
│  │              │ Model    │          │ Agent    │ │ GPU ││    │
│  │              │ Gateway  │          │ Workers  │ │Nodes││    │
│  │              └──────────┘          └──────────┘ └─────┘│    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  Option C: Hybrid (Desktop + Cloud Compute)                      │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  ┌─────────────┐           ┌─────────────────────────┐  │    │
│  │  │  Desktop    │◀─────────▶│  Cloud Agent Workers    │  │    │
│  │  │  IDE Shell  │           │  (GPU Clusters)         │  │    │
│  │  └─────────────┘           └─────────────────────────┘  │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 11.2 Kubernetes Deployment (Cloud Option)

```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: antigravity-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: antigravity-api
  template:
    spec:
      containers:
        - name: api
          image: antigravity/api:latest
          ports:
            - containerPort: 8080
          env:
            - name: VERTEX_AI_PROJECT
              valueFrom:
                secretKeyRef:
                  name: model-credentials
                  key: vertex-project
            - name: ANTHROPIC_API_KEY
              valueFrom:
                secretKeyRef:
                  name: model-credentials
                  key: anthropic-key
          resources:
            requests:
              cpu: "2"
              memory: "8Gi"
            limits:
              cpu: "4"
              memory: "16Gi"

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: agent-worker
spec:
  replicas: 5
  selector:
    matchLabels:
      app: agent-worker
  template:
    spec:
      containers:
        - name: worker
          image: antigravity/agent-worker:latest
          resources:
            requests:
              cpu: "4"
              memory: "32Gi"
              nvidia.com/gpu: 1
            limits:
              cpu: "8"
              memory: "64Gi"
              nvidia.com/gpu: 1
      nodeSelector:
        cloud.google.com/gke-accelerator: nvidia-tesla-a100
```

---

## 12. Implementation Roadmap

### Phase 1: Foundation (Weeks 1-8)

| Week | Milestone | Deliverables |
|------|-----------|--------------|
| 1-2 | **IDE Core Setup** | Fork Code OSS, Electron shell, basic window management |
| 3-4 | **UI Bifurcation** | Editor View implementation, Manager View scaffold |
| 5-6 | **Agent Framework** | Agent lifecycle, basic tools, task decomposition |
| 7-8 | **Single Model Integration** | Gemini 3.1 Pro adapter, basic inference pipeline |

### Phase 2: Multi-Model Engine (Weeks 9-16)

| Week | Milestone | Deliverables |
|------|-----------|--------------|
| 9-10 | **Claude Integration** | Claude 4.6 adapter, adaptive thinking support |
| 11-12 | **Task Router** | Intelligent model selection, context management |
| 13-14 | **NVIDIA NIM** | Local inference support, NVML integration |
| 15-16 | **Context Controller** | 2M token management, compaction integration |

### Phase 3: Browser & Verification (Weeks 17-22)

| Week | Milestone | Deliverables |
|------|-----------|--------------|
| 17-18 | **Browser Agent Core** | CDP integration, navigation, DOM extraction |
| 19-20 | **Visual Verification** | Screenshot capture, video recording, visual AI |
| 21-22 | **Artifact System** | Task lists, implementation plans, walkthroughs |

### Phase 4: Security & Polish (Weeks 23-28)

| Week | Milestone | Deliverables |
|------|-----------|--------------|
| 23-24 | **Permission System** | Terminal policies, domain filtering, secret detection |
| 25-26 | **Knowledge System** | Learning from missions, pattern storage, preferences |
| 27-28 | **Production Hardening** | Performance optimization, error handling, logging |

### Phase 5: Enterprise Features (Weeks 29-36)

| Week | Milestone | Deliverables |
|------|-----------|--------------|
| 29-30 | **Team Collaboration** | Shared workspaces, agent handoff, audit trails |
| 31-32 | **Enterprise Auth** | SAML, OIDC, RBAC integration |
| 33-34 | **Deployment Options** | Desktop builds, cloud deployment, hybrid mode |
| 35-36 | **Documentation & Launch** | User guides, API docs, public beta |

---

## Appendix A: Technology Stack Summary

| Component | Primary Technology | Alternatives |
|-----------|-------------------|--------------|
| **IDE Shell** | Electron + Code OSS | Tauri |
| **UI Framework** | React 18 + TypeScript | Solid.js |
| **State Management** | Zustand | Redux Toolkit |
| **Model Gateway** | Custom Node.js | LangChain |
| **Database** | PostgreSQL + pgvector | SQLite + Chroma |
| **Browser Automation** | Playwright | Puppeteer |
| **GPU Monitoring** | NVML (native bindings) | nvidia-smi parsing |
| **Video Recording** | FFmpeg | MediaRecorder API |
| **Authentication** | NextAuth.js | Auth0 |
| **Deployment** | Kubernetes / Electron | Docker Compose |

---

## Appendix B: API Endpoint Reference

```typescript
// Core API Routes
POST   /api/agents              // Create new agent
GET    /api/agents/:id          // Get agent status
DELETE /api/agents/:id          // Terminate agent
POST   /api/agents/:id/mission  // Start mission
POST   /api/agents/:id/approve  // Approve pending action
POST   /api/agents/:id/reject   // Reject pending action

// Model API Routes
POST   /api/models/invoke       // Unified model invocation
POST   /api/models/stream       // Streaming invocation
GET    /api/models/status       // Model availability

// Artifact Routes
GET    /api/artifacts/:id       // Get artifact
POST   /api/artifacts/:id/comment // Add feedback

// Resource Routes
GET    /api/resources/gpu       // GPU metrics
GET    /api/resources/health    // System health

// Knowledge Routes
GET    /api/knowledge/search    // Semantic search
POST   /api/knowledge/learn     // Store learned pattern
```

---

*This architecture document provides the comprehensive blueprint for building a Google Antigravity-class agentic development environment. The design prioritizes model flexibility, hardware awareness, human-in-the-loop safety, and verifiable AI work products.*
