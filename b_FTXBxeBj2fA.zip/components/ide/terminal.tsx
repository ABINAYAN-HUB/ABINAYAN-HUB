"use client"

import { useState, useRef, useEffect } from "react"
import { X, Plus, ChevronDown, Terminal as TerminalIcon, AlertCircle, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"

interface TerminalProps {
  onClose: () => void
}

interface TerminalLine {
  type: 'input' | 'output' | 'error' | 'system'
  content: string
  timestamp: Date
}

const initialHistory: TerminalLine[] = [
  { type: 'system', content: 'Welcome to Antigravity IDE Terminal', timestamp: new Date() },
  { type: 'system', content: 'Type "help" for available commands', timestamp: new Date() },
  { type: 'input', content: '$ npm run dev', timestamp: new Date() },
  { type: 'output', content: '> antigravity-ide@1.0.0 dev', timestamp: new Date() },
  { type: 'output', content: '> next dev', timestamp: new Date() },
  { type: 'output', content: '', timestamp: new Date() },
  { type: 'system', content: '  ▲ Next.js 16.0.0', timestamp: new Date() },
  { type: 'system', content: '  - Local:        http://localhost:3000', timestamp: new Date() },
  { type: 'system', content: '  - Environments: .env.local', timestamp: new Date() },
  { type: 'output', content: '', timestamp: new Date() },
  { type: 'output', content: ' ✓ Ready in 1.2s', timestamp: new Date() },
]

const commands: Record<string, (args: string[]) => string[]> = {
  help: () => [
    'Available commands:',
    '  help          - Show this help message',
    '  clear         - Clear terminal',
    '  ls            - List files',
    '  pwd           - Print working directory',
    '  npm <cmd>     - Run npm command',
    '  ai <prompt>   - Generate with AI',
    '  model         - Show current AI model',
    '  models        - List available models',
  ],
  pwd: () => ['/home/user/antigravity-project'],
  ls: () => ['src/  api/  package.json  tsconfig.json  .env.local'],
  model: () => ['Current AI Model: Claude Opus 4 (Anthropic)'],
  models: () => [
    'Available AI Models:',
    '  claude-opus   - Claude Opus 4 (Anthropic) [Active]',
    '  gpt-5         - GPT-5 (OpenAI)',
    '  gemini-3      - Gemini 3 Pro (Google)',
    '  nvidia-nim    - NVIDIA NIM',
    '  llama-4       - Llama 4 (Meta)',
  ],
  npm: (args) => {
    if (args[0] === 'run' && args[1] === 'build') {
      return [
        '> antigravity-ide@1.0.0 build',
        '> next build',
        '',
        '  ▲ Next.js 16.0.0',
        '',
        '   Creating an optimized production build ...',
        ' ✓ Compiled successfully',
        ' ✓ Collecting page data',
        ' ✓ Generating static pages',
        ' ✓ Finalizing page optimization',
        '',
        'Route (app)                              Size     First Load JS',
        '┌ ○ /                                    5.2 kB         89.2 kB',
        '├ ○ /api/ai/generate                     0 B                0 B',
        '└ ○ /api/ai/models                       0 B                0 B',
        '',
        ' ✓ Build completed in 4.2s',
      ]
    }
    if (args[0] === 'install') {
      return [
        'added 245 packages in 8s',
        '',
        '42 packages are looking for funding',
        '  run `npm fund` for details',
      ]
    }
    return [`npm ${args.join(' ')}: command executed`]
  },
  ai: (args) => {
    const prompt = args.join(' ')
    if (!prompt) return ['Usage: ai <prompt>']
    return [
      `Generating with Claude Opus 4...`,
      '',
      `// AI Response for: "${prompt}"`,
      'function example() {',
      '  return "AI-generated code placeholder"',
      '}',
    ]
  },
}

export function Terminal({ onClose }: TerminalProps) {
  const [history, setHistory] = useState<TerminalLine[]>(initialHistory)
  const [input, setInput] = useState('')
  const [activeTab, setActiveTab] = useState('terminal')
  const inputRef = useRef<HTMLInputElement>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [history])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const newHistory: TerminalLine[] = [
      ...history,
      { type: 'input', content: `$ ${input}`, timestamp: new Date() }
    ]

    const [cmd, ...args] = input.trim().split(' ')

    if (cmd === 'clear') {
      setHistory([])
      setInput('')
      return
    }

    const handler = commands[cmd]
    if (handler) {
      const output = handler(args)
      output.forEach(line => {
        newHistory.push({ 
          type: 'output', 
          content: line, 
          timestamp: new Date() 
        })
      })
    } else {
      newHistory.push({ 
        type: 'error', 
        content: `Command not found: ${cmd}. Type "help" for available commands.`, 
        timestamp: new Date() 
      })
    }

    setHistory(newHistory)
    setInput('')
  }

  const getLineStyle = (type: TerminalLine['type']) => {
    switch (type) {
      case 'input': return 'text-accent'
      case 'error': return 'text-destructive'
      case 'system': return 'text-primary'
      default: return 'text-foreground'
    }
  }

  const problems = [
    { type: 'warning', file: 'ai-provider.tsx', line: 15, message: 'Missing return type on function' },
    { type: 'info', file: 'model-selector.tsx', line: 8, message: 'Consider using const assertion' },
  ]

  return (
    <div className="h-full flex flex-col bg-sidebar">
      <div className="h-9 flex items-center justify-between px-2 border-b border-border">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
          <TabsList className="h-full bg-transparent border-0 p-0">
            <TabsTrigger 
              value="terminal" 
              className="h-full px-3 text-xs data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
            >
              <TerminalIcon className="w-3.5 h-3.5 mr-1.5" />
              Terminal
            </TabsTrigger>
            <TabsTrigger 
              value="problems" 
              className="h-full px-3 text-xs data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
            >
              <AlertCircle className="w-3.5 h-3.5 mr-1.5" />
              Problems
              <span className="ml-1.5 px-1.5 py-0.5 text-[10px] bg-chart-3/20 text-chart-3 rounded">
                {problems.length}
              </span>
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="icon" 
            className="w-6 h-6 text-muted-foreground hover:text-foreground"
            onClick={() => setHistory([])}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="w-6 h-6 text-muted-foreground hover:text-foreground">
            <Plus className="w-3.5 h-3.5" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="w-6 h-6 text-muted-foreground hover:text-foreground"
            onClick={onClose}
          >
            <X className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {activeTab === 'terminal' && (
        <div className="flex-1 flex flex-col overflow-hidden">
          <ScrollArea className="flex-1" ref={scrollRef}>
            <div className="p-3 font-mono text-sm space-y-0.5">
              {history.map((line, i) => (
                <div key={i} className={cn("leading-5", getLineStyle(line.type))}>
                  {line.content || '\u00A0'}
                </div>
              ))}
            </div>
          </ScrollArea>

          <form onSubmit={handleSubmit} className="p-3 pt-0">
            <div className="flex items-center gap-2 font-mono text-sm">
              <span className="text-accent">$</span>
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 bg-transparent outline-none text-foreground placeholder:text-muted-foreground"
                placeholder="Type a command..."
                autoFocus
              />
            </div>
          </form>
        </div>
      )}

      {activeTab === 'problems' && (
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {problems.map((problem, i) => (
              <div 
                key={i}
                className="flex items-start gap-2 p-2 rounded hover:bg-secondary/50 cursor-pointer text-sm"
              >
                <AlertCircle className={cn(
                  "w-4 h-4 mt-0.5 shrink-0",
                  problem.type === 'warning' ? 'text-chart-3' : 'text-primary'
                )} />
                <div className="flex-1 min-w-0">
                  <p className="text-foreground">{problem.message}</p>
                  <p className="text-xs text-muted-foreground">
                    {problem.file}:{problem.line}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  )
}
