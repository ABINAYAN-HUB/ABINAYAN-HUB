"use client"

import { useState, useRef, useEffect } from "react"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { FileTab } from "./ide-layout"

interface CodeEditorProps {
  file: FileTab
  onChange: (content: string) => void
}

// Simple syntax highlighting tokens
const tokenize = (code: string, language: string) => {
  const tokens: { type: string; value: string }[] = []
  
  const keywords = ['import', 'export', 'from', 'const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'class', 'interface', 'type', 'async', 'await', 'try', 'catch', 'throw', 'new', 'this', 'default', 'extends', 'implements']
  const builtins = ['useState', 'useEffect', 'useContext', 'useCallback', 'useMemo', 'useRef', 'createContext', 'React', 'ReactDOM', 'console', 'fetch', 'Promise', 'Array', 'Object', 'String', 'Number', 'Boolean', 'JSON', 'Response', 'Request']
  const types = ['string', 'number', 'boolean', 'void', 'null', 'undefined', 'any', 'never', 'unknown', 'ReactNode', 'ReactElement', 'FC', 'Component']
  
  let remaining = code
  
  while (remaining.length > 0) {
    let matched = false
    
    // Comments
    if (remaining.startsWith('//')) {
      const end = remaining.indexOf('\n')
      const comment = end === -1 ? remaining : remaining.slice(0, end)
      tokens.push({ type: 'comment', value: comment })
      remaining = remaining.slice(comment.length)
      matched = true
    }
    // Multi-line comments
    else if (remaining.startsWith('/*')) {
      const end = remaining.indexOf('*/')
      const comment = end === -1 ? remaining : remaining.slice(0, end + 2)
      tokens.push({ type: 'comment', value: comment })
      remaining = remaining.slice(comment.length)
      matched = true
    }
    // Strings (double quotes)
    else if (remaining.startsWith('"')) {
      let i = 1
      while (i < remaining.length && remaining[i] !== '"') {
        if (remaining[i] === '\\') i++
        i++
      }
      const str = remaining.slice(0, i + 1)
      tokens.push({ type: 'string', value: str })
      remaining = remaining.slice(str.length)
      matched = true
    }
    // Strings (single quotes)
    else if (remaining.startsWith("'")) {
      let i = 1
      while (i < remaining.length && remaining[i] !== "'") {
        if (remaining[i] === '\\') i++
        i++
      }
      const str = remaining.slice(0, i + 1)
      tokens.push({ type: 'string', value: str })
      remaining = remaining.slice(str.length)
      matched = true
    }
    // Template literals
    else if (remaining.startsWith('`')) {
      let i = 1
      while (i < remaining.length && remaining[i] !== '`') {
        if (remaining[i] === '\\') i++
        i++
      }
      const str = remaining.slice(0, i + 1)
      tokens.push({ type: 'string', value: str })
      remaining = remaining.slice(str.length)
      matched = true
    }
    // Numbers
    else if (/^[0-9]/.test(remaining)) {
      const match = remaining.match(/^[0-9]+\.?[0-9]*/)
      if (match) {
        tokens.push({ type: 'number', value: match[0] })
        remaining = remaining.slice(match[0].length)
        matched = true
      }
    }
    // JSX tags
    else if (remaining.startsWith('<') && /^<\/?[A-Z]/.test(remaining)) {
      const match = remaining.match(/^<\/?[A-Za-z][A-Za-z0-9]*/)
      if (match) {
        tokens.push({ type: 'jsx-tag', value: match[0] })
        remaining = remaining.slice(match[0].length)
        matched = true
      }
    }
    // Identifiers and keywords
    else if (/^[a-zA-Z_$]/.test(remaining)) {
      const match = remaining.match(/^[a-zA-Z_$][a-zA-Z0-9_$]*/)
      if (match) {
        const word = match[0]
        if (keywords.includes(word)) {
          tokens.push({ type: 'keyword', value: word })
        } else if (builtins.includes(word)) {
          tokens.push({ type: 'builtin', value: word })
        } else if (types.includes(word)) {
          tokens.push({ type: 'type', value: word })
        } else if (/^[A-Z]/.test(word)) {
          tokens.push({ type: 'class', value: word })
        } else {
          tokens.push({ type: 'identifier', value: word })
        }
        remaining = remaining.slice(word.length)
        matched = true
      }
    }
    // Operators and punctuation
    else if (/^[+\-*/%=<>!&|^~?:;,.()\[\]{}]/.test(remaining)) {
      tokens.push({ type: 'punctuation', value: remaining[0] })
      remaining = remaining.slice(1)
      matched = true
    }
    
    if (!matched) {
      tokens.push({ type: 'text', value: remaining[0] })
      remaining = remaining.slice(1)
    }
  }
  
  return tokens
}

const getTokenClass = (type: string) => {
  switch (type) {
    case 'keyword': return 'text-[#c678dd]'
    case 'string': return 'text-[#98c379]'
    case 'number': return 'text-[#d19a66]'
    case 'comment': return 'text-[#5c6370] italic'
    case 'builtin': return 'text-[#61afef]'
    case 'type': return 'text-[#e5c07b]'
    case 'class': return 'text-[#e5c07b]'
    case 'jsx-tag': return 'text-[#e06c75]'
    case 'punctuation': return 'text-[#abb2bf]'
    default: return 'text-foreground'
  }
}

export function CodeEditor({ file, onChange }: CodeEditorProps) {
  const [cursorLine, setCursorLine] = useState(1)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const lines = file.content.split('\n')
  
  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange(e.target.value)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Tab') {
      e.preventDefault()
      const textarea = textareaRef.current
      if (textarea) {
        const start = textarea.selectionStart
        const end = textarea.selectionEnd
        const newValue = file.content.substring(0, start) + '  ' + file.content.substring(end)
        onChange(newValue)
        setTimeout(() => {
          textarea.selectionStart = textarea.selectionEnd = start + 2
        }, 0)
      }
    }
  }

  const updateCursorLine = () => {
    const textarea = textareaRef.current
    if (textarea) {
      const textBeforeCursor = file.content.substring(0, textarea.selectionStart)
      const line = textBeforeCursor.split('\n').length
      setCursorLine(line)
    }
  }

  return (
    <div className="h-full flex bg-background font-mono text-sm relative">
      {/* Line numbers */}
      <div className="w-14 bg-background border-r border-border flex-shrink-0 select-none">
        <ScrollArea className="h-full">
          <div className="py-4 pr-3 text-right">
            {lines.map((_, i) => (
              <div 
                key={i} 
                className={`leading-6 h-6 ${
                  cursorLine === i + 1 
                    ? 'text-foreground' 
                    : 'text-muted-foreground'
                }`}
              >
                {i + 1}
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>
      
      {/* Code area */}
      <div className="flex-1 relative overflow-hidden">
        <ScrollArea className="h-full">
          <div className="relative min-h-full">
            {/* Highlighted code display */}
            <div className="p-4 pointer-events-none whitespace-pre" aria-hidden="true">
              {lines.map((line, i) => (
                <div 
                  key={i} 
                  className={`leading-6 h-6 ${
                    cursorLine === i + 1 ? 'bg-secondary/30' : ''
                  }`}
                >
                  {tokenize(line, file.language).map((token, j) => (
                    <span key={j} className={getTokenClass(token.type)}>
                      {token.value}
                    </span>
                  ))}
                  {line === '' && '\u00A0'}
                </div>
              ))}
            </div>
            
            {/* Editable textarea overlay */}
            <textarea
              ref={textareaRef}
              value={file.content}
              onChange={handleTextareaChange}
              onKeyDown={handleKeyDown}
              onClick={updateCursorLine}
              onKeyUp={updateCursorLine}
              className="absolute inset-0 w-full h-full p-4 bg-transparent text-transparent caret-primary resize-none outline-none leading-6 font-mono text-sm"
              spellCheck={false}
              autoCapitalize="off"
              autoCorrect="off"
            />
          </div>
        </ScrollArea>
      </div>

      {/* Minimap */}
      <div className="w-20 bg-sidebar/50 border-l border-border hidden lg:block">
        <div className="p-2 scale-[0.15] origin-top-left w-[500px] pointer-events-none opacity-60">
          {lines.slice(0, 100).map((line, i) => (
            <div key={i} className="h-1 overflow-hidden whitespace-nowrap">
              {tokenize(line, file.language).map((token, j) => (
                <span key={j} className={getTokenClass(token.type)}>
                  {token.value}
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
