"use client"

import { 
  GitBranch, 
  AlertCircle, 
  AlertTriangle, 
  Bell, 
  Wifi,
  Check,
  Zap,
  Cloud
} from "lucide-react"
import { cn } from "@/lib/utils"
import type { FileTab } from "./ide-layout"

interface StatusBarProps {
  file?: FileTab
  aiModel: string
}

export function StatusBar({ file, aiModel }: StatusBarProps) {
  return (
    <div className="h-6 bg-primary flex items-center justify-between px-2 text-primary-foreground text-xs select-none">
      <div className="flex items-center gap-3">
        {/* Git branch */}
        <button className="flex items-center gap-1 hover:bg-white/10 px-1.5 py-0.5 rounded">
          <GitBranch className="w-3.5 h-3.5" />
          <span>main</span>
        </button>

        {/* Sync status */}
        <button className="flex items-center gap-1 hover:bg-white/10 px-1.5 py-0.5 rounded">
          <Cloud className="w-3.5 h-3.5" />
          <span>Synced</span>
        </button>

        {/* Errors and warnings */}
        <button className="flex items-center gap-2 hover:bg-white/10 px-1.5 py-0.5 rounded">
          <span className="flex items-center gap-1">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>0</span>
          </span>
          <span className="flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>2</span>
          </span>
        </button>
      </div>

      <div className="flex items-center gap-3">
        {/* AI Model indicator */}
        <button className="flex items-center gap-1.5 hover:bg-white/10 px-1.5 py-0.5 rounded bg-white/5">
          <Zap className="w-3.5 h-3.5 text-accent" />
          <span>{aiModel}</span>
        </button>

        {/* File info */}
        {file && (
          <>
            <span className="flex items-center gap-1">
              <span>Ln {1}, Col {1}</span>
            </span>
            <span>Spaces: 2</span>
            <span>UTF-8</span>
            <span>{file.language === 'typescript' ? 'TypeScript React' : file.language}</span>
          </>
        )}

        {/* Connection status */}
        <button className="flex items-center gap-1 hover:bg-white/10 px-1.5 py-0.5 rounded">
          <Wifi className="w-3.5 h-3.5" />
        </button>

        {/* Notifications */}
        <button className="flex items-center gap-1 hover:bg-white/10 px-1.5 py-0.5 rounded">
          <Bell className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  )
}
