"use client"

import { useState } from "react"
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable"
import { ActivityBar } from "./activity-bar"
import { FileExplorer } from "./file-explorer"
import { EditorTabs } from "./editor-tabs"
import { CodeEditor } from "./code-editor"
import { Terminal } from "./terminal"
import { AIAssistant } from "./ai-assistant"
import { StatusBar } from "./status-bar"
import { TitleBar } from "./title-bar"

export interface FileTab {
  id: string
  name: string
  path: string
  content: string
  language: string
  isModified: boolean
}

const initialFiles: FileTab[] = [
  {
    id: "1",
    name: "app.tsx",
    path: "/src/app.tsx",
    language: "typescript",
    isModified: false,
    content: `import { useState } from 'react'
import { AIProvider } from './providers/ai-provider'
import { ModelSelector } from './components/model-selector'

export default function App() {
  const [selectedModel, setSelectedModel] = useState('claude-opus')
  
  return (
    <AIProvider model={selectedModel}>
      <div className="min-h-screen bg-background">
        <header className="border-b px-6 py-4">
          <h1 className="text-2xl font-bold">Antigravity IDE</h1>
          <ModelSelector 
            value={selectedModel}
            onChange={setSelectedModel}
          />
        </header>
        <main className="container mx-auto py-8">
          {/* Your AI-powered application */}
        </main>
      </div>
    </AIProvider>
  )
}`
  },
  {
    id: "2", 
    name: "ai-provider.tsx",
    path: "/src/providers/ai-provider.tsx",
    language: "typescript",
    isModified: true,
    content: `import { createContext, useContext, ReactNode } from 'react'

interface AIContextType {
  model: string
  generateText: (prompt: string) => Promise<string>
  generateCode: (prompt: string) => Promise<string>
  analyzeCode: (code: string) => Promise<Analysis>
}

const AIContext = createContext<AIContextType | null>(null)

export function AIProvider({ 
  children, 
  model 
}: { 
  children: ReactNode
  model: string 
}) {
  const generateText = async (prompt: string) => {
    const response = await fetch('/api/ai/generate', {
      method: 'POST',
      body: JSON.stringify({ prompt, model }),
    })
    return response.json()
  }

  const generateCode = async (prompt: string) => {
    const response = await fetch('/api/ai/code', {
      method: 'POST', 
      body: JSON.stringify({ prompt, model }),
    })
    return response.json()
  }

  const analyzeCode = async (code: string) => {
    const response = await fetch('/api/ai/analyze', {
      method: 'POST',
      body: JSON.stringify({ code, model }),
    })
    return response.json()
  }

  return (
    <AIContext.Provider value={{ 
      model, 
      generateText, 
      generateCode, 
      analyzeCode 
    }}>
      {children}
    </AIContext.Provider>
  )
}

export const useAI = () => {
  const context = useContext(AIContext)
  if (!context) {
    throw new Error('useAI must be used within AIProvider')
  }
  return context
}`
  },
  {
    id: "3",
    name: "model-selector.tsx", 
    path: "/src/components/model-selector.tsx",
    language: "typescript",
    isModified: false,
    content: `import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

const AI_MODELS = [
  { id: 'claude-opus', name: 'Claude Opus 4', provider: 'Anthropic' },
  { id: 'gpt-5', name: 'GPT-5', provider: 'OpenAI' },
  { id: 'gemini-3', name: 'Gemini 3 Pro', provider: 'Google' },
  { id: 'nvidia-nim', name: 'NVIDIA NIM', provider: 'NVIDIA' },
  { id: 'llama-4', name: 'Llama 4', provider: 'Meta' },
]

interface ModelSelectorProps {
  value: string
  onChange: (value: string) => void
}

export function ModelSelector({ value, onChange }: ModelSelectorProps) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-[200px]">
        <SelectValue placeholder="Select AI Model" />
      </SelectTrigger>
      <SelectContent>
        {AI_MODELS.map((model) => (
          <SelectItem key={model.id} value={model.id}>
            <div className="flex items-center gap-2">
              <span>{model.name}</span>
              <span className="text-xs text-muted-foreground">
                {model.provider}
              </span>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}`
  }
]

export function IDELayout() {
  const [activePanel, setActivePanel] = useState<string>("explorer")
  const [openFiles, setOpenFiles] = useState<FileTab[]>(initialFiles)
  const [activeFileId, setActiveFileId] = useState<string>("1")
  const [terminalOpen, setTerminalOpen] = useState(true)
  const [aiPanelOpen, setAiPanelOpen] = useState(true)

  const activeFile = openFiles.find(f => f.id === activeFileId)

  const handleCloseFile = (fileId: string) => {
    const newFiles = openFiles.filter(f => f.id !== fileId)
    setOpenFiles(newFiles)
    if (activeFileId === fileId && newFiles.length > 0) {
      setActiveFileId(newFiles[0].id)
    }
  }

  const handleFileSelect = (file: { name: string; path: string; content: string }) => {
    const existingFile = openFiles.find(f => f.path === file.path)
    if (existingFile) {
      setActiveFileId(existingFile.id)
    } else {
      const newFile: FileTab = {
        id: Date.now().toString(),
        name: file.name,
        path: file.path,
        content: file.content,
        language: file.name.endsWith('.tsx') || file.name.endsWith('.ts') ? 'typescript' : 
                  file.name.endsWith('.css') ? 'css' : 
                  file.name.endsWith('.json') ? 'json' : 'text',
        isModified: false
      }
      setOpenFiles([...openFiles, newFile])
      setActiveFileId(newFile.id)
    }
  }

  const handleContentChange = (content: string) => {
    setOpenFiles(files => 
      files.map(f => 
        f.id === activeFileId 
          ? { ...f, content, isModified: true }
          : f
      )
    )
  }

  return (
    <div className="h-screen w-screen flex flex-col bg-background overflow-hidden">
      <TitleBar />
      
      <div className="flex-1 flex overflow-hidden">
        <ActivityBar 
          activePanel={activePanel} 
          onPanelChange={setActivePanel}
          onToggleTerminal={() => setTerminalOpen(!terminalOpen)}
          onToggleAI={() => setAiPanelOpen(!aiPanelOpen)}
        />
        
        <ResizablePanelGroup direction="horizontal" className="flex-1">
          {activePanel && (
            <>
              <ResizablePanel defaultSize={18} minSize={12} maxSize={30}>
                <FileExplorer onFileSelect={handleFileSelect} />
              </ResizablePanel>
              <ResizableHandle className="w-px bg-border hover:bg-primary/50 transition-colors" />
            </>
          )}
          
          <ResizablePanel defaultSize={aiPanelOpen ? 52 : 82}>
            <ResizablePanelGroup direction="vertical">
              <ResizablePanel defaultSize={terminalOpen ? 70 : 100}>
                <div className="h-full flex flex-col">
                  <EditorTabs 
                    files={openFiles}
                    activeFileId={activeFileId}
                    onFileSelect={setActiveFileId}
                    onFileClose={handleCloseFile}
                  />
                  <div className="flex-1 overflow-hidden">
                    {activeFile ? (
                      <CodeEditor 
                        file={activeFile}
                        onChange={handleContentChange}
                      />
                    ) : (
                      <div className="h-full flex items-center justify-center text-muted-foreground">
                        <div className="text-center space-y-4">
                          <div className="w-16 h-16 mx-auto rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                            <span className="text-2xl font-bold text-primary">AG</span>
                          </div>
                          <p>Open a file to start editing</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </ResizablePanel>
              
              {terminalOpen && (
                <>
                  <ResizableHandle className="h-px bg-border hover:bg-primary/50 transition-colors" />
                  <ResizablePanel defaultSize={30} minSize={15}>
                    <Terminal onClose={() => setTerminalOpen(false)} />
                  </ResizablePanel>
                </>
              )}
            </ResizablePanelGroup>
          </ResizablePanel>
          
          {aiPanelOpen && (
            <>
              <ResizableHandle className="w-px bg-border hover:bg-primary/50 transition-colors" />
              <ResizablePanel defaultSize={30} minSize={20} maxSize={45}>
                <AIAssistant onClose={() => setAiPanelOpen(false)} />
              </ResizablePanel>
            </>
          )}
        </ResizablePanelGroup>
      </div>
      
      <StatusBar 
        file={activeFile}
        aiModel="Claude Opus 4"
      />
    </div>
  )
}
