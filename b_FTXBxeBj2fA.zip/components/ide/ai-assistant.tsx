"use client"

import { useState, useRef, useEffect } from "react"
import { 
  X, 
  Send, 
  Sparkles, 
  Code, 
  FileText, 
  Bug, 
  Lightbulb,
  ChevronDown,
  Copy,
  Check,
  RotateCcw,
  Zap
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { cn } from "@/lib/utils"

interface AIAssistantProps {
  onClose: () => void
}

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
  model?: string
}

// Models organized by API key requirement
// NVIDIA NIM models all use NVIDIA_API_KEY
// Other providers use their own API keys

interface AIModel {
  id: string
  name: string
  provider: string
  category: 'nvidia-nim' | 'anthropic' | 'openai' | 'google' | 'meta' | 'mistral' | 'cohere' | 'xai' | 'deepseek' | 'alibaba'
  apiKeyEnv: string
  parameters?: string
  context?: string
  description?: string
}

const AI_MODELS: AIModel[] = [
  // ═══════════════════════════════════════════════════════════════
  // NVIDIA NIM MODELS (All use single NVIDIA_API_KEY)
  // ═══════════════════════════════════════════════════════════════
  
  // Llama Models on NVIDIA NIM
  { id: 'nim-llama-3.3-70b', name: 'Llama 3.3 70B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '70B', context: '128K', description: 'Meta Llama 3.3 optimized on NVIDIA' },
  { id: 'nim-llama-3.2-90b-vision', name: 'Llama 3.2 90B Vision', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '90B', context: '128K', description: 'Multimodal vision-language model' },
  { id: 'nim-llama-3.2-11b-vision', name: 'Llama 3.2 11B Vision', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '11B', context: '128K', description: 'Efficient vision-language model' },
  { id: 'nim-llama-3.1-405b', name: 'Llama 3.1 405B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '405B', context: '128K', description: 'Largest open Llama model' },
  { id: 'nim-llama-3.1-70b', name: 'Llama 3.1 70B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '70B', context: '128K', description: 'High-performance Llama model' },
  { id: 'nim-llama-3.1-8b', name: 'Llama 3.1 8B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '8B', context: '128K', description: 'Fast and efficient Llama model' },
  
  // Mistral Models on NVIDIA NIM
  { id: 'nim-mistral-large-2', name: 'Mistral Large 2', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '123B', context: '128K', description: 'Flagship Mistral model' },
  { id: 'nim-mistral-nemo', name: 'Mistral NeMo 12B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '12B', context: '128K', description: 'NVIDIA-Mistral collaboration' },
  { id: 'nim-mixtral-8x22b', name: 'Mixtral 8x22B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '176B MoE', context: '64K', description: 'Mixture of Experts model' },
  { id: 'nim-mixtral-8x7b', name: 'Mixtral 8x7B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '47B MoE', context: '32K', description: 'Efficient MoE model' },
  { id: 'nim-codestral', name: 'Codestral 22B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '22B', context: '32K', description: 'Code-specialized model' },
  
  // DeepSeek Models on NVIDIA NIM
  { id: 'nim-deepseek-r1', name: 'DeepSeek R1', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '671B MoE', context: '128K', description: 'Advanced reasoning model' },
  { id: 'nim-deepseek-r1-distill-llama-70b', name: 'DeepSeek R1 Distill 70B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '70B', context: '128K', description: 'Distilled reasoning model' },
  { id: 'nim-deepseek-r1-distill-qwen-32b', name: 'DeepSeek R1 Distill 32B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '32B', context: '128K', description: 'Compact reasoning model' },
  
  // Qwen Models on NVIDIA NIM
  { id: 'nim-qwen2.5-72b', name: 'Qwen 2.5 72B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '72B', context: '128K', description: 'Alibaba flagship model' },
  { id: 'nim-qwen2.5-coder-32b', name: 'Qwen 2.5 Coder 32B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '32B', context: '128K', description: 'Code-specialized Qwen' },
  { id: 'nim-qwq-32b', name: 'QwQ 32B Preview', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '32B', context: '32K', description: 'Experimental reasoning model' },
  
  // Google Models on NVIDIA NIM
  { id: 'nim-gemma-2-27b', name: 'Gemma 2 27B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '27B', context: '8K', description: 'Google open model' },
  { id: 'nim-gemma-2-9b', name: 'Gemma 2 9B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '9B', context: '8K', description: 'Efficient Google model' },
  { id: 'nim-gemma-2-2b', name: 'Gemma 2 2B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '2B', context: '8K', description: 'Lightweight Google model' },
  
  // Microsoft Models on NVIDIA NIM
  { id: 'nim-phi-3.5-moe', name: 'Phi 3.5 MoE', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '42B MoE', context: '128K', description: 'Microsoft MoE model' },
  { id: 'nim-phi-3.5-mini', name: 'Phi 3.5 Mini', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '3.8B', context: '128K', description: 'Compact Microsoft model' },
  { id: 'nim-phi-3-medium', name: 'Phi 3 Medium', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '14B', context: '128K', description: 'Balanced Microsoft model' },
  
  // IBM Models on NVIDIA NIM
  { id: 'nim-granite-3.1-8b', name: 'Granite 3.1 8B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '8B', context: '128K', description: 'IBM enterprise model' },
  { id: 'nim-granite-3.1-2b', name: 'Granite 3.1 2B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '2B', context: '128K', description: 'Lightweight IBM model' },
  { id: 'nim-granite-3-guardian-8b', name: 'Granite Guardian 8B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '8B', context: '8K', description: 'Safety-focused model' },
  
  // Specialized Models on NVIDIA NIM
  { id: 'nim-arctic-embed-l', name: 'Arctic Embed L', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '335M', description: 'Snowflake embeddings model' },
  { id: 'nim-nv-embed-v2', name: 'NV-Embed V2', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '7B', description: 'NVIDIA embeddings model' },
  { id: 'nim-llama-3.2-nv-embedqa', name: 'Llama EmbedQA', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '1B', description: 'QA embeddings model' },
  { id: 'nim-nv-rerankqa', name: 'NV-RerankQA', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '4B', description: 'Reranking model' },
  
  // NVIDIA Vision & Multimodal on NIM
  { id: 'nim-nvlm-d-72b', name: 'NVLM-D 72B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '72B', context: '4K', description: 'Vision-language model' },
  { id: 'nim-vila1.5-40b', name: 'VILA 1.5 40B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '40B', context: '4K', description: 'Video understanding model' },
  { id: 'nim-cosmos-predict1-7b', name: 'Cosmos Predict 7B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '7B', description: 'World foundation model' },
  
  // Healthcare Models on NVIDIA NIM
  { id: 'nim-llama-3.1-nemotron-70b', name: 'Nemotron 70B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '70B', context: '128K', description: 'NVIDIA custom Llama' },
  { id: 'nim-meditron-70b', name: 'Meditron 70B', provider: 'NVIDIA NIM', category: 'nvidia-nim', apiKeyEnv: 'NVIDIA_API_KEY', parameters: '70B', context: '4K', description: 'Medical domain model' },
  
  // ═══════════════════════════════════════════════════════════════
  // ANTHROPIC MODELS (Use ANTHROPIC_API_KEY)
  // ═══════════════════════════════════════════════════════════════
  { id: 'claude-opus-4', name: 'Claude Opus 4', provider: 'Anthropic', category: 'anthropic', apiKeyEnv: 'ANTHROPIC_API_KEY', parameters: 'N/A', context: '200K', description: 'Most capable Claude model' },
  { id: 'claude-sonnet-4', name: 'Claude Sonnet 4', provider: 'Anthropic', category: 'anthropic', apiKeyEnv: 'ANTHROPIC_API_KEY', parameters: 'N/A', context: '200K', description: 'Balanced performance' },
  { id: 'claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', provider: 'Anthropic', category: 'anthropic', apiKeyEnv: 'ANTHROPIC_API_KEY', parameters: 'N/A', context: '200K', description: 'Fast and intelligent' },
  { id: 'claude-3.5-haiku', name: 'Claude 3.5 Haiku', provider: 'Anthropic', category: 'anthropic', apiKeyEnv: 'ANTHROPIC_API_KEY', parameters: 'N/A', context: '200K', description: 'Fastest Claude model' },
  
  // ═══════════════════════════════════════════════════════════════
  // OPENAI MODELS (Use OPENAI_API_KEY)
  // ═══════════════════════════════════════════════════════════════
  { id: 'gpt-5', name: 'GPT-5', provider: 'OpenAI', category: 'openai', apiKeyEnv: 'OPENAI_API_KEY', parameters: 'N/A', context: '128K', description: 'Most advanced GPT model' },
  { id: 'gpt-4.1', name: 'GPT-4.1', provider: 'OpenAI', category: 'openai', apiKeyEnv: 'OPENAI_API_KEY', parameters: 'N/A', context: '1M', description: 'Extended context GPT-4' },
  { id: 'gpt-4o', name: 'GPT-4o', provider: 'OpenAI', category: 'openai', apiKeyEnv: 'OPENAI_API_KEY', parameters: 'N/A', context: '128K', description: 'Omni multimodal model' },
  { id: 'gpt-4o-mini', name: 'GPT-4o Mini', provider: 'OpenAI', category: 'openai', apiKeyEnv: 'OPENAI_API_KEY', parameters: 'N/A', context: '128K', description: 'Efficient GPT-4o variant' },
  { id: 'o1', name: 'o1', provider: 'OpenAI', category: 'openai', apiKeyEnv: 'OPENAI_API_KEY', parameters: 'N/A', context: '200K', description: 'Advanced reasoning model' },
  { id: 'o1-mini', name: 'o1 Mini', provider: 'OpenAI', category: 'openai', apiKeyEnv: 'OPENAI_API_KEY', parameters: 'N/A', context: '128K', description: 'Fast reasoning model' },
  { id: 'o3-mini', name: 'o3 Mini', provider: 'OpenAI', category: 'openai', apiKeyEnv: 'OPENAI_API_KEY', parameters: 'N/A', context: '200K', description: 'Latest reasoning model' },
  
  // ═══════════════════════════════════════════════════════════════
  // GOOGLE MODELS (Use GOOGLE_API_KEY)
  // ═══════════════════════════════════════════════════════════════
  { id: 'gemini-2.5-pro', name: 'Gemini 2.5 Pro', provider: 'Google', category: 'google', apiKeyEnv: 'GOOGLE_API_KEY', parameters: 'N/A', context: '1M', description: 'Most capable Gemini' },
  { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash', provider: 'Google', category: 'google', apiKeyEnv: 'GOOGLE_API_KEY', parameters: 'N/A', context: '1M', description: 'Fast Gemini model' },
  { id: 'gemini-2.0-flash', name: 'Gemini 2.0 Flash', provider: 'Google', category: 'google', apiKeyEnv: 'GOOGLE_API_KEY', parameters: 'N/A', context: '1M', description: 'Multimodal with tools' },
  { id: 'gemini-2.0-flash-lite', name: 'Gemini 2.0 Flash Lite', provider: 'Google', category: 'google', apiKeyEnv: 'GOOGLE_API_KEY', parameters: 'N/A', context: '1M', description: 'Lightweight Gemini' },
  
  // ═══════════════════════════════════════════════════════════════
  // META MODELS (Use META_API_KEY or hosted services)
  // ═══════════════════════════════════════════════════════════════
  { id: 'llama-4-maverick', name: 'Llama 4 Maverick', provider: 'Meta', category: 'meta', apiKeyEnv: 'META_API_KEY', parameters: '400B MoE', context: '1M', description: 'Flagship Llama 4 model' },
  { id: 'llama-4-scout', name: 'Llama 4 Scout', provider: 'Meta', category: 'meta', apiKeyEnv: 'META_API_KEY', parameters: '109B MoE', context: '10M', description: 'Long context Llama 4' },
  
  // ═══════════════════════════════════════════════════════════════
  // MISTRAL MODELS (Use MISTRAL_API_KEY)
  // ═══════════════════════════════════════════════════════════════
  { id: 'mistral-large', name: 'Mistral Large', provider: 'Mistral', category: 'mistral', apiKeyEnv: 'MISTRAL_API_KEY', parameters: '123B', context: '128K', description: 'Flagship Mistral model' },
  { id: 'mistral-medium', name: 'Mistral Medium', provider: 'Mistral', category: 'mistral', apiKeyEnv: 'MISTRAL_API_KEY', parameters: 'N/A', context: '32K', description: 'Balanced Mistral model' },
  { id: 'mistral-small', name: 'Mistral Small', provider: 'Mistral', category: 'mistral', apiKeyEnv: 'MISTRAL_API_KEY', parameters: '22B', context: '32K', description: 'Efficient Mistral model' },
  { id: 'pixtral-large', name: 'Pixtral Large', provider: 'Mistral', category: 'mistral', apiKeyEnv: 'MISTRAL_API_KEY', parameters: '124B', context: '128K', description: 'Multimodal Mistral' },
  { id: 'codestral-latest', name: 'Codestral', provider: 'Mistral', category: 'mistral', apiKeyEnv: 'MISTRAL_API_KEY', parameters: '22B', context: '32K', description: 'Code generation model' },
  
  // ═══════════════════════════════════════════════════════════════
  // XAI MODELS (Use XAI_API_KEY)
  // ═══════════════════════════════════════════════════════════════
  { id: 'grok-3', name: 'Grok 3', provider: 'xAI', category: 'xai', apiKeyEnv: 'XAI_API_KEY', parameters: 'N/A', context: '131K', description: 'Latest Grok model' },
  { id: 'grok-3-mini', name: 'Grok 3 Mini', provider: 'xAI', category: 'xai', apiKeyEnv: 'XAI_API_KEY', parameters: 'N/A', context: '131K', description: 'Efficient Grok model' },
  { id: 'grok-2', name: 'Grok 2', provider: 'xAI', category: 'xai', apiKeyEnv: 'XAI_API_KEY', parameters: 'N/A', context: '131K', description: 'Grok 2 model' },
  
  // ═══════════════════════════════════════════════════════════════
  // COHERE MODELS (Use COHERE_API_KEY)
  // ═══════════════════════════════════════════════════════════════
  { id: 'command-r-plus', name: 'Command R+', provider: 'Cohere', category: 'cohere', apiKeyEnv: 'COHERE_API_KEY', parameters: '104B', context: '128K', description: 'Enterprise RAG model' },
  { id: 'command-r', name: 'Command R', provider: 'Cohere', category: 'cohere', apiKeyEnv: 'COHERE_API_KEY', parameters: '35B', context: '128K', description: 'Scalable RAG model' },
  { id: 'command-a', name: 'Command A', provider: 'Cohere', category: 'cohere', apiKeyEnv: 'COHERE_API_KEY', parameters: '111B', context: '256K', description: 'Agentic model' },
  
  // ═══════════════════════════════════════════════════════════════
  // DEEPSEEK MODELS (Use DEEPSEEK_API_KEY)
  // ═══════════════════════════════════════════════════════════════
  { id: 'deepseek-v3', name: 'DeepSeek V3', provider: 'DeepSeek', category: 'deepseek', apiKeyEnv: 'DEEPSEEK_API_KEY', parameters: '671B MoE', context: '128K', description: 'Latest DeepSeek model' },
  { id: 'deepseek-r1-api', name: 'DeepSeek R1', provider: 'DeepSeek', category: 'deepseek', apiKeyEnv: 'DEEPSEEK_API_KEY', parameters: '671B MoE', context: '128K', description: 'Reasoning-focused model' },
  { id: 'deepseek-coder-v2.5', name: 'DeepSeek Coder V2.5', provider: 'DeepSeek', category: 'deepseek', apiKeyEnv: 'DEEPSEEK_API_KEY', parameters: '236B MoE', context: '128K', description: 'Code generation model' },
  
  // ═══════════════════════════════════════════════════════════════
  // ALIBABA MODELS (Use ALIBABA_API_KEY)
  // ═══════════════════════════════════════════════════════════════
  { id: 'qwen-max', name: 'Qwen Max', provider: 'Alibaba', category: 'alibaba', apiKeyEnv: 'ALIBABA_API_KEY', parameters: 'N/A', context: '32K', description: 'Flagship Qwen model' },
  { id: 'qwen-plus', name: 'Qwen Plus', provider: 'Alibaba', category: 'alibaba', apiKeyEnv: 'ALIBABA_API_KEY', parameters: 'N/A', context: '128K', description: 'Enhanced Qwen model' },
  { id: 'qwen-turbo', name: 'Qwen Turbo', provider: 'Alibaba', category: 'alibaba', apiKeyEnv: 'ALIBABA_API_KEY', parameters: 'N/A', context: '1M', description: 'Fast Qwen model' },
]

const PROVIDER_COLORS: Record<string, string> = {
  'nvidia-nim': 'bg-green-500',
  'anthropic': 'bg-orange-500',
  'openai': 'bg-emerald-500',
  'google': 'bg-blue-500',
  'meta': 'bg-blue-600',
  'mistral': 'bg-orange-400',
  'xai': 'bg-gray-500',
  'cohere': 'bg-purple-500',
  'deepseek': 'bg-cyan-500',
  'alibaba': 'bg-orange-600',
}

const CATEGORY_LABELS: Record<string, string> = {
  'nvidia-nim': 'NVIDIA NIM (Single API Key)',
  'anthropic': 'Anthropic',
  'openai': 'OpenAI',
  'google': 'Google',
  'meta': 'Meta',
  'mistral': 'Mistral AI',
  'xai': 'xAI',
  'cohere': 'Cohere',
  'deepseek': 'DeepSeek',
  'alibaba': 'Alibaba Cloud',
}

const quickActions = [
  { id: 'explain', icon: Lightbulb, label: 'Explain', prompt: 'Explain this code:' },
  { id: 'generate', icon: Code, label: 'Generate', prompt: 'Generate code for:' },
  { id: 'fix', icon: Bug, label: 'Fix Bug', prompt: 'Fix this bug:' },
  { id: 'document', icon: FileText, label: 'Document', prompt: 'Add documentation:' },
]

const sampleResponses: Record<string, string> = {
  'explain': `This code implements an AI Provider context for React applications.

**Key Components:**

1. **AIContext** - A React context that provides AI capabilities throughout your app

2. **AIProvider** - The provider component that:
   - Accepts a \`model\` prop to specify which AI model to use
   - Provides \`generateText\`, \`generateCode\`, and \`analyzeCode\` functions
   - Wraps your application to make AI features available

3. **useAI Hook** - A custom hook to access AI context from any component

**Usage Example:**
\`\`\`tsx
function MyComponent() {
  const { generateText, model } = useAI()
  
  const handleGenerate = async () => {
    const result = await generateText("Hello!")
    console.log(result)
  }
}
\`\`\`

The pattern follows React best practices for dependency injection and makes it easy to swap AI providers.`,

  'generate': `Here's the implementation you requested:

\`\`\`typescript
import { useState, useCallback } from 'react'
import { useAI } from '@/providers/ai-provider'

export function useAICompletion() {
  const [isLoading, setIsLoading] = useState(false)
  const [completion, setCompletion] = useState('')
  const [error, setError] = useState<Error | null>(null)
  const { generateText, model } = useAI()

  const complete = useCallback(async (prompt: string) => {
    setIsLoading(true)
    setError(null)
    
    try {
      const result = await generateText(prompt)
      setCompletion(result)
      return result
    } catch (err) {
      setError(err as Error)
      throw err
    } finally {
      setIsLoading(false)
    }
  }, [generateText])

  const reset = useCallback(() => {
    setCompletion('')
    setError(null)
  }, [])

  return { 
    complete, 
    completion, 
    isLoading, 
    error,
    reset,
    model 
  }
}
\`\`\`

This hook provides a clean interface for AI completions with loading states and error handling.`,

  'fix': `I found the issue! Here's the fix:

**Problem:** The context is not properly typed and can return \`null\`.

**Solution:**

\`\`\`diff
- const AIContext = createContext<AIContextType | null>(null)
+ const AIContext = createContext<AIContextType | undefined>(undefined)

export const useAI = () => {
  const context = useContext(AIContext)
- if (!context) {
+ if (context === undefined) {
    throw new Error('useAI must be used within an AIProvider')
  }
  return context
}
\`\`\`

**Additional Recommendations:**
1. Add proper TypeScript types for the API response
2. Add error boundaries for failed API calls
3. Consider adding retry logic for network failures`,

  'document': `Here's the documented version:

\`\`\`typescript
/**
 * AI Provider Context
 * 
 * Provides AI capabilities throughout the React component tree.
 * Supports multiple AI models including Claude, GPT, and Gemini.
 * 
 * @example
 * \`\`\`tsx
 * <AIProvider model="claude-opus">
 *   <App />
 * </AIProvider>
 * \`\`\`
 */

interface AIContextType {
  /** Currently selected AI model identifier */
  model: string
  
  /** 
   * Generate text completion from a prompt
   * @param prompt - The input prompt for text generation
   * @returns Promise resolving to generated text
   */
  generateText: (prompt: string) => Promise<string>
  
  /**
   * Generate code from a natural language description
   * @param prompt - Description of desired code
   * @returns Promise resolving to generated code string
   */
  generateCode: (prompt: string) => Promise<string>
  
  /**
   * Analyze code for issues, improvements, and explanations
   * @param code - The code to analyze
   * @returns Promise resolving to analysis results
   */
  analyzeCode: (code: string) => Promise<Analysis>
}
\`\`\`

Documentation has been added with JSDoc comments for better IDE support and developer experience.`,
}

export function AIAssistant({ onClose }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hello! I'm your AI coding assistant powered by multiple models. I can help you write, explain, debug, and document code. What would you like to work on?",
      timestamp: new Date(),
      model: 'claude-opus'
    }
  ])
  const [input, setInput] = useState('')
  const [selectedModel, setSelectedModel] = useState('claude-opus')
  const [isLoading, setIsLoading] = useState(false)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSend = async (customPrompt?: string) => {
    const prompt = customPrompt || input
    if (!prompt.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: prompt,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsLoading(true)

    // Simulate AI response
    setTimeout(() => {
      const actionType = quickActions.find(a => prompt.startsWith(a.prompt))?.id || 'explain'
      const responseContent = sampleResponses[actionType] || sampleResponses['explain']

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: responseContent,
        timestamp: new Date(),
        model: selectedModel
      }

      setMessages(prev => [...prev, assistantMessage])
      setIsLoading(false)
    }, 1500)
  }

  const handleQuickAction = (action: typeof quickActions[0]) => {
    setInput(action.prompt + ' ')
    textareaRef.current?.focus()
  }

  const handleCopy = async (content: string, id: string) => {
    await navigator.clipboard.writeText(content)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const currentModel = AI_MODELS.find(m => m.id === selectedModel)

  return (
    <div className="h-full flex flex-col bg-sidebar">
      {/* Header */}
      <div className="h-12 flex items-center justify-between px-4 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-gradient-to-br from-accent to-primary flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="font-medium text-sm">AI Assistant</span>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            className="w-7 h-7 text-muted-foreground hover:text-foreground"
            onClick={() => setMessages([messages[0]])}
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="w-7 h-7 text-muted-foreground hover:text-foreground"
            onClick={onClose}
          >
            <X className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* Model Selector */}
      <div className="px-4 py-3 border-b border-border">
        <Select value={selectedModel} onValueChange={setSelectedModel}>
          <SelectTrigger className="h-9 text-sm">
            <SelectValue>
              <div className="flex items-center gap-2">
                <span>{currentModel?.icon}</span>
                <span>{currentModel?.name}</span>
                <span className="text-xs text-muted-foreground">({currentModel?.provider})</span>
              </div>
            </SelectValue>
          </SelectTrigger>
          <SelectContent>
            {AI_MODELS.map(model => (
              <SelectItem key={model.id} value={model.id}>
                <div className="flex items-center gap-2">
                  <span>{model.icon}</span>
                  <span>{model.name}</span>
                  <span className="text-xs text-muted-foreground">({model.provider})</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-3 border-b border-border">
        <div className="flex flex-wrap gap-2">
          {quickActions.map(action => (
            <Button
              key={action.id}
              variant="outline"
              size="sm"
              className="h-7 text-xs gap-1.5"
              onClick={() => handleQuickAction(action)}
            >
              <action.icon className="w-3 h-3" />
              {action.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1" ref={scrollRef}>
        <div className="p-4 space-y-4">
          {messages.map(message => (
            <div
              key={message.id}
              className={cn(
                "flex gap-3",
                message.role === 'user' && "flex-row-reverse"
              )}
            >
              <div className={cn(
                "w-7 h-7 rounded-md flex items-center justify-center shrink-0",
                message.role === 'assistant' 
                  ? "bg-gradient-to-br from-accent to-primary" 
                  : "bg-secondary"
              )}>
                {message.role === 'assistant' ? (
                  <Sparkles className="w-3.5 h-3.5 text-white" />
                ) : (
                  <span className="text-xs font-medium">U</span>
                )}
              </div>
              <div className={cn(
                "flex-1 min-w-0",
                message.role === 'user' && "text-right"
              )}>
                <div className={cn(
                  "inline-block max-w-full text-sm rounded-lg p-3",
                  message.role === 'assistant' 
                    ? "bg-secondary text-left" 
                    : "bg-primary text-primary-foreground"
                )}>
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    {message.content.split('```').map((part, i) => {
                      if (i % 2 === 1) {
                        const [lang, ...codeLines] = part.split('\n')
                        const code = codeLines.join('\n')
                        return (
                          <div key={i} className="relative my-2 group">
                            <div className="flex items-center justify-between bg-background/50 px-3 py-1.5 rounded-t border border-b-0 border-border">
                              <span className="text-xs text-muted-foreground">{lang || 'code'}</span>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity"
                                onClick={() => handleCopy(code, message.id + i)}
                              >
                                {copiedId === message.id + i ? (
                                  <Check className="w-3 h-3 text-accent" />
                                ) : (
                                  <Copy className="w-3 h-3" />
                                )}
                              </Button>
                            </div>
                            <pre className="!mt-0 !rounded-t-none bg-background/50 p-3 overflow-x-auto border border-border">
                              <code className="text-xs">{code}</code>
                            </pre>
                          </div>
                        )
                      }
                      return <span key={i} className="whitespace-pre-wrap">{part}</span>
                    })}
                  </div>
                </div>
                {message.model && (
                  <p className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1">
                    <Zap className="w-2.5 h-2.5" />
                    {AI_MODELS.find(m => m.id === message.model)?.name}
                  </p>
                )}
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-md bg-gradient-to-br from-accent to-primary flex items-center justify-center">
                <Sparkles className="w-3.5 h-3.5 text-white animate-pulse" />
              </div>
              <div className="bg-secondary rounded-lg p-3">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t border-border">
        <div className="relative">
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask anything about your code..."
            className="min-h-[80px] pr-12 resize-none text-sm"
          />
          <Button
            size="icon"
            className="absolute bottom-2 right-2 w-8 h-8"
            onClick={() => handleSend()}
            disabled={!input.trim() || isLoading}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-[10px] text-muted-foreground mt-2 text-center">
          Press Enter to send, Shift+Enter for new line
        </p>
      </div>
    </div>
  )
}
