"use client"

import { 
  Files, 
  Search, 
  GitBranch, 
  Bug, 
  Blocks, 
  Settings, 
  User, 
  Sparkles,
  Terminal,
  Play
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { cn } from "@/lib/utils"

interface ActivityBarProps {
  activePanel: string
  onPanelChange: (panel: string) => void
  onToggleTerminal: () => void
  onToggleAI: () => void
}

const topItems = [
  { id: "explorer", icon: Files, label: "Explorer", shortcut: "Ctrl+Shift+E" },
  { id: "search", icon: Search, label: "Search", shortcut: "Ctrl+Shift+F" },
  { id: "git", icon: GitBranch, label: "Source Control", shortcut: "Ctrl+Shift+G" },
  { id: "debug", icon: Bug, label: "Run and Debug", shortcut: "Ctrl+Shift+D" },
  { id: "extensions", icon: Blocks, label: "Extensions", shortcut: "Ctrl+Shift+X" },
]

export function ActivityBar({ activePanel, onPanelChange, onToggleTerminal, onToggleAI }: ActivityBarProps) {
  return (
    <TooltipProvider delayDuration={300}>
      <div className="w-12 bg-sidebar border-r border-border flex flex-col items-center py-2">
        <div className="flex flex-col gap-1">
          {topItems.map((item) => (
            <Tooltip key={item.id}>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className={cn(
                    "w-10 h-10 text-muted-foreground hover:text-foreground relative",
                    activePanel === item.id && "text-foreground before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-0.5 before:h-6 before:bg-primary before:rounded-r"
                  )}
                  onClick={() => onPanelChange(activePanel === item.id ? "" : item.id)}
                >
                  <item.icon className="w-5 h-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right" className="flex items-center gap-2">
                <span>{item.label}</span>
                <span className="text-xs text-muted-foreground">{item.shortcut}</span>
              </TooltipContent>
            </Tooltip>
          ))}
        </div>

        <div className="flex-1" />

        <div className="flex flex-col gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-10 h-10 text-muted-foreground hover:text-foreground"
                onClick={onToggleTerminal}
              >
                <Terminal className="w-5 h-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="right">
              <span>Toggle Terminal</span>
              <span className="text-xs text-muted-foreground ml-2">Ctrl+`</span>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-10 h-10 text-accent hover:text-accent/80"
                onClick={onToggleAI}
              >
                <Sparkles className="w-5 h-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="right">
              <span>AI Assistant</span>
              <span className="text-xs text-muted-foreground ml-2">Ctrl+Shift+A</span>
            </TooltipContent>
          </Tooltip>

          <div className="w-6 h-px bg-border my-2 mx-auto" />

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-10 h-10 text-muted-foreground hover:text-foreground"
              >
                <User className="w-5 h-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="right">Account</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-10 h-10 text-muted-foreground hover:text-foreground"
              >
                <Settings className="w-5 h-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="right">Settings</TooltipContent>
          </Tooltip>
        </div>
      </div>
    </TooltipProvider>
  )
}
