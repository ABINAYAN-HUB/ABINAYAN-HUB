"use client"

import { useState } from "react"
import { 
  ChevronRight, 
  ChevronDown, 
  File, 
  Folder, 
  FolderOpen,
  MoreHorizontal,
  Plus,
  RefreshCw
} from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface FileNode {
  name: string
  type: "file" | "folder"
  path: string
  children?: FileNode[]
  content?: string
}

const fileTree: FileNode[] = [
  {
    name: "src",
    type: "folder",
    path: "/src",
    children: [
      {
        name: "components",
        type: "folder", 
        path: "/src/components",
        children: [
          { 
            name: "model-selector.tsx", 
            type: "file", 
            path: "/src/components/model-selector.tsx",
            content: `import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

const AI_MODELS = [
  { id: 'claude-opus', name: 'Claude Opus 4', provider: 'Anthropic' },
  { id: 'gpt-5', name: 'GPT-5', provider: 'OpenAI' },
  { id: 'gemini-3', name: 'Gemini 3 Pro', provider: 'Google' },
  { id: 'nvidia-nim', name: 'NVIDIA NIM', provider: 'NVIDIA' },
]

export function ModelSelector({ value, onChange }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-[200px]">
        <SelectValue placeholder="Select AI Model" />
      </SelectTrigger>
      <SelectContent>
        {AI_MODELS.map((model) => (
          <SelectItem key={model.id} value={model.id}>
            {model.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}`
          },
          { 
            name: "chat-interface.tsx", 
            type: "file", 
            path: "/src/components/chat-interface.tsx",
            content: `"use client"

import { useState } from 'react'
import { useAI } from '@/providers/ai-provider'

export function ChatInterface() {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const { generateText } = useAI()

  const handleSend = async () => {
    if (!input.trim()) return
    
    const userMessage = { role: 'user', content: input }
    setMessages(prev => [...prev, userMessage])
    setInput('')

    const response = await generateText(input)
    setMessages(prev => [...prev, { role: 'assistant', content: response }])
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, i) => (
          <div key={i} className={\`p-3 rounded-lg \${
            msg.role === 'user' ? 'bg-primary/10 ml-8' : 'bg-muted mr-8'
          }\`}>
            {msg.content}
          </div>
        ))}
      </div>
      <div className="p-4 border-t">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Type a message..."
          className="w-full px-4 py-2 rounded-lg border"
        />
      </div>
    </div>
  )
}`
          },
          { 
            name: "code-viewer.tsx", 
            type: "file", 
            path: "/src/components/code-viewer.tsx",
            content: `export function CodeViewer({ code, language }) {
  return (
    <pre className="p-4 rounded-lg bg-muted overflow-x-auto">
      <code className={\`language-\${language}\`}>
        {code}
      </code>
    </pre>
  )
}`
          },
        ]
      },
      {
        name: "providers",
        type: "folder",
        path: "/src/providers",
        children: [
          { 
            name: "ai-provider.tsx", 
            type: "file", 
            path: "/src/providers/ai-provider.tsx",
            content: `import { createContext, useContext } from 'react'

const AIContext = createContext(null)

export function AIProvider({ children, model }) {
  const generateText = async (prompt) => {
    const response = await fetch('/api/ai/generate', {
      method: 'POST',
      body: JSON.stringify({ prompt, model }),
    })
    return response.json()
  }

  return (
    <AIContext.Provider value={{ model, generateText }}>
      {children}
    </AIContext.Provider>
  )
}

export const useAI = () => useContext(AIContext)`
          },
        ]
      },
      {
        name: "hooks",
        type: "folder",
        path: "/src/hooks",
        children: [
          { 
            name: "use-ai-completion.ts", 
            type: "file", 
            path: "/src/hooks/use-ai-completion.ts",
            content: `import { useState, useCallback } from 'react'
import { useAI } from '@/providers/ai-provider'

export function useAICompletion() {
  const [isLoading, setIsLoading] = useState(false)
  const [completion, setCompletion] = useState('')
  const { generateText } = useAI()

  const complete = useCallback(async (prompt: string) => {
    setIsLoading(true)
    try {
      const result = await generateText(prompt)
      setCompletion(result)
      return result
    } finally {
      setIsLoading(false)
    }
  }, [generateText])

  return { complete, completion, isLoading }
}`
          },
        ]
      },
      { 
        name: "app.tsx", 
        type: "file", 
        path: "/src/app.tsx",
        content: `import { AIProvider } from './providers/ai-provider'

export default function App() {
  return (
    <AIProvider model="claude-opus">
      <div className="min-h-screen">
        <h1>Antigravity IDE</h1>
      </div>
    </AIProvider>
  )
}`
      },
      { 
        name: "main.tsx", 
        type: "file", 
        path: "/src/main.tsx",
        content: `import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './app'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)`
      },
      { 
        name: "index.css", 
        type: "file", 
        path: "/src/index.css",
        content: `@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  --background: #0a0a0f;
  --foreground: #e5e5e5;
}`
      },
    ]
  },
  {
    name: "api",
    type: "folder",
    path: "/api",
    children: [
      {
        name: "ai",
        type: "folder",
        path: "/api/ai",
        children: [
          { 
            name: "generate.ts", 
            type: "file", 
            path: "/api/ai/generate.ts",
            content: `import { NextRequest } from 'next/server'

export async function POST(req: NextRequest) {
  const { prompt, model } = await req.json()
  
  // Route to appropriate AI provider
  const providers = {
    'claude-opus': 'https://api.anthropic.com/v1/messages',
    'gpt-5': 'https://api.openai.com/v1/chat/completions',
    'gemini-3': 'https://generativelanguage.googleapis.com/v1/models',
    'nvidia-nim': 'https://api.nvidia.com/nim/v1/generate',
  }

  const response = await fetch(providers[model], {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt }),
  })

  return Response.json(await response.json())
}`
          },
          { 
            name: "models.ts", 
            type: "file", 
            path: "/api/ai/models.ts",
            content: `export const AI_MODELS = {
  'claude-opus': {
    name: 'Claude Opus 4',
    provider: 'Anthropic',
    maxTokens: 200000,
    capabilities: ['text', 'code', 'analysis', 'vision']
  },
  'gpt-5': {
    name: 'GPT-5',
    provider: 'OpenAI', 
    maxTokens: 128000,
    capabilities: ['text', 'code', 'analysis', 'vision', 'audio']
  },
  'gemini-3': {
    name: 'Gemini 3 Pro',
    provider: 'Google',
    maxTokens: 1000000,
    capabilities: ['text', 'code', 'analysis', 'vision', 'multimodal']
  },
  'nvidia-nim': {
    name: 'NVIDIA NIM',
    provider: 'NVIDIA',
    maxTokens: 32000,
    capabilities: ['text', 'code', 'inference']
  }
}`
          },
        ]
      },
    ]
  },
  { 
    name: "package.json", 
    type: "file", 
    path: "/package.json",
    content: `{
  "name": "antigravity-ide",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  },
  "dependencies": {
    "next": "^16.0.0",
    "react": "^19.0.0",
    "ai": "^6.0.0",
    "@ai-sdk/anthropic": "^1.0.0",
    "@ai-sdk/openai": "^1.0.0"
  }
}`
  },
  { 
    name: "tsconfig.json", 
    type: "file", 
    path: "/tsconfig.json",
    content: `{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["dom", "ES2022"],
    "jsx": "preserve",
    "strict": true,
    "module": "ESNext",
    "moduleResolution": "bundler",
    "paths": {
      "@/*": ["./*"]
    }
  }
}`
  },
  { 
    name: ".env.local", 
    type: "file", 
    path: "/.env.local",
    content: `ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
GOOGLE_AI_API_KEY=...
NVIDIA_API_KEY=nvapi-...`
  },
]

interface FileExplorerProps {
  onFileSelect: (file: { name: string; path: string; content: string }) => void
}

export function FileExplorer({ onFileSelect }: FileExplorerProps) {
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(
    new Set(["/src", "/src/components", "/api", "/api/ai"])
  )

  const toggleFolder = (path: string) => {
    setExpandedFolders(prev => {
      const next = new Set(prev)
      if (next.has(path)) {
        next.delete(path)
      } else {
        next.add(path)
      }
      return next
    })
  }

  const getFileIcon = (name: string) => {
    if (name.endsWith('.tsx') || name.endsWith('.ts')) {
      return <span className="text-[#3178c6] text-xs font-bold">TS</span>
    }
    if (name.endsWith('.css')) {
      return <span className="text-[#563d7c] text-xs font-bold">CSS</span>
    }
    if (name.endsWith('.json')) {
      return <span className="text-[#cbcb41] text-xs font-bold">{'{}'}</span>
    }
    return <File className="w-4 h-4 text-muted-foreground" />
  }

  const renderNode = (node: FileNode, depth: number = 0) => {
    const isExpanded = expandedFolders.has(node.path)
    const paddingLeft = depth * 12 + 8

    if (node.type === "folder") {
      return (
        <div key={node.path}>
          <button
            className="w-full flex items-center gap-1 py-1 px-2 hover:bg-secondary/50 text-sm text-foreground"
            style={{ paddingLeft }}
            onClick={() => toggleFolder(node.path)}
          >
            {isExpanded ? (
              <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
            ) : (
              <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
            )}
            {isExpanded ? (
              <FolderOpen className="w-4 h-4 text-primary shrink-0" />
            ) : (
              <Folder className="w-4 h-4 text-primary shrink-0" />
            )}
            <span className="truncate">{node.name}</span>
          </button>
          {isExpanded && node.children && (
            <div>
              {node.children.map(child => renderNode(child, depth + 1))}
            </div>
          )}
        </div>
      )
    }

    return (
      <button
        key={node.path}
        className="w-full flex items-center gap-2 py-1 px-2 hover:bg-secondary/50 text-sm text-muted-foreground hover:text-foreground"
        style={{ paddingLeft: paddingLeft + 20 }}
        onClick={() => onFileSelect({ 
          name: node.name, 
          path: node.path, 
          content: node.content || '' 
        })}
      >
        {getFileIcon(node.name)}
        <span className="truncate">{node.name}</span>
      </button>
    )
  }

  return (
    <div className="h-full bg-sidebar flex flex-col">
      <div className="h-9 flex items-center justify-between px-4 border-b border-border">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          Explorer
        </span>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="w-6 h-6 text-muted-foreground hover:text-foreground">
            <Plus className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="w-6 h-6 text-muted-foreground hover:text-foreground">
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="px-2 py-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-foreground uppercase mb-1 px-2">
          <ChevronDown className="w-3 h-3" />
          antigravity-project
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="pb-4">
          {fileTree.map(node => renderNode(node))}
        </div>
      </ScrollArea>
    </div>
  )
}
