"use client"

import { 
  Settings, 
  Search, 
  Maximize2,
  Minus,
  X,
  ChevronDown
} from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from "@/components/ui/dropdown-menu"

const menuItems = [
  {
    label: "File",
    items: [
      { label: "New File", shortcut: "Ctrl+N" },
      { label: "New Window", shortcut: "Ctrl+Shift+N" },
      { type: "separator" as const },
      { label: "Open File...", shortcut: "Ctrl+O" },
      { label: "Open Folder...", shortcut: "Ctrl+K Ctrl+O" },
      { type: "separator" as const },
      { label: "Save", shortcut: "Ctrl+S" },
      { label: "Save As...", shortcut: "Ctrl+Shift+S" },
      { type: "separator" as const },
      { label: "Exit" },
    ]
  },
  {
    label: "Edit",
    items: [
      { label: "Undo", shortcut: "Ctrl+Z" },
      { label: "Redo", shortcut: "Ctrl+Y" },
      { type: "separator" as const },
      { label: "Cut", shortcut: "Ctrl+X" },
      { label: "Copy", shortcut: "Ctrl+C" },
      { label: "Paste", shortcut: "Ctrl+V" },
      { type: "separator" as const },
      { label: "Find", shortcut: "Ctrl+F" },
      { label: "Replace", shortcut: "Ctrl+H" },
    ]
  },
  {
    label: "View",
    items: [
      { label: "Command Palette...", shortcut: "Ctrl+Shift+P" },
      { type: "separator" as const },
      { label: "Explorer", shortcut: "Ctrl+Shift+E" },
      { label: "Search", shortcut: "Ctrl+Shift+F" },
      { label: "AI Assistant", shortcut: "Ctrl+Shift+A" },
      { type: "separator" as const },
      { label: "Terminal", shortcut: "Ctrl+`" },
      { label: "Problems", shortcut: "Ctrl+Shift+M" },
    ]
  },
  {
    label: "AI",
    items: [
      { label: "Generate Code", shortcut: "Ctrl+K" },
      { label: "Explain Selection", shortcut: "Ctrl+Shift+E" },
      { label: "Fix Code", shortcut: "Ctrl+Shift+F" },
      { type: "separator" as const },
      { label: "Switch Model..." },
      { 
        label: "Models",
        submenu: [
          { label: "Claude Opus 4" },
          { label: "GPT-5" },
          { label: "Gemini 3 Pro" },
          { label: "NVIDIA NIM" },
        ]
      },
    ]
  },
  {
    label: "Help",
    items: [
      { label: "Documentation" },
      { label: "Keyboard Shortcuts", shortcut: "Ctrl+K Ctrl+S" },
      { type: "separator" as const },
      { label: "About Antigravity" },
    ]
  },
]

export function TitleBar() {
  return (
    <div className="h-9 bg-sidebar border-b border-border flex items-center justify-between px-2 select-none">
      <div className="flex items-center gap-1">
        <div className="w-6 h-6 rounded-md bg-gradient-to-br from-primary to-accent flex items-center justify-center mr-2">
          <span className="text-[10px] font-bold text-primary-foreground">AG</span>
        </div>
        
        {menuItems.map((menu) => (
          <DropdownMenu key={menu.label}>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-6 px-2 text-xs text-muted-foreground hover:text-foreground hover:bg-secondary"
              >
                {menu.label}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="min-w-[200px]">
              {menu.items.map((item, index) => {
                if (item.type === "separator") {
                  return <DropdownMenuSeparator key={index} />
                }
                if ('submenu' in item && item.submenu) {
                  return (
                    <DropdownMenuSub key={item.label}>
                      <DropdownMenuSubTrigger>{item.label}</DropdownMenuSubTrigger>
                      <DropdownMenuSubContent>
                        {item.submenu.map((subItem) => (
                          <DropdownMenuItem key={subItem.label}>
                            {subItem.label}
                          </DropdownMenuItem>
                        ))}
                      </DropdownMenuSubContent>
                    </DropdownMenuSub>
                  )
                }
                return (
                  <DropdownMenuItem key={item.label} className="flex justify-between">
                    <span>{item.label}</span>
                    {'shortcut' in item && item.shortcut && (
                      <span className="text-xs text-muted-foreground ml-4">{item.shortcut}</span>
                    )}
                  </DropdownMenuItem>
                )
              })}
            </DropdownMenuContent>
          </DropdownMenu>
        ))}
      </div>

      <div className="flex-1 flex items-center justify-center">
        <Button 
          variant="ghost" 
          className="h-6 px-3 text-xs text-muted-foreground hover:text-foreground bg-secondary/50 rounded-md gap-2 min-w-[300px] justify-start"
        >
          <Search className="w-3 h-3" />
          <span>Antigravity IDE - app.tsx</span>
          <span className="ml-auto text-[10px] opacity-60">Ctrl+P</span>
        </Button>
      </div>

      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon" className="w-6 h-6 text-muted-foreground hover:text-foreground">
          <Settings className="w-3.5 h-3.5" />
        </Button>
        <div className="w-px h-4 bg-border mx-1" />
        <Button variant="ghost" size="icon" className="w-8 h-6 text-muted-foreground hover:text-foreground hover:bg-secondary">
          <Minus className="w-3 h-3" />
        </Button>
        <Button variant="ghost" size="icon" className="w-8 h-6 text-muted-foreground hover:text-foreground hover:bg-secondary">
          <Maximize2 className="w-3 h-3" />
        </Button>
        <Button variant="ghost" size="icon" className="w-8 h-6 text-muted-foreground hover:text-foreground hover:bg-destructive/80">
          <X className="w-3 h-3" />
        </Button>
      </div>
    </div>
  )
}
