"use client"

import { X, Circle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"
import type { FileTab } from "./ide-layout"

interface EditorTabsProps {
  files: FileTab[]
  activeFileId: string
  onFileSelect: (fileId: string) => void
  onFileClose: (fileId: string) => void
}

export function EditorTabs({ files, activeFileId, onFileSelect, onFileClose }: EditorTabsProps) {
  const getFileIcon = (name: string) => {
    if (name.endsWith('.tsx') || name.endsWith('.ts')) {
      return <span className="text-[#3178c6] text-[10px] font-bold">TS</span>
    }
    if (name.endsWith('.css')) {
      return <span className="text-[#563d7c] text-[10px] font-bold">CSS</span>
    }
    if (name.endsWith('.json')) {
      return <span className="text-[#cbcb41] text-[10px] font-bold">{'{}'}</span>
    }
    return null
  }

  return (
    <div className="h-9 bg-sidebar border-b border-border flex items-center">
      <ScrollArea className="flex-1">
        <div className="flex h-9">
          {files.map((file) => (
            <div
              key={file.id}
              className={cn(
                "group flex items-center gap-2 h-full px-3 border-r border-border cursor-pointer min-w-[120px] max-w-[200px]",
                activeFileId === file.id 
                  ? "bg-background text-foreground" 
                  : "bg-sidebar text-muted-foreground hover:text-foreground"
              )}
              onClick={() => onFileSelect(file.id)}
            >
              {getFileIcon(file.name)}
              <span className="text-sm truncate flex-1">{file.name}</span>
              {file.isModified && (
                <Circle className="w-2 h-2 fill-primary text-primary shrink-0" />
              )}
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  "w-5 h-5 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity",
                  activeFileId === file.id && "opacity-100"
                )}
                onClick={(e) => {
                  e.stopPropagation()
                  onFileClose(file.id)
                }}
              >
                <X className="w-3 h-3" />
              </Button>
            </div>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  )
}
