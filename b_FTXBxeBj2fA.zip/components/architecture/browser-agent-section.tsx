"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Globe, 
  MousePointer, 
  Eye, 
  Camera,
  FileText,
  Download,
  Shield,
  Cpu,
  Network,
  Layers,
  Play,
  CheckCircle2
} from "lucide-react"

const browserCapabilities = [
  {
    name: "Visual Understanding",
    icon: Eye,
    description: "Screenshot analysis and DOM element recognition",
    features: [
      "Page layout comprehension",
      "Element identification by visual appearance",
      "Dynamic content detection",
      "Accessibility tree parsing"
    ]
  },
  {
    name: "Interaction Automation",
    icon: MousePointer,
    description: "Precise click, type, scroll, and navigation actions",
    features: [
      "Intelligent element targeting",
      "Form filling automation",
      "Multi-step workflow execution",
      "Wait and retry strategies"
    ]
  },
  {
    name: "Content Extraction",
    icon: FileText,
    description: "Structured data extraction from web pages",
    features: [
      "Table and list parsing",
      "Article content extraction",
      "API response interception",
      "Dynamic content scraping"
    ]
  },
  {
    name: "Session Management",
    icon: Shield,
    description: "Secure cookie and authentication handling",
    features: [
      "Credential isolation",
      "Session persistence",
      "Multi-account support",
      "OAuth flow automation"
    ]
  }
]

const browserActions = [
  { action: "navigate", description: "Go to URL or follow links", example: "navigate('https://github.com/user/repo')" },
  { action: "click", description: "Click on elements by selector or coordinates", example: "click('#submit-button')" },
  { action: "type", description: "Enter text into input fields", example: "type('#search', 'query text')" },
  { action: "screenshot", description: "Capture full page or element screenshots", example: "screenshot({ fullPage: true })" },
  { action: "extract", description: "Extract structured data from page", example: "extract('.product-card', schema)" },
  { action: "wait", description: "Wait for elements or conditions", example: "wait('.loading', { hidden: true })" },
  { action: "scroll", description: "Scroll to elements or positions", example: "scroll('#footer')" },
  { action: "evaluate", description: "Execute JavaScript in page context", example: "evaluate(() => document.title)" }
]

const securityMeasures = [
  {
    measure: "Isolated Browser Contexts",
    description: "Each session runs in a separate browser context with no shared state"
  },
  {
    measure: "Network Request Filtering",
    description: "Allowlist-only network policies prevent data exfiltration"
  },
  {
    measure: "Credential Vault Integration",
    description: "Passwords never exposed to agent; injected via secure vault"
  },
  {
    measure: "Action Audit Logging",
    description: "Complete trace of all browser actions for compliance review"
  },
  {
    measure: "Resource Limits",
    description: "CPU, memory, and time limits prevent runaway automation"
  }
]

const useCases = [
  {
    title: "Web Testing",
    description: "Automated E2E testing with visual regression detection",
    icon: Play
  },
  {
    title: "Data Collection",
    description: "Structured extraction from documentation and APIs",
    icon: Download
  },
  {
    title: "Workflow Automation",
    description: "Multi-step processes across web applications",
    icon: Layers
  },
  {
    title: "Live Preview",
    description: "Real-time preview and interaction with generated UIs",
    icon: Camera
  }
]

export function BrowserAgentSection() {
  return (
    <div className="space-y-12">
      <div className="text-center">
        <Badge variant="outline" className="mb-4 border-blue-500/50 text-blue-400">
          Browser Automation
        </Badge>
        <h2 className="text-3xl font-bold text-foreground mb-4">
          Browser Agent Infrastructure
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Headless browser automation with AI-powered visual understanding 
          for web interaction, testing, and content extraction.
        </p>
      </div>

      {/* Capabilities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {browserCapabilities.map((cap) => {
          const Icon = cap.icon
          return (
            <Card key={cap.name} className="bg-card border-border">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <CardTitle className="text-foreground text-lg">{cap.name}</CardTitle>
                    <CardDescription className="text-sm">{cap.description}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {cap.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Browser Actions API */}
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Globe className="w-5 h-5 text-cyan-400" />
            <CardTitle className="text-foreground">Browser Actions API</CardTitle>
          </div>
          <CardDescription>
            Programmable browser control interface for agent execution
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {browserActions.map((item) => (
              <div 
                key={item.action}
                className="p-3 rounded-lg bg-muted/50 border border-border"
              >
                <div className="flex items-center gap-2 mb-1">
                  <code className="text-sm font-semibold text-cyan-400">{item.action}()</code>
                </div>
                <p className="text-xs text-muted-foreground mb-2">{item.description}</p>
                <code className="text-xs text-muted-foreground/70 font-mono block truncate">
                  {item.example}
                </code>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Security & Use Cases */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Security Measures */}
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-green-400" />
              <CardTitle className="text-foreground">Security Measures</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {securityMeasures.map((item) => (
                <li key={item.measure} className="border-b border-border last:border-0 pb-3 last:pb-0">
                  <p className="font-medium text-foreground text-sm">{item.measure}</p>
                  <p className="text-xs text-muted-foreground">{item.description}</p>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Use Cases */}
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Cpu className="w-5 h-5 text-amber-400" />
              <CardTitle className="text-foreground">Use Cases</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {useCases.map((useCase) => {
                const Icon = useCase.icon
                return (
                  <div 
                    key={useCase.title}
                    className="p-4 rounded-lg bg-muted/50 border border-border text-center"
                  >
                    <div className="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center mx-auto mb-2">
                      <Icon className="w-5 h-5 text-amber-400" />
                    </div>
                    <h4 className="font-medium text-foreground text-sm mb-1">{useCase.title}</h4>
                    <p className="text-xs text-muted-foreground">{useCase.description}</p>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Architecture Diagram */}
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Network className="w-5 h-5 text-purple-400" />
            <CardTitle className="text-foreground">Browser Pool Architecture</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-purple-500/10 border border-purple-500/30">
              <h4 className="font-semibold text-foreground mb-2">Browser Pool</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>Chromium instances: 10-50</li>
                <li>Warm pool for fast startup</li>
                <li>Auto-scaling based on demand</li>
                <li>Health monitoring</li>
              </ul>
            </div>
            <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/30">
              <h4 className="font-semibold text-foreground mb-2">Proxy Layer</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>Request routing</li>
                <li>Rate limiting</li>
                <li>Geographic distribution</li>
                <li>SSL termination</li>
              </ul>
            </div>
            <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/30">
              <h4 className="font-semibold text-foreground mb-2">Vision Service</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>Screenshot analysis</li>
                <li>Element detection</li>
                <li>OCR processing</li>
                <li>Layout understanding</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
