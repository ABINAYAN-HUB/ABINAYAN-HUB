"use client"

import { Badge } from "@/components/ui/badge"
import { Bot, Cpu, Eye, Shield, Sparkles, Zap } from "lucide-react"

const features = [
  { icon: Bot, label: "Multi-Agent Orchestration", color: "text-cyan-400" },
  { icon: Sparkles, label: "AI Model Integration", color: "text-blue-400" },
  { icon: Cpu, label: "GPU-Aware Resource Management", color: "text-emerald-400" },
  { icon: Eye, label: "Browser Verification", color: "text-amber-400" },
  { icon: Shield, label: "Enterprise Security", color: "text-rose-400" },
  { icon: Zap, label: "Real-time Performance", color: "text-violet-400" },
]

export function HeroSection() {
  return (
    <div className="relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-cyan-950/20 via-background to-background" />
      
      {/* Grid pattern */}
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(to right, currentColor 1px, transparent 1px), 
                           linear-gradient(to bottom, currentColor 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />
      
      {/* Glowing orbs */}
      <div className="absolute top-20 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />
      <div className="absolute top-40 right-1/4 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-20">
        <div className="text-center">
          <Badge variant="outline" className="mb-6 px-4 py-1.5 text-sm border-cyan-500/30 text-cyan-400 bg-cyan-500/5">
            Architectural Blueprint v1.0
          </Badge>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-foreground mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-violet-400">
              Antigravity IDE
            </span>
          </h1>
          
          <p className="text-xl sm:text-2xl text-muted-foreground max-w-3xl mx-auto mb-4 leading-relaxed">
            A comprehensive architecture for building the next generation of 
            <span className="text-foreground font-medium"> agent-first development environments</span>
          </p>
          
          <p className="text-base text-muted-foreground max-w-2xl mx-auto mb-12">
            Integrating Gemini 3.1 Pro, Claude 4.6 Opus, NVIDIA NIM, and advanced GPU monitoring 
            to create autonomous AI agents that plan, execute, and verify complex engineering tasks.
          </p>
          
          {/* Feature pills */}
          <div className="flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
            {features.map((feature) => (
              <div
                key={feature.label}
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/50 border border-border"
              >
                <feature.icon className={`w-4 h-4 ${feature.color}`} />
                <span className="text-sm text-muted-foreground">{feature.label}</span>
              </div>
            ))}
          </div>
        </div>
        
        {/* Stats */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { value: "2M", label: "Token Context Window", sublabel: "Gemini 3.1 Pro" },
            { value: "5", label: "Parallel Agents", sublabel: "Maximum concurrent" },
            { value: "6", label: "Security Layers", sublabel: "Enterprise-grade" },
            { value: "36", label: "Week Roadmap", sublabel: "Full implementation" },
          ].map((stat) => (
            <div key={stat.label} className="text-center p-6 rounded-xl bg-secondary/30 border border-border">
              <div className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
                {stat.value}
              </div>
              <div className="text-sm font-medium text-foreground mt-1">{stat.label}</div>
              <div className="text-xs text-muted-foreground">{stat.sublabel}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
