"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { 
  Cpu, 
  Activity, 
  Thermometer, 
  Zap,
  HardDrive,
  Server,
  BarChart3,
  Clock,
  TrendingUp,
  AlertTriangle
} from "lucide-react"

// Simulated GPU data
const gpuNodes = [
  {
    id: "gpu-node-1",
    name: "A100-40GB-01",
    type: "NVIDIA A100",
    memory: { used: 28.5, total: 40 },
    utilization: 78,
    temperature: 62,
    power: 285,
    maxPower: 400,
    status: "healthy"
  },
  {
    id: "gpu-node-2",
    name: "A100-40GB-02",
    type: "NVIDIA A100",
    memory: { used: 35.2, total: 40 },
    utilization: 92,
    temperature: 71,
    power: 345,
    maxPower: 400,
    status: "healthy"
  },
  {
    id: "gpu-node-3",
    name: "H100-80GB-01",
    type: "NVIDIA H100",
    memory: { used: 45.8, total: 80 },
    utilization: 65,
    temperature: 58,
    power: 420,
    maxPower: 700,
    status: "healthy"
  },
  {
    id: "gpu-node-4",
    name: "L4-24GB-01",
    type: "NVIDIA L4",
    memory: { used: 18.2, total: 24 },
    utilization: 45,
    temperature: 48,
    power: 52,
    maxPower: 72,
    status: "idle"
  }
]

const inferenceMetrics = [
  { label: "Requests/sec", value: "2,847", change: "+12%", icon: Activity },
  { label: "Avg Latency", value: "156ms", change: "-8%", icon: Clock },
  { label: "Throughput", value: "1.2M tok/s", change: "+5%", icon: TrendingUp },
  { label: "Queue Depth", value: "23", change: "-15%", icon: BarChart3 }
]

const modelDeployments = [
  { model: "gemini-2.0-flash", instances: 4, gpus: "A100", status: "running", qps: 850 },
  { model: "claude-opus-4", instances: 2, gpus: "H100", status: "running", qps: 320 },
  { model: "codestral-latest", instances: 6, gpus: "L4", status: "running", qps: 1200 },
  { model: "custom-finetune-v2", instances: 1, gpus: "A100", status: "scaling", qps: 180 }
]

export function GPUMonitorSection() {
  const [metrics, setMetrics] = useState(inferenceMetrics)
  
  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => prev.map(m => ({
        ...m,
        value: m.label === "Requests/sec" 
          ? `${(2800 + Math.floor(Math.random() * 100)).toLocaleString()}`
          : m.label === "Avg Latency"
          ? `${150 + Math.floor(Math.random() * 20)}ms`
          : m.value
      })))
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-12">
      <div className="text-center">
        <Badge variant="outline" className="mb-4 border-green-500/50 text-green-400">
          Infrastructure
        </Badge>
        <h2 className="text-3xl font-bold text-foreground mb-4">
          GPU Cluster Monitoring
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Real-time monitoring of GPU resources, inference throughput, 
          and model deployment status across the compute cluster.
        </p>
      </div>

      {/* Real-time Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {metrics.map((metric) => {
          const Icon = metric.icon
          const isPositive = metric.change.startsWith("+") || metric.change.startsWith("-") && metric.label === "Avg Latency"
          return (
            <Card key={metric.label} className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-2">
                  <Icon className="w-5 h-5 text-muted-foreground" />
                  <Badge 
                    variant="outline" 
                    className={isPositive ? "border-green-500/50 text-green-400" : "border-red-500/50 text-red-400"}
                  >
                    {metric.change}
                  </Badge>
                </div>
                <p className="text-2xl font-bold text-foreground">{metric.value}</p>
                <p className="text-sm text-muted-foreground">{metric.label}</p>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* GPU Nodes */}
      <div>
        <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
          <Server className="w-5 h-5 text-cyan-400" />
          GPU Nodes
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {gpuNodes.map((gpu) => (
            <Card key={gpu.id} className="bg-card border-border">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-foreground text-lg">{gpu.name}</CardTitle>
                    <CardDescription>{gpu.type}</CardDescription>
                  </div>
                  <Badge 
                    variant="outline" 
                    className={
                      gpu.status === "healthy" ? "border-green-500/50 text-green-400" :
                      gpu.status === "idle" ? "border-blue-500/50 text-blue-400" :
                      "border-amber-500/50 text-amber-400"
                    }
                  >
                    {gpu.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* GPU Utilization */}
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-muted-foreground flex items-center gap-1">
                        <Cpu className="w-3 h-3" /> GPU Utilization
                      </span>
                      <span className="text-foreground">{gpu.utilization}%</span>
                    </div>
                    <Progress value={gpu.utilization} className="h-2" />
                  </div>
                  
                  {/* Memory */}
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-muted-foreground flex items-center gap-1">
                        <HardDrive className="w-3 h-3" /> Memory
                      </span>
                      <span className="text-foreground">{gpu.memory.used}GB / {gpu.memory.total}GB</span>
                    </div>
                    <Progress value={(gpu.memory.used / gpu.memory.total) * 100} className="h-2" />
                  </div>
                  
                  {/* Temperature & Power */}
                  <div className="grid grid-cols-2 gap-4 pt-2 border-t border-border">
                    <div className="flex items-center gap-2">
                      <Thermometer className={`w-4 h-4 ${gpu.temperature > 70 ? "text-amber-400" : "text-green-400"}`} />
                      <div>
                        <p className="text-xs text-muted-foreground">Temp</p>
                        <p className="text-sm font-medium text-foreground">{gpu.temperature}°C</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-400" />
                      <div>
                        <p className="text-xs text-muted-foreground">Power</p>
                        <p className="text-sm font-medium text-foreground">{gpu.power}W / {gpu.maxPower}W</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Model Deployments */}
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Activity className="w-5 h-5 text-purple-400" />
            <CardTitle className="text-foreground">Model Deployments</CardTitle>
          </div>
          <CardDescription>
            Active model instances and their resource allocation
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Model</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Instances</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">GPU Type</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
                  <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">QPS</th>
                </tr>
              </thead>
              <tbody>
                {modelDeployments.map((deployment) => (
                  <tr key={deployment.model} className="border-b border-border last:border-0">
                    <td className="py-3 px-4">
                      <code className="text-sm text-cyan-400">{deployment.model}</code>
                    </td>
                    <td className="py-3 px-4 text-sm text-foreground">{deployment.instances}</td>
                    <td className="py-3 px-4 text-sm text-foreground">{deployment.gpus}</td>
                    <td className="py-3 px-4">
                      <Badge 
                        variant="outline" 
                        className={
                          deployment.status === "running" 
                            ? "border-green-500/50 text-green-400" 
                            : "border-amber-500/50 text-amber-400"
                        }
                      >
                        {deployment.status}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-right text-sm text-foreground">{deployment.qps.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Scaling Policy */}
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center gap-3">
            <TrendingUp className="w-5 h-5 text-green-400" />
            <CardTitle className="text-foreground">Auto-Scaling Configuration</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-muted/50 border border-border">
              <h4 className="font-medium text-foreground mb-2">Scale-Up Triggers</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>GPU utilization &gt; 80% for 2min</li>
                <li>Request queue &gt; 100</li>
                <li>Latency p99 &gt; 500ms</li>
              </ul>
            </div>
            <div className="p-4 rounded-lg bg-muted/50 border border-border">
              <h4 className="font-medium text-foreground mb-2">Scale-Down Triggers</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>GPU utilization &lt; 30% for 10min</li>
                <li>No pending requests</li>
                <li>Minimum instances maintained</li>
              </ul>
            </div>
            <div className="p-4 rounded-lg bg-muted/50 border border-border">
              <h4 className="font-medium text-foreground mb-2">Limits</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>Max instances: 20 per model</li>
                <li>Min instances: 1 per model</li>
                <li>Cooldown: 5 minutes</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
