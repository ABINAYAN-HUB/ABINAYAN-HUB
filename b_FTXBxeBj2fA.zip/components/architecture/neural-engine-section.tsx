"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Brain, Zap, Gauge, ArrowRight, Check } from "lucide-react"

const modelTiers = [
  {
    tier: "Tier 1 (Pro/Opus)",
    models: [
      {
        name: "Gemini 3.1 Pro",
        provider: "Google Vertex AI",
        contextWindow: "2M tokens",
        contextTokens: 2000000,
        capabilities: ["Large-scale refactoring", "Architectural planning", "E2E testing", "Multimodal analysis"],
        strengths: ["Massive context window", "Native multimodality", "Global code consistency"],
        color: "cyan",
      },
      {
        name: "Claude 4.6 Opus",
        provider: "Anthropic",
        contextWindow: "1M tokens",
        contextTokens: 1000000,
        capabilities: ["Adaptive thinking", "Precision coding", "Critical analysis", "Agentic workflows"],
        strengths: ["Effort levels (low→max)", "Context compaction", "Deep reasoning"],
        color: "violet",
      },
    ],
  },
  {
    tier: "Tier 2 (Flash/Sonnet)",
    models: [
      {
        name: "Gemini 3 Flash",
        provider: "Google Vertex AI",
        contextWindow: "1M tokens",
        contextTokens: 1000000,
        capabilities: ["Rapid debugging", "UI iteration", "Quick fixes"],
        strengths: ["Fast response", "Cost-effective", "Good balance"],
        color: "blue",
      },
      {
        name: "Claude 4.6 Sonnet",
        provider: "Anthropic",
        contextWindow: "200K tokens",
        contextTokens: 200000,
        capabilities: ["Unit test generation", "API integration", "Code review"],
        strengths: ["Balanced performance", "Production-ready", "Reliable"],
        color: "indigo",
      },
    ],
  },
  {
    tier: "Tier 3 (Lite/Haiku)",
    models: [
      {
        name: "Gemini 3.1 Flash-Lite",
        provider: "Google Vertex AI",
        contextWindow: "200K tokens",
        contextTokens: 200000,
        capabilities: ["Task routing", "Classification", "Summarization"],
        strengths: ["Ultra-fast", "Low cost", "High throughput"],
        color: "emerald",
      },
      {
        name: "Claude 4.5 Haiku",
        provider: "Anthropic",
        contextWindow: "200K tokens",
        contextTokens: 200000,
        capabilities: ["Documentation", "Simple queries", "Formatting"],
        strengths: ["Instant responses", "Economical", "Efficient"],
        color: "teal",
      },
    ],
  },
]

const routingDecisionTree = [
  {
    condition: "Context > 1M tokens",
    result: "Gemini 3.1 Pro",
    reasoning: "Only model with 2M context window for full codebase analysis",
  },
  {
    condition: "Deep reasoning required + High complexity",
    result: "Claude 4.6 Opus (Max Effort)",
    reasoning: "Adaptive thinking with maximum computational budget",
  },
  {
    condition: "Medium complexity + Standard task",
    result: "Claude 4.6 Sonnet / Gemini 3 Flash",
    reasoning: "Balanced performance for production use cases",
  },
  {
    condition: "Speed critical + Simple task",
    result: "Gemini 3 Flash",
    reasoning: "Optimized for rapid iteration and quick feedback",
  },
  {
    condition: "Classification / Routing",
    result: "Gemini 3.1 Flash-Lite",
    reasoning: "Fast, token-efficient for simple automation tasks",
  },
]

const effortLevels = [
  { level: "Low", description: "Fast, token-efficient for simple automation", budget: 25 },
  { level: "Medium", description: "Balanced for production use cases", budget: 50 },
  { level: "High", description: "Complex architectural analysis", budget: 75 },
  { level: "Max", description: "Highest capability for agentic coding", budget: 100 },
]

export function NeuralEngineSection() {
  const maxContextTokens = 2000000

  return (
    <div className="space-y-12">
      <div>
        <Badge variant="outline" className="mb-4">Neural Engine</Badge>
        <h2 className="text-3xl font-bold text-foreground mb-4">Multi-Model Orchestration</h2>
        <p className="text-lg text-muted-foreground max-w-3xl">
          The Neural Engine intelligently routes tasks to optimal AI models based on 
          complexity analysis, context requirements, and reasoning profiles.
        </p>
      </div>

      {/* Model Tiers */}
      <Tabs defaultValue="tier1" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="tier1">Tier 1 (Pro/Opus)</TabsTrigger>
          <TabsTrigger value="tier2">Tier 2 (Flash/Sonnet)</TabsTrigger>
          <TabsTrigger value="tier3">Tier 3 (Lite/Haiku)</TabsTrigger>
        </TabsList>

        {modelTiers.map((tier, tierIndex) => (
          <TabsContent key={tier.tier} value={`tier${tierIndex + 1}`}>
            <div className="grid md:grid-cols-2 gap-6">
              {tier.models.map((model) => (
                <Card key={model.name} className="border-border bg-card/50 overflow-hidden">
                  <div className={`h-1 bg-${model.color}-500`} style={{ 
                    background: model.color === "cyan" ? "rgb(6, 182, 212)" : 
                               model.color === "violet" ? "rgb(139, 92, 246)" :
                               model.color === "blue" ? "rgb(59, 130, 246)" :
                               model.color === "indigo" ? "rgb(99, 102, 241)" :
                               model.color === "emerald" ? "rgb(16, 185, 129)" : "rgb(20, 184, 166)"
                  }} />
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl">{model.name}</CardTitle>
                        <CardDescription>{model.provider}</CardDescription>
                      </div>
                      <Badge variant="outline">{model.contextWindow}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Context Window Visualization */}
                    <div>
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>Context Window</span>
                        <span>{(model.contextTokens / 1000000).toFixed(1)}M / {(maxContextTokens / 1000000).toFixed(1)}M tokens</span>
                      </div>
                      <Progress value={(model.contextTokens / maxContextTokens) * 100} className="h-2" />
                    </div>

                    {/* Capabilities */}
                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground mb-2">Capabilities</h4>
                      <div className="flex flex-wrap gap-2">
                        {model.capabilities.map((cap) => (
                          <Badge key={cap} variant="secondary" className="text-xs">
                            {cap}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Key Strengths */}
                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground mb-2">Key Strengths</h4>
                      <ul className="space-y-1">
                        {model.strengths.map((strength) => (
                          <li key={strength} className="flex items-center gap-2 text-sm text-foreground">
                            <Check className="w-3 h-3 text-emerald-500" />
                            {strength}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Task Router Decision Tree */}
      <div className="mt-12">
        <h3 className="text-2xl font-bold text-foreground mb-6">Intelligent Task Routing</h3>
        <p className="text-muted-foreground mb-8 max-w-3xl">
          The Task Router analyzes incoming requests and automatically selects the optimal 
          model based on complexity, context requirements, and task type.
        </p>

        <div className="space-y-4">
          {routingDecisionTree.map((decision, index) => (
            <div key={decision.condition} className="flex items-stretch gap-4">
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 rounded-full bg-secondary border border-border flex items-center justify-center text-sm font-medium">
                  {index + 1}
                </div>
                {index < routingDecisionTree.length - 1 && (
                  <div className="flex-1 w-px bg-border mt-2" />
                )}
              </div>
              <Card className="flex-1 border-border bg-card/30">
                <CardContent className="p-4">
                  <div className="flex flex-col md:flex-row md:items-center gap-4">
                    <div className="flex-1">
                      <h4 className="font-medium text-foreground">{decision.condition}</h4>
                      <p className="text-sm text-muted-foreground">{decision.reasoning}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <ArrowRight className="w-4 h-4 text-muted-foreground hidden md:block" />
                      <Badge className="bg-cyan-500/10 text-cyan-400 border-cyan-500/30">
                        {decision.result}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>

      {/* Claude Adaptive Thinking */}
      <div className="mt-12">
        <h3 className="text-2xl font-bold text-foreground mb-6">Claude 4.6 Adaptive Thinking</h3>
        <p className="text-muted-foreground mb-8 max-w-3xl">
          Claude 4.6 introduces dynamic effort levels that allow the model to automatically 
          determine the computational budget required for each prompt.
        </p>

        <Card className="border-border bg-card/50">
          <CardContent className="p-6">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {effortLevels.map((level) => (
                <div
                  key={level.level}
                  className="p-4 rounded-lg bg-secondary/30 border border-border"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-foreground">{level.level}</h4>
                    <Gauge className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <Progress value={level.budget} className="h-2 mb-3" />
                  <p className="text-xs text-muted-foreground">{level.description}</p>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 rounded-lg bg-violet-500/5 border border-violet-500/20">
              <div className="flex items-start gap-3">
                <Brain className="w-5 h-5 text-violet-400 mt-0.5" />
                <div>
                  <h4 className="font-medium text-foreground mb-1">Context Compaction</h4>
                  <p className="text-sm text-muted-foreground">
                    Claude 4.6 features automatic server-side summarization of long-running conversations, 
                    enabling infinite conversations for persistent development tasks without hitting context limits.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* NVIDIA NIM Integration */}
      <div className="mt-12">
        <h3 className="text-2xl font-bold text-foreground mb-6">NVIDIA NIM Integration</h3>
        <Card className="border-border bg-card/50">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-emerald-400" />
                  Local Inference Benefits
                </h4>
                <ul className="space-y-2">
                  {[
                    "Run open-source models locally (GPT-OSS-120B, Gemma 4)",
                    "Reduced latency for rapid iteration cycles",
                    "Data privacy - no external API calls required",
                    "Cost optimization for high-volume workflows",
                    "GPU-optimized inference via NVIDIA CUDA",
                  ].map((benefit) => (
                    <li key={benefit} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <Check className="w-3 h-3 text-emerald-500 mt-1" />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-foreground mb-3">NIM Microservices Architecture</h4>
                <div className="space-y-3">
                  <div className="p-3 rounded-lg bg-secondary/30 border border-border">
                    <div className="text-sm font-medium text-foreground">Container Deployment</div>
                    <div className="text-xs text-muted-foreground">Pre-built Docker images with optimized inference</div>
                  </div>
                  <div className="p-3 rounded-lg bg-secondary/30 border border-border">
                    <div className="text-sm font-medium text-foreground">GPU Memory Management</div>
                    <div className="text-xs text-muted-foreground">Automatic VRAM allocation via NVML integration</div>
                  </div>
                  <div className="p-3 rounded-lg bg-secondary/30 border border-border">
                    <div className="text-sm font-medium text-foreground">Model Quantization</div>
                    <div className="text-xs text-muted-foreground">FP16, INT8, INT4 for memory optimization</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
