"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { 
  Rocket, 
  CheckCircle2, 
  Clock, 
  Calendar,
  ArrowRight,
  Target,
  Users,
  Zap
} from "lucide-react"

const phases = [
  {
    phase: 1,
    name: "Foundation",
    duration: "Weeks 1-8",
    status: "planning",
    progress: 0,
    description: "Core infrastructure and model abstraction layer",
    milestones: [
      { name: "API Gateway Setup", status: "pending" },
      { name: "Model Router Implementation", status: "pending" },
      { name: "Authentication System", status: "pending" },
      { name: "Base Editor Integration", status: "pending" },
      { name: "Sandbox Environment v1", status: "pending" }
    ],
    deliverables: [
      "Unified API for all AI models",
      "OAuth 2.0 authentication flow",
      "Monaco editor with AI hooks",
      "Basic sandbox execution"
    ]
  },
  {
    phase: 2,
    name: "Intelligence Layer",
    duration: "Weeks 9-16",
    status: "upcoming",
    progress: 0,
    description: "AI agents, context management, and smart features",
    milestones: [
      { name: "Context Engine", status: "pending" },
      { name: "Codebase Indexing", status: "pending" },
      { name: "Agent Framework", status: "pending" },
      { name: "Multi-turn Conversations", status: "pending" },
      { name: "Tool Integration", status: "pending" }
    ],
    deliverables: [
      "Semantic code search",
      "Project-aware completions",
      "Autonomous coding agents",
      "External tool integration"
    ]
  },
  {
    phase: 3,
    name: "Scale & Polish",
    duration: "Weeks 17-24",
    status: "upcoming",
    progress: 0,
    description: "Performance optimization and enterprise features",
    milestones: [
      { name: "Caching Layer", status: "pending" },
      { name: "Team Collaboration", status: "pending" },
      { name: "Analytics Dashboard", status: "pending" },
      { name: "Enterprise SSO", status: "pending" },
      { name: "Audit Logging", status: "pending" }
    ],
    deliverables: [
      "Sub-100ms completions",
      "Real-time collaboration",
      "Usage analytics",
      "Compliance reporting"
    ]
  }
]

const teamStructure = [
  { role: "Platform Engineers", count: 4, focus: "Infrastructure, API Gateway, Scaling" },
  { role: "AI/ML Engineers", count: 3, focus: "Model integration, RAG, Fine-tuning" },
  { role: "Frontend Engineers", count: 3, focus: "Editor, UI/UX, Real-time features" },
  { role: "Security Engineers", count: 2, focus: "Auth, Sandboxing, Compliance" },
  { role: "DevOps/SRE", count: 2, focus: "CI/CD, Monitoring, On-call" }
]

const techStack = [
  { category: "Frontend", items: ["Next.js 16", "Monaco Editor", "React Query", "Tailwind CSS"] },
  { category: "Backend", items: ["Node.js", "Go (hot paths)", "Python (ML)", "gRPC"] },
  { category: "Data", items: ["PostgreSQL", "Redis", "Pinecone", "ClickHouse"] },
  { category: "Infra", items: ["Kubernetes", "Istio", "Terraform", "ArgoCD"] }
]

export function ImplementationRoadmap() {
  return (
    <section id="roadmap" className="py-24 px-6 bg-zinc-950/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 border-amber-500/50 text-amber-400">
            Implementation Plan
          </Badge>
          <h2 className="text-4xl font-bold text-white mb-4">
            Development Roadmap
          </h2>
          <p className="text-zinc-400 max-w-2xl mx-auto">
            A phased approach to building the Antigravity IDE, from core infrastructure
            to enterprise-ready features.
          </p>
        </div>

        {/* Timeline */}
        <div className="space-y-6 mb-16">
          {phases.map((phase, index) => (
            <Card key={phase.phase} className="bg-zinc-900/50 border-zinc-800 overflow-hidden">
              <div className="flex flex-col lg:flex-row">
                {/* Phase Header */}
                <div className="lg:w-72 p-6 border-b lg:border-b-0 lg:border-r border-zinc-800 bg-zinc-900/80">
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      phase.status === "completed" ? "bg-green-500/20 text-green-400" :
                      phase.status === "in-progress" ? "bg-cyan-500/20 text-cyan-400" :
                      phase.status === "planning" ? "bg-amber-500/20 text-amber-400" :
                      "bg-zinc-700/50 text-zinc-500"
                    }`}>
                      {phase.status === "completed" ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : (
                        <span className="font-bold">{phase.phase}</span>
                      )}
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{phase.name}</h3>
                      <div className="flex items-center gap-1 text-xs text-zinc-500">
                        <Calendar className="w-3 h-3" />
                        {phase.duration}
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-zinc-400 mb-4">{phase.description}</p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="text-zinc-500">Progress</span>
                      <span className="text-zinc-400">{phase.progress}%</span>
                    </div>
                    <Progress value={phase.progress} className="h-1.5" />
                  </div>
                </div>

                {/* Phase Content */}
                <div className="flex-1 p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Milestones */}
                    <div>
                      <h4 className="text-sm font-medium text-zinc-400 mb-3 flex items-center gap-2">
                        <Target className="w-4 h-4" />
                        Milestones
                      </h4>
                      <div className="space-y-2">
                        {phase.milestones.map((milestone) => (
                          <div 
                            key={milestone.name}
                            className="flex items-center gap-2 text-sm"
                          >
                            {milestone.status === "completed" ? (
                              <CheckCircle2 className="w-4 h-4 text-green-500" />
                            ) : milestone.status === "in-progress" ? (
                              <Clock className="w-4 h-4 text-cyan-400" />
                            ) : (
                              <div className="w-4 h-4 rounded-full border border-zinc-600" />
                            )}
                            <span className={
                              milestone.status === "completed" ? "text-zinc-400 line-through" :
                              milestone.status === "in-progress" ? "text-white" :
                              "text-zinc-500"
                            }>
                              {milestone.name}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Deliverables */}
                    <div>
                      <h4 className="text-sm font-medium text-zinc-400 mb-3 flex items-center gap-2">
                        <Rocket className="w-4 h-4" />
                        Deliverables
                      </h4>
                      <div className="space-y-2">
                        {phase.deliverables.map((deliverable) => (
                          <div 
                            key={deliverable}
                            className="flex items-center gap-2 text-sm text-zinc-300"
                          >
                            <ArrowRight className="w-3 h-3 text-cyan-500" />
                            {deliverable}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Team & Tech Stack */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Team Structure */}
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-cyan-400" />
                <CardTitle className="text-white">Recommended Team</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {teamStructure.map((team) => (
                  <div 
                    key={team.role}
                    className="flex items-center justify-between p-3 rounded-lg bg-zinc-800/50 border border-zinc-700/50"
                  >
                    <div>
                      <p className="font-medium text-white text-sm">{team.role}</p>
                      <p className="text-xs text-zinc-500">{team.focus}</p>
                    </div>
                    <Badge variant="outline" className="border-zinc-600 text-zinc-300">
                      {team.count}
                    </Badge>
                  </div>
                ))}
                <div className="pt-3 border-t border-zinc-800 flex items-center justify-between">
                  <span className="text-sm text-zinc-400">Total Team Size</span>
                  <span className="font-semibold text-white">14 engineers</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tech Stack */}
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Zap className="w-5 h-5 text-amber-400" />
                <CardTitle className="text-white">Technology Stack</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {techStack.map((stack) => (
                  <div key={stack.category}>
                    <p className="text-xs text-zinc-500 mb-2 uppercase tracking-wider">{stack.category}</p>
                    <div className="space-y-1">
                      {stack.items.map((item) => (
                        <div 
                          key={item}
                          className="px-2 py-1 rounded bg-zinc-800/50 border border-zinc-700/50 text-sm text-zinc-300"
                        >
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
