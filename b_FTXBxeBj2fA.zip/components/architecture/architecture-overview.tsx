"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Monitor, 
  LayoutDashboard, 
  Globe, 
  Inbox, 
  Layers, 
  Brain, 
  HardDrive,
  ArrowRight,
  ArrowDown
} from "lucide-react"

const layers = [
  {
    name: "Presentation Layer",
    icon: Monitor,
    color: "from-cyan-500 to-blue-500",
    components: [
      { name: "Editor View", description: "Monaco-based code editing with AI assistance", icon: Monitor },
      { name: "Manager View", description: "Agent orchestration dashboard with GPU metrics", icon: LayoutDashboard },
      { name: "Browser Surface", description: "Chrome CDP integration for UI testing", icon: Globe },
      { name: "Inbox", description: "Approval queue and notification center", icon: Inbox },
    ],
  },
  {
    name: "Orchestration Layer",
    icon: Layers,
    color: "from-blue-500 to-violet-500",
    components: [
      { name: "Task Router", description: "Intelligent model selection based on complexity" },
      { name: "Context Manager", description: "2M token window management with compaction" },
      { name: "Artifact Engine", description: "Generate task lists, plans, and walkthroughs" },
      { name: "Agent Lifecycle", description: "Spawn, monitor, and manage parallel agents" },
    ],
  },
  {
    name: "Neural Engine Layer",
    icon: Brain,
    color: "from-violet-500 to-rose-500",
    components: [
      { name: "Gemini 3.1 Pro", description: "2M context, multimodal, large codebases" },
      { name: "Claude 4.6 Opus", description: "Adaptive thinking, precision coding" },
      { name: "NVIDIA NIM", description: "Local inference with GPU optimization" },
      { name: "Model Gateway", description: "Unified API with rate limiting" },
    ],
  },
  {
    name: "Infrastructure Layer",
    icon: HardDrive,
    color: "from-rose-500 to-amber-500",
    components: [
      { name: "NVML Monitor", description: "Real-time GPU metrics and throttling" },
      { name: "Database", description: "PostgreSQL + Vector store for embeddings" },
      { name: "Security Gateway", description: "OAuth, permissions, secret detection" },
      { name: "Audit Logging", description: "Complete action trail for compliance" },
    ],
  },
]

const dualViewComparison = [
  {
    view: "Editor View",
    purpose: "Tactical Code Editing",
    persona: "Developer / Contributor",
    mode: "Synchronous / Reactive",
    features: ["Monaco Editor", "File Explorer", "Terminal", "AI Sidebar", "Tab Completion", "Inline Commands"],
  },
  {
    view: "Manager View",
    purpose: "Strategic Orchestration",
    persona: "Architect / Product Owner",
    mode: "Asynchronous / Proactive",
    features: ["Agent Grid (5 max)", "GPU Metrics", "Inbox Queue", "Artifact Viewer", "Mission Timeline", "Knowledge Base"],
  },
]

export function ArchitectureOverview() {
  return (
    <div className="space-y-12">
      <div>
        <Badge variant="outline" className="mb-4">System Architecture</Badge>
        <h2 className="text-3xl font-bold text-foreground mb-4">High-Level Architecture</h2>
        <p className="text-lg text-muted-foreground max-w-3xl">
          The Antigravity IDE is built on four interconnected layers, each responsible for 
          distinct aspects of the agentic development experience.
        </p>
      </div>

      {/* Layer Diagram */}
      <div className="space-y-4">
        {layers.map((layer, layerIndex) => (
          <div key={layer.name}>
            <Card className="border-border bg-card/50 overflow-hidden">
              <div className={`h-1 bg-gradient-to-r ${layer.color}`} />
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg bg-gradient-to-br ${layer.color} bg-opacity-10`}>
                    <layer.icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{layer.name}</CardTitle>
                    <CardDescription>Layer {layerIndex + 1} of 4</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {layer.components.map((component) => (
                    <div
                      key={component.name}
                      className="p-4 rounded-lg bg-secondary/30 border border-border hover:bg-secondary/50 transition-colors"
                    >
                      <h4 className="font-medium text-foreground text-sm mb-1">{component.name}</h4>
                      <p className="text-xs text-muted-foreground">{component.description}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {layerIndex < layers.length - 1 && (
              <div className="flex justify-center py-2">
                <ArrowDown className="w-5 h-5 text-muted-foreground" />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Dual View Architecture */}
      <div className="mt-16">
        <h3 className="text-2xl font-bold text-foreground mb-6">Bifurcated Interface Design</h3>
        <p className="text-muted-foreground mb-8 max-w-3xl">
          Unlike traditional IDEs, Antigravity uses a two-view architecture to separate 
          tactical code editing from strategic mission orchestration.
        </p>
        
        <div className="grid md:grid-cols-2 gap-6">
          {dualViewComparison.map((view, index) => (
            <Card key={view.view} className="border-border bg-card/50">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">{view.view}</CardTitle>
                  <Badge variant={index === 0 ? "default" : "secondary"}>
                    {view.mode}
                  </Badge>
                </div>
                <CardDescription>{view.purpose}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">Primary User:</span>
                  <span className="text-foreground font-medium">{view.persona}</span>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Key Features</h4>
                  <div className="flex flex-wrap gap-2">
                    {view.features.map((feature) => (
                      <Badge key={feature} variant="outline" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Data Flow Arrow */}
        <div className="flex items-center justify-center my-8 gap-4">
          <div className="flex-1 h-px bg-border" />
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-border">
            <span className="text-sm text-muted-foreground">Unified Agent Orchestration Engine</span>
            <ArrowRight className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex-1 h-px bg-border" />
        </div>
      </div>

      {/* Key Principles */}
      <div className="grid md:grid-cols-3 gap-6 mt-12">
        {[
          {
            title: "Agent-First Paradigm",
            description: "AI is not a peripheral utility but an autonomous actor capable of long-horizon reasoning and multi-step task execution.",
          },
          {
            title: "Human-in-the-Loop Gating",
            description: "Critical decisions require human approval through the Inbox system, ensuring developers remain vital gatekeepers.",
          },
          {
            title: "Hardware Awareness",
            description: "Real-time GPU monitoring via NVML enables intelligent resource management and prevents system overload.",
          },
        ].map((principle) => (
          <Card key={principle.title} className="border-border bg-secondary/20">
            <CardHeader>
              <CardTitle className="text-base">{principle.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{principle.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
