"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Bot, 
  GitBranch, 
  Terminal, 
  FileSearch,
  Code2,
  MessageSquare,
  Workflow,
  Layers,
  ArrowRight,
  Zap,
  Brain,
  Target,
  Clock,
  CheckCircle2
} from "lucide-react"

const agentTypes = [
  {
    id: "coding",
    name: "Coding Agent",
    icon: Code2,
    color: "from-cyan-500 to-blue-500",
    description: "Autonomous code generation, refactoring, and optimization",
    capabilities: [
      "Multi-file code generation with dependency awareness",
      "Automated refactoring with semantic understanding",
      "Test generation and coverage optimization",
      "Performance profiling and optimization suggestions",
      "Cross-language translation and migration"
    ],
    tools: ["file_read", "file_write", "terminal_exec", "search_codebase", "run_tests"]
  },
  {
    id: "research",
    name: "Research Agent",
    icon: FileSearch,
    color: "from-green-500 to-emerald-500",
    description: "Information gathering, documentation, and knowledge synthesis",
    capabilities: [
      "API documentation parsing and summarization",
      "Stack Overflow and GitHub issue analysis",
      "Library comparison and recommendation",
      "Security vulnerability research",
      "Best practices aggregation"
    ],
    tools: ["web_search", "web_fetch", "doc_parser", "summarize", "compare"]
  },
  {
    id: "debug",
    name: "Debug Agent",
    icon: Terminal,
    color: "from-orange-500 to-amber-500",
    description: "Error diagnosis, root cause analysis, and fix generation",
    capabilities: [
      "Stack trace analysis and source mapping",
      "Runtime behavior monitoring",
      "Memory leak detection",
      "Race condition identification",
      "Automated fix suggestion and verification"
    ],
    tools: ["debugger_attach", "memory_profile", "trace_execution", "log_analyze", "breakpoint_set"]
  },
  {
    id: "orchestrator",
    name: "Orchestrator Agent",
    icon: Workflow,
    color: "from-purple-500 to-violet-500",
    description: "Task decomposition, delegation, and result aggregation",
    capabilities: [
      "Complex task decomposition into subtasks",
      "Dynamic agent selection and routing",
      "Parallel execution coordination",
      "Result synthesis and conflict resolution",
      "Progress tracking and status reporting"
    ],
    tools: ["spawn_agent", "delegate_task", "await_result", "aggregate", "report"]
  }
]

const agentWorkflow = [
  {
    step: 1,
    title: "Task Reception",
    description: "Receive and parse user intent from natural language",
    icon: MessageSquare
  },
  {
    step: 2,
    title: "Planning",
    description: "Decompose into subtasks with dependency graph",
    icon: GitBranch
  },
  {
    step: 3,
    title: "Tool Selection",
    description: "Choose appropriate tools for each subtask",
    icon: Layers
  },
  {
    step: 4,
    title: "Execution",
    description: "Execute with monitoring and error recovery",
    icon: Zap
  },
  {
    step: 5,
    title: "Verification",
    description: "Validate results against acceptance criteria",
    icon: CheckCircle2
  }
]

const memoryTypes = [
  {
    name: "Short-term Memory",
    description: "Current conversation context and active task state",
    retention: "Session",
    storage: "In-memory cache"
  },
  {
    name: "Working Memory",
    description: "Intermediate results and partial computations",
    retention: "Task duration",
    storage: "Redis cluster"
  },
  {
    name: "Long-term Memory",
    description: "User preferences, project patterns, learned behaviors",
    retention: "Persistent",
    storage: "Vector database"
  },
  {
    name: "Episodic Memory",
    description: "Past interactions and successful problem solutions",
    retention: "Indexed",
    storage: "PostgreSQL + Embeddings"
  }
]

export function AgentFrameworkSection() {
  const [selectedAgent, setSelectedAgent] = useState(agentTypes[0])

  return (
    <div className="space-y-12">
      <div className="text-center">
        <Badge variant="outline" className="mb-4 border-purple-500/50 text-purple-400">
          Agent Framework
        </Badge>
        <h2 className="text-3xl font-bold text-foreground mb-4">
          Autonomous Agent Architecture
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          A flexible agent framework enabling autonomous task execution, tool use, 
          and multi-agent collaboration for complex development workflows.
        </p>
      </div>

      {/* Agent Types Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {agentTypes.map((agent) => {
          const Icon = agent.icon
          const isSelected = selectedAgent.id === agent.id
          return (
            <button
              key={agent.id}
              onClick={() => setSelectedAgent(agent)}
              className={`text-left p-4 rounded-xl border transition-all duration-300 ${
                isSelected
                  ? "border-purple-500/50 bg-purple-500/10"
                  : "border-border bg-card hover:border-muted-foreground/30"
              }`}
            >
              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${agent.color} flex items-center justify-center mb-3`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <h3 className="font-semibold text-foreground mb-1">{agent.name}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2">{agent.description}</p>
            </button>
          )
        })}
      </div>

      {/* Selected Agent Details */}
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${selectedAgent.color} flex items-center justify-center`}>
              <selectedAgent.icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-foreground">{selectedAgent.name}</CardTitle>
              <CardDescription>{selectedAgent.description}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-4 flex items-center gap-2">
                <Target className="w-4 h-4" />
                Capabilities
              </h4>
              <ul className="space-y-2">
                {selectedAgent.capabilities.map((cap, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                    <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                    {cap}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-4 flex items-center gap-2">
                <Layers className="w-4 h-4" />
                Available Tools
              </h4>
              <div className="flex flex-wrap gap-2">
                {selectedAgent.tools.map((tool) => (
                  <Badge key={tool} variant="secondary" className="font-mono text-xs">
                    {tool}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Agent Execution Workflow */}
      <div>
        <h3 className="text-xl font-semibold text-foreground mb-6 text-center">
          Agent Execution Pipeline
        </h3>
        <div className="flex flex-col lg:flex-row items-stretch gap-4">
          {agentWorkflow.map((step, i) => {
            const Icon = step.icon
            return (
              <div key={step.step} className="flex items-center gap-4 flex-1">
                <div className="flex-1 p-4 rounded-xl bg-card border border-border h-full">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 font-semibold text-sm">
                      {step.step}
                    </div>
                    <Icon className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <h4 className="font-medium text-foreground mb-1">{step.title}</h4>
                  <p className="text-xs text-muted-foreground">{step.description}</p>
                </div>
                {i < agentWorkflow.length - 1 && (
                  <ArrowRight className="w-5 h-5 text-muted-foreground shrink-0 hidden lg:block" />
                )}
              </div>
            )
          })}
        </div>
      </div>

      {/* Memory System */}
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Brain className="w-5 h-5 text-cyan-400" />
            <CardTitle className="text-foreground">Agent Memory System</CardTitle>
          </div>
          <CardDescription>
            Multi-tier memory architecture for context retention and learning
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {memoryTypes.map((memory) => (
              <div 
                key={memory.name}
                className="p-4 rounded-lg bg-muted/50 border border-border"
              >
                <h4 className="font-medium text-foreground text-sm mb-2">{memory.name}</h4>
                <p className="text-xs text-muted-foreground mb-3">{memory.description}</p>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Retention:</span>
                    <span className="text-foreground">{memory.retention}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Storage:</span>
                    <span className="text-foreground">{memory.storage}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
