"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Shield, 
  Lock, 
  Key, 
  Eye, 
  FileCheck, 
  Server,
  AlertTriangle,
  CheckCircle2,
  Network,
  Fingerprint
} from "lucide-react"

const securityLayers = [
  {
    title: "Identity & Access Management",
    icon: Fingerprint,
    color: "from-blue-500 to-cyan-500",
    features: [
      {
        name: "OAuth 2.0 / OIDC",
        description: "Industry-standard authentication with Google, GitHub, and enterprise IdPs"
      },
      {
        name: "Role-Based Access Control",
        description: "Granular permissions for users, teams, and organizations"
      },
      {
        name: "Service Account Auth",
        description: "Secure API access for CI/CD and automation workflows"
      },
      {
        name: "MFA Enforcement",
        description: "Mandatory multi-factor authentication for sensitive operations"
      }
    ]
  },
  {
    title: "Data Protection",
    icon: Lock,
    color: "from-green-500 to-emerald-500",
    features: [
      {
        name: "End-to-End Encryption",
        description: "TLS 1.3 for transit, AES-256-GCM for data at rest"
      },
      {
        name: "Client-Side Encryption",
        description: "Optional customer-managed keys for sensitive projects"
      },
      {
        name: "Data Residency",
        description: "Region-specific storage for compliance requirements"
      },
      {
        name: "Secure Deletion",
        description: "Cryptographic erasure with audit trails"
      }
    ]
  },
  {
    title: "Execution Security",
    icon: Server,
    color: "from-orange-500 to-amber-500",
    features: [
      {
        name: "Sandbox Isolation",
        description: "gVisor/Firecracker microVMs with strict resource limits"
      },
      {
        name: "Network Policies",
        description: "Zero-trust networking with allowlist-only egress"
      },
      {
        name: "Code Scanning",
        description: "Static analysis before execution to detect malicious patterns"
      },
      {
        name: "Resource Quotas",
        description: "CPU, memory, and time limits per execution context"
      }
    ]
  },
  {
    title: "AI Safety",
    icon: Shield,
    color: "from-purple-500 to-violet-500",
    features: [
      {
        name: "Prompt Injection Defense",
        description: "Multi-layer detection and filtering of adversarial inputs"
      },
      {
        name: "Output Validation",
        description: "Syntax verification and safety scanning of generated code"
      },
      {
        name: "PII Redaction",
        description: "Automatic detection and masking of sensitive data"
      },
      {
        name: "Audit Logging",
        description: "Complete trace of all AI interactions for compliance"
      }
    ]
  }
]

const complianceFrameworks = [
  { name: "SOC 2 Type II", status: "certified" },
  { name: "ISO 27001", status: "certified" },
  { name: "GDPR", status: "compliant" },
  { name: "HIPAA", status: "eligible" },
  { name: "FedRAMP", status: "in-progress" },
  { name: "PCI DSS", status: "compliant" }
]

const threatModel = [
  {
    threat: "Prompt Injection",
    mitigation: "Input sanitization, context isolation, output validation",
    severity: "high"
  },
  {
    threat: "Data Exfiltration",
    mitigation: "Network policies, DLP scanning, egress filtering",
    severity: "high"
  },
  {
    threat: "Credential Theft",
    mitigation: "Vault integration, short-lived tokens, automatic rotation",
    severity: "critical"
  },
  {
    threat: "Supply Chain Attack",
    mitigation: "Dependency scanning, SBOM generation, signature verification",
    severity: "high"
  },
  {
    threat: "Denial of Service",
    mitigation: "Rate limiting, circuit breakers, auto-scaling",
    severity: "medium"
  }
]

export function SecuritySection() {
  return (
    <section id="security" className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 border-green-500/50 text-green-400">
            Security & Compliance
          </Badge>
          <h2 className="text-4xl font-bold text-white mb-4">
            Enterprise-Grade Security Architecture
          </h2>
          <p className="text-zinc-400 max-w-2xl mx-auto">
            Defense-in-depth security model with multiple layers of protection
            for code, data, and AI interactions.
          </p>
        </div>

        {/* Security Layers Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-16">
          {securityLayers.map((layer) => {
            const Icon = layer.icon
            return (
              <Card key={layer.title} className="bg-zinc-900/50 border-zinc-800">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${layer.color} flex items-center justify-center`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-white">{layer.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {layer.features.map((feature) => (
                      <div key={feature.name} className="flex gap-3">
                        <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-medium text-white text-sm">{feature.name}</p>
                          <p className="text-xs text-zinc-500">{feature.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Compliance & Threat Model */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Compliance Frameworks */}
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardHeader>
              <div className="flex items-center gap-3">
                <FileCheck className="w-5 h-5 text-cyan-400" />
                <CardTitle className="text-white">Compliance Frameworks</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {complianceFrameworks.map((framework) => (
                  <div 
                    key={framework.name}
                    className="flex items-center justify-between p-3 rounded-lg bg-zinc-800/50 border border-zinc-700/50"
                  >
                    <span className="text-sm text-white">{framework.name}</span>
                    <Badge 
                      variant="outline" 
                      className={
                        framework.status === "certified" 
                          ? "border-green-500/50 text-green-400" 
                          : framework.status === "compliant"
                          ? "border-blue-500/50 text-blue-400"
                          : framework.status === "in-progress"
                          ? "border-amber-500/50 text-amber-400"
                          : "border-zinc-500/50 text-zinc-400"
                      }
                    >
                      {framework.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Threat Model */}
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardHeader>
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
                <CardTitle className="text-white">Threat Mitigation</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {threatModel.map((item) => (
                  <div 
                    key={item.threat}
                    className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700/50"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-white text-sm">{item.threat}</span>
                      <Badge 
                        variant="outline" 
                        className={
                          item.severity === "critical" 
                            ? "border-red-500/50 text-red-400" 
                            : item.severity === "high"
                            ? "border-orange-500/50 text-orange-400"
                            : "border-yellow-500/50 text-yellow-400"
                        }
                      >
                        {item.severity}
                      </Badge>
                    </div>
                    <p className="text-xs text-zinc-500">{item.mitigation}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
