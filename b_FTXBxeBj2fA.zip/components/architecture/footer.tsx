import { Badge } from "@/components/ui/badge"
import { ExternalLink, Github, FileText, BookOpen } from "lucide-react"
import Link from "next/link"

export function Footer() {
  return (
    <footer className="py-16 px-6 border-t border-zinc-800">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                <span className="text-white font-bold text-lg">A</span>
              </div>
              <span className="text-xl font-bold text-white">Antigravity IDE</span>
            </div>
            <p className="text-zinc-400 text-sm max-w-md mb-4">
              A comprehensive architectural blueprint for building a next-generation 
              agentic development environment with multi-model AI integration.
            </p>
            <Badge variant="outline" className="border-zinc-700 text-zinc-400">
              Architecture Blueprint v1.0
            </Badge>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Documentation</h4>
            <ul className="space-y-2">
              <li>
                <Link 
                  href="/docs/ANTIGRAVITY_ARCHITECTURE.md" 
                  className="text-sm text-zinc-400 hover:text-white transition-colors flex items-center gap-2"
                >
                  <FileText className="w-4 h-4" />
                  Full Architecture
                </Link>
              </li>
              <li>
                <Link 
                  href="/docs/SYSTEM_DIAGRAMS.md" 
                  className="text-sm text-zinc-400 hover:text-white transition-colors flex items-center gap-2"
                >
                  <BookOpen className="w-4 h-4" />
                  System Diagrams
                </Link>
              </li>
              <li>
                <Link 
                  href="/types/antigravity.ts" 
                  className="text-sm text-zinc-400 hover:text-white transition-colors flex items-center gap-2"
                >
                  <Github className="w-4 h-4" />
                  Type Definitions
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">References</h4>
            <ul className="space-y-2">
              <li>
                <a 
                  href="https://ai.google.dev" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm text-zinc-400 hover:text-white transition-colors flex items-center gap-2"
                >
                  <ExternalLink className="w-4 h-4" />
                  Google AI Studio
                </a>
              </li>
              <li>
                <a 
                  href="https://www.anthropic.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm text-zinc-400 hover:text-white transition-colors flex items-center gap-2"
                >
                  <ExternalLink className="w-4 h-4" />
                  Anthropic Claude
                </a>
              </li>
              <li>
                <a 
                  href="https://developer.nvidia.com/nim" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm text-zinc-400 hover:text-white transition-colors flex items-center gap-2"
                >
                  <ExternalLink className="w-4 h-4" />
                  NVIDIA NIM
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-zinc-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-zinc-500">
            This is an architectural reference document. Not affiliated with Google.
          </p>
          <div className="flex items-center gap-4 text-sm text-zinc-500">
            <span>Built with Next.js</span>
            <span className="w-1 h-1 rounded-full bg-zinc-600" />
            <span>Powered by AI</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
