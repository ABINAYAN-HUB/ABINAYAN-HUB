"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Cpu, 
  Sparkles, 
  Zap, 
  Brain, 
  Server, 
  Code2,
  GitBranch,
  Database,
  Shield,
  ArrowRight,
  Check
} from "lucide-react"

const models = [
  {
    id: "gemini",
    name: "Google Gemini",
    icon: Sparkles,
    color: "from-blue-500 to-cyan-500",
    description: "Multi-modal foundation model with advanced reasoning capabilities",
    capabilities: [
      "Multi-modal understanding (text, image, video, audio)",
      "Long context window (up to 2M tokens)",
      "Advanced code generation and analysis",
      "Real-time streaming responses",
      "Function calling and tool use"
    ],
    integration: {
      endpoint: "/api/v1/models/gemini",
      auth: "API Key + OAuth 2.0",
      rateLimit: "60 RPM / 1M TPD",
      latency: "~200ms p50"
    },
    useCases: [
      "Primary code generation engine",
      "Multi-modal file analysis",
      "Complex reasoning tasks",
      "Documentation generation"
    ]
  },
  {
    id: "claude",
    name: "Claude Opus",
    icon: Brain,
    color: "from-orange-500 to-amber-500",
    description: "Anthropic's most capable model for nuanced, safe AI assistance",
    capabilities: [
      "200K context window",
      "Constitutional AI alignment",
      "Nuanced instruction following",
      "Multi-step reasoning chains",
      "Code review and refactoring"
    ],
    integration: {
      endpoint: "/api/v1/models/claude",
      auth: "API Key (Anthropic)",
      rateLimit: "50 RPM / 500K TPD",
      latency: "~300ms p50"
    },
    useCases: [
      "Code review and analysis",
      "Complex refactoring tasks",
      "Safety-critical code generation",
      "Technical documentation"
    ]
  },
  {
    id: "nvidia",
    name: "NVIDIA NIM",
    icon: Cpu,
    color: "from-green-500 to-emerald-500",
    description: "Optimized inference microservices for enterprise AI deployment",
    capabilities: [
      "GPU-accelerated inference",
      "Custom model fine-tuning",
      "Enterprise-grade security",
      "Kubernetes-native deployment",
      "Multi-GPU scaling"
    ],
    integration: {
      endpoint: "/api/v1/models/nvidia",
      auth: "NGC API Key + IAM",
      rateLimit: "Unlimited (self-hosted)",
      latency: "~50ms p50"
    },
    useCases: [
      "High-throughput code completion",
      "Real-time syntax analysis",
      "Custom domain models",
      "On-premise deployments"
    ]
  },
  {
    id: "codestral",
    name: "Codestral",
    icon: Code2,
    color: "from-purple-500 to-violet-500",
    description: "Specialized code generation model with 32K context",
    capabilities: [
      "80+ programming languages",
      "Fill-in-the-middle completion",
      "Instruction-tuned variants",
      "Low-latency responses",
      "Code-specific tokenization"
    ],
    integration: {
      endpoint: "/api/v1/models/codestral",
      auth: "API Key (Mistral)",
      rateLimit: "100 RPM / 2M TPD",
      latency: "~100ms p50"
    },
    useCases: [
      "Fast code completion",
      "Boilerplate generation",
      "Code translation",
      "Syntax correction"
    ]
  }
]

const orchestrationSteps = [
  {
    step: 1,
    title: "Request Intake",
    description: "Parse user intent and extract context from IDE state",
    icon: GitBranch
  },
  {
    step: 2,
    title: "Model Selection",
    description: "Route to optimal model based on task type and complexity",
    icon: Brain
  },
  {
    step: 3,
    title: "Context Assembly",
    description: "Build rich context from codebase, history, and preferences",
    icon: Database
  },
  {
    step: 4,
    title: "Inference Execution",
    description: "Execute with failover, caching, and streaming support",
    icon: Server
  },
  {
    step: 5,
    title: "Response Processing",
    description: "Validate, format, and apply safety filters to output",
    icon: Shield
  }
]

export function ModelIntegrationSection() {
  const [selectedModel, setSelectedModel] = useState(models[0])

  return (
    <section id="models" className="py-24 px-6 bg-zinc-950/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 border-cyan-500/50 text-cyan-400">
            AI Model Integration
          </Badge>
          <h2 className="text-4xl font-bold text-white mb-4">
            Multi-Model Orchestration Layer
          </h2>
          <p className="text-zinc-400 max-w-2xl mx-auto">
            Seamlessly integrate and orchestrate multiple AI models through a unified abstraction layer
            that handles routing, failover, and response aggregation.
          </p>
        </div>

        {/* Model Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
          {models.map((model) => {
            const Icon = model.icon
            const isSelected = selectedModel.id === model.id
            return (
              <button
                key={model.id}
                onClick={() => setSelectedModel(model)}
                className={`text-left p-4 rounded-xl border transition-all duration-300 ${
                  isSelected
                    ? "border-cyan-500/50 bg-cyan-500/10"
                    : "border-zinc-800 bg-zinc-900/50 hover:border-zinc-700"
                }`}
              >
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${model.color} flex items-center justify-center mb-3`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-semibold text-white mb-1">{model.name}</h3>
                <p className="text-sm text-zinc-500 line-clamp-2">{model.description}</p>
              </button>
            )
          })}
        </div>

        {/* Selected Model Details */}
        <Card className="bg-zinc-900/50 border-zinc-800 mb-16">
          <CardHeader>
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${selectedModel.color} flex items-center justify-center`}>
                <selectedModel.icon className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white">{selectedModel.name}</CardTitle>
                <p className="text-sm text-zinc-400">{selectedModel.description}</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="capabilities" className="w-full">
              <TabsList className="bg-zinc-800/50 border border-zinc-700">
                <TabsTrigger value="capabilities">Capabilities</TabsTrigger>
                <TabsTrigger value="integration">Integration</TabsTrigger>
                <TabsTrigger value="usecases">Use Cases</TabsTrigger>
              </TabsList>
              
              <TabsContent value="capabilities" className="mt-6">
                <div className="grid gap-3">
                  {selectedModel.capabilities.map((cap, i) => (
                    <div key={i} className="flex items-center gap-3 text-zinc-300">
                      <Check className="w-4 h-4 text-green-500 shrink-0" />
                      <span>{cap}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="integration" className="mt-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <p className="text-xs text-zinc-500 mb-1">Endpoint</p>
                    <code className="text-sm text-cyan-400">{selectedModel.integration.endpoint}</code>
                  </div>
                  <div className="p-4 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <p className="text-xs text-zinc-500 mb-1">Authentication</p>
                    <p className="text-sm text-white">{selectedModel.integration.auth}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <p className="text-xs text-zinc-500 mb-1">Rate Limit</p>
                    <p className="text-sm text-white">{selectedModel.integration.rateLimit}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <p className="text-xs text-zinc-500 mb-1">Latency</p>
                    <p className="text-sm text-white">{selectedModel.integration.latency}</p>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="usecases" className="mt-6">
                <div className="grid grid-cols-2 gap-3">
                  {selectedModel.useCases.map((useCase, i) => (
                    <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-zinc-800/30 border border-zinc-700/50">
                      <Zap className="w-4 h-4 text-amber-500" />
                      <span className="text-sm text-zinc-300">{useCase}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Orchestration Pipeline */}
        <div>
          <h3 className="text-2xl font-bold text-white mb-8 text-center">
            Request Orchestration Pipeline
          </h3>
          <div className="flex flex-col lg:flex-row items-center gap-4">
            {orchestrationSteps.map((step, i) => {
              const Icon = step.icon
              return (
                <div key={step.step} className="flex items-center gap-4 w-full lg:w-auto">
                  <div className="flex-1 lg:flex-none p-4 rounded-xl bg-zinc-900/50 border border-zinc-800 min-w-[200px]">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                        <Icon className="w-4 h-4 text-cyan-400" />
                      </div>
                      <span className="text-xs text-zinc-500">Step {step.step}</span>
                    </div>
                    <h4 className="font-medium text-white mb-1">{step.title}</h4>
                    <p className="text-xs text-zinc-500">{step.description}</p>
                  </div>
                  {i < orchestrationSteps.length - 1 && (
                    <ArrowRight className="w-5 h-5 text-zinc-600 shrink-0 hidden lg:block" />
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
